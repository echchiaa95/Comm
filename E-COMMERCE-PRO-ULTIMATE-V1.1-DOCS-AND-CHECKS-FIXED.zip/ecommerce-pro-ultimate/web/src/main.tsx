import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import App from "./App";
import { TenantProvider } from "./lib/tenant";
import "./index.css";

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 30_000, retry: 1 } },
});

// PWA: register the service worker in production (stale-while-revalidate,
// never caches Supabase/API traffic)
if ("serviceWorker" in navigator && import.meta.env.PROD) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  });
}

// Localized URLs: /fr/... and /ar/... are real, crawlable pages (hreflang). The prefix becomes the router basename,
// so every internal <Link to="/product/x"> automatically stays inside the active language.
const prefix = window.location.pathname.match(/^\/(en|fr|ar)(?=\/|$)/)?.[0] ?? "";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <BrowserRouter basename={prefix}>
        <TenantProvider>
          <App />
        </TenantProvider>
      </BrowserRouter>
    </QueryClientProvider>
  </React.StrictMode>,
);
