import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "react-router-dom";
import { supabase } from "@/lib/supabase";
import { useTenant } from "@/lib/tenant";

type Popup = {
  id: string; type: string; status: string; priority: number;
  content: { title?: string; body?: string; image?: string; cta_text?: string; cta_link?: string; coupon_code?: string };
  targeting: { pages?: string[]; min_cart?: number; device?: "mobile" | "desktop"; visitor?: "new" | "returning" };
  behavior: { delay_seconds?: number; frequency_cap?: number; cooldown_hours?: number };
};

type Seen = Record<string, { count: number; last: number }>;
const readSeen = (): Seen => { try { return JSON.parse(localStorage.getItem("epu_popup_seen") ?? "{}"); } catch { return {}; } };
const isMobile = () => window.matchMedia("(max-width: 768px)").matches;

export function PopupEngine() {
  const { store } = useTenant();
  const { pathname } = useLocation();
  const [candidate, setCandidate] = useState<Popup | null>(null);
  const [visible, setVisible] = useState(false);
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  const { data: popups } = useQuery({
    queryKey: ["popups", store?.id],
    enabled: !!store,
    queryFn: async () =>
      ((await supabase.from("popups").select("*").eq("store_id", store!.id).eq("status", "active")
        .order("priority", { ascending: false })).data ?? []) as Popup[],
  });

  const eligible = useMemo(() => {
    if (!popups?.length) return null;
    const cartLines: { qty: number }[] = JSON.parse(localStorage.getItem("epu_cart") ?? "[]");
    const cartTotalGuess = cartLines.length; // count-based fallback; min_cart in currency is refined server-side
    const returning = !!localStorage.getItem("epu_returning");
    const seen = readSeen();
    const now = Date.now();
    return popups.find((p) => {
      const t = p.targeting ?? {};
      if (t.pages?.length && !t.pages.some((x) => pathname.startsWith(x))) return false;
      if (t.device && ((t.device === "mobile") !== isMobile())) return false;
      if (t.visitor === "new" && returning) return false;
      if (t.visitor === "returning" && !returning) return false;
      if (t.min_cart && cartLines.length < t.min_cart) return false;
      const s = seen[p.id];
      if (s) {
        const cooldownMs = (p.behavior?.cooldown_hours ?? 24) * 3600_000;
        if (now - s.last < cooldownMs) return false;
        if (p.behavior?.frequency_cap && s.count >= p.behavior.frequency_cap) return false;
      }
      return true;
    }) ?? null;
  }, [popups, pathname]);

  useEffect(() => {
    if (!eligible || candidate?.id === eligible.id) return;
    setCandidate(eligible);
    setVisible(false);
    const wantsExitIntent = eligible.type === "exit_intent";
    const delayMs = (eligible.behavior?.delay_seconds ?? (wantsExitIntent ? 0 : 5)) * 1000;
    let exited = false;
    const onLeave = (e: MouseEvent) => {
      if (e.clientY <= 0 && !exited) { exited = true; setVisible(true); document.removeEventListener("mouseout", onLeave); }
    };
    if (wantsExitIntent && !isMobile()) document.addEventListener("mouseout", onLeave);
    const t = setTimeout(() => setVisible(true), delayMs);
    return () => { clearTimeout(t); document.removeEventListener("mouseout", onLeave); };
  }, [eligible, candidate?.id]);

  function close(converted = false) {
    if (!candidate) return;
    const seen = readSeen();
    const cur = seen[candidate.id] ?? { count: 0, last: 0 };
    localStorage.setItem("epu_popup_seen", JSON.stringify({ ...seen, [candidate.id]: { count: cur.count + (converted ? 1 : 1), last: Date.now() } }));
    setVisible(false); setCandidate(null);
  }

  function applyCoupon() {
    if (candidate?.content?.coupon_code) {
      localStorage.setItem("epu_coupon", candidate.content.coupon_code);
      close(true);
    }
  }

  async function subscribe(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await supabase.rpc("subscribe_newsletter", { p_store_id: store!.id, p_email: email, p_source: `popup:${candidate?.type ?? "unknown"}` });
    if (!error) { setDone(true); setTimeout(() => close(true), 1200); }
  }

  if (!candidate || !visible) return null;
  const c = candidate.content;

  return (
    <div className="fixed inset-0 z-50 grid place-items-center p-4">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => close()} />
      <div className="relative bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 text-center" role="dialog" aria-modal="true">
        <button onClick={() => close()} aria-label="close" className="absolute top-3 end-3 text-slate-400 hover:text-slate-700 text-xl leading-none">×</button>
        {c.image && <img src={c.image} alt="" className="w-full h-40 object-cover rounded-xl mb-4" />}
        {c.title && <h2 className="text-2xl font-extrabold mb-2">{c.title}</h2>}
        {c.body && <p className="text-slate-600 mb-5">{c.body}</p>}
        {candidate.type === "newsletter" && !done ? (
          <form onSubmit={subscribe} className="flex gap-2">
            <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com" className="flex-1 border border-slate-300 rounded-lg px-3 py-2" />
            <button className="brand-primary text-white rounded-lg px-4 py-2 font-semibold">→</button>
          </form>
        ) : c.coupon_code ? (
          <button onClick={applyCoupon} className="brand-primary text-white rounded-xl px-6 py-3 font-bold">
            {c.cta_text ?? `Apply ${c.coupon_code}`}
          </button>
        ) : c.cta_text && c.cta_link ? (
          <a href={c.cta_link} onClick={() => close(true)} className="inline-block brand-primary text-white rounded-xl px-6 py-3 font-bold">{c.cta_text}</a>
        ) : null}
      </div>
    </div>
  );
}
