import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { useTenant } from "@/lib/tenant";

declare global {
  interface Window {
    dataLayer?: Record<string, unknown>[];
    gtag?: (...args: unknown[]) => void;
    fbq?: ((...args: unknown[]) => void) & { queue?: unknown[]; loaded?: boolean; version?: string };
    ttq?: ((...args: unknown[]) => void) & { queue?: unknown[] };
  }
}

function loadScript(src: string, id: string) {
  if (document.getElementById(id)) return;
  const s = document.createElement("script");
  s.id = id; s.async = true; s.src = src;
  document.head.appendChild(s);
}

// Consent-gated tracking: NOTHING loads before an explicit choice, per the spec.
export function Analytics() {
  const { store, dir } = useTenant();
  const { pathname } = useLocation();
  const [consent, setConsent] = useState<string | null>(localStorage.getItem("epu_consent"));
  const [prefs, setPrefs] = useState({
    analytics: localStorage.getItem("epu_c_analytics") !== "0",
    ads: localStorage.getItem("epu_c_ads") !== "0",
  });
  const [customize, setCustomize] = useState(false);

  const { data: integrations } = useQuery({
    queryKey: ["integrations-pub", store?.id],
    enabled: !!store,
    queryFn: async () => (await supabase.rpc("store_integrations_public", { p_store_id: store!.id })).data as { provider: string; config: Record<string, string> }[],
  });

  useEffect(() => {
    if (consent !== "accepted" || !integrations) return;
    const cfg = Object.fromEntries(integrations.map((i) => [i.provider, i.config ?? {}])) as Record<string, Record<string, string>>;

    if (prefs.analytics && cfg.google_analytics?.measurement_id) {
      const id = cfg.google_analytics.measurement_id;
      loadScript(`https://www.googletagmanager.com/gtag/js?id=${id}`, "ga4-src");
      window.dataLayer = window.dataLayer ?? [];
      window.gtag = window.gtag ?? function (...args: unknown[]) { window.dataLayer!.push(args); };
      window.gtag("js", new Date());
      window.gtag("config", id, { anonymize_ip: true });
    }
    if (prefs.analytics && cfg.google_tag_manager?.container_id) {
      window.dataLayer = window.dataLayer ?? [];
      loadScript(`https://www.googletagmanager.com/gtm.js?id=${cfg.google_tag_manager.container_id}`, "gtm-src");
    }
    if (prefs.ads && cfg.meta_pixel?.pixel_id) {
      const fb = window.fbq = window.fbq ?? ((...args: unknown[]) => { (window.fbq!.queue = window.fbq!.queue ?? []).push(args); }) as Window["fbq"];
      fb.loaded = true; fb.version = "2.0";
      loadScript("https://connect.facebook.net/en_US/fbevents.js", "fbpx-src");
      fb("init", cfg.meta_pixel.pixel_id); fb("track", "PageView");
    }
    if (prefs.ads && cfg.tiktok_pixel?.pixel_id) {
      const tt = window.ttq = window.ttq ?? ((...args: unknown[]) => { (window.ttq!.queue = window.ttq!.queue ?? []).push(args); }) as Window["ttq"];
      loadScript(`https://analytics.tiktok.com/i18n/pixel/events.js?sdkid=${cfg.tiktok_pixel.pixel_id}&lib=ttq`, "ttpx-src");
      tt("track", "PageView");
    }
    // google_search_console / google_merchant / meta_conversions_api are
    // server-side integrations — no browser code here by design.
  }, [consent, integrations, prefs]);

  useEffect(() => {
    if (consent !== "accepted") return;
    window.gtag?.("event", "page_view", { page_path: pathname });
    window.fbq?.("track", "PageView");
    window.ttq?.("track", "PageView");
    window.dataLayer?.push({ event: "page_view", page_path: pathname });
  }, [pathname, consent]);

  function choose(accepted: boolean, p = prefs) {
    localStorage.setItem("epu_consent", accepted ? "accepted" : "rejected");
    localStorage.setItem("epu_c_analytics", accepted && p.analytics ? "1" : "0");
    localStorage.setItem("epu_c_ads", accepted && p.ads ? "1" : "0");
    setPrefs(p);
    setConsent(accepted ? "accepted" : "rejected");
  }

  if (consent !== null || !store) return null;
  return (
    <div className="fixed bottom-4 inset-x-4 sm:inset-x-auto sm:max-w-md z-50" dir={dir}>
      <div className="bg-white border border-slate-200 shadow-2xl rounded-2xl p-5">
        <p className="text-sm text-slate-600 mb-3">We use cookies for analytics and, with your consent, advertising measurement. No trackers load before you choose.</p>
        {customize && (
          <div className="space-y-2 mb-3 text-sm">
            {([["analytics", "Analytics (GA4, GTM)"], ["ads", "Advertising (Meta, TikTok pixels)"]] as const).map(([k, label]) => (
              <label key={k} className="flex items-center justify-between">
                <span>{label}</span>
                <input type="checkbox" checked={prefs[k]} onChange={(e) => setPrefs((p) => ({ ...p, [k]: e.target.checked }))} className="w-4 h-4" />
              </label>
            ))}
          </div>
        )}
        <div className="flex gap-2">
          <button onClick={() => choose(true)} className="flex-1 brand-primary text-white rounded-lg py-2 text-sm font-semibold">Accept</button>
          <button onClick={() => choose(false, { analytics: false, ads: false })} className="flex-1 border border-slate-300 rounded-lg py-2 text-sm font-medium">Reject all</button>
          <button onClick={() => setCustomize((c) => !c)} className="border border-slate-300 rounded-lg px-3 py-2 text-sm">⚙</button>
        </div>
      </div>
    </div>
  );
}
