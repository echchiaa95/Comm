# TypeScript workflow fixes

This update addresses the TypeScript diagnostics reported by GitHub Actions in:

- `web/src/components/Analytics.tsx`
- `web/src/components/PopupEngine.tsx`
- `web/src/lib/supabase.ts`
- `web/src/pages/automations-admin.tsx`
- `web/src/pages/storefront.tsx`

The fixes preserve strict TypeScript checks; they do not disable `noUnusedLocals`, `strict`, or the workflow's typecheck step.

Local validation: source syntax parsing and static SQL/security checks passed. Full `npm install`, `npm run typecheck`, and `npm run build` remain to be verified by GitHub Actions because dependency installation timed out in this environment.
