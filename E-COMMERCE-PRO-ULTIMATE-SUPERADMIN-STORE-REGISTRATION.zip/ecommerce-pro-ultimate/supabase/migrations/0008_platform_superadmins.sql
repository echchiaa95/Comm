-- Platform-level super administrators.
-- Bootstrap the first superadmin manually with supabase/bootstrap_superadmin.sql
-- after creating that user through Supabase Auth.

create table if not exists public.platform_superadmins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id) on delete set null
);

alter table public.platform_superadmins enable row level security;

-- No browser role can read or modify the platform superadmin registry.
revoke all on public.platform_superadmins from anon, authenticated;
grant all on public.platform_superadmins to service_role;

create or replace function public.is_platform_superadmin(p_user_id uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.platform_superadmins ps
    where ps.user_id = coalesce(p_user_id, auth.uid())
  );
$$;

revoke all on function public.is_platform_superadmin(uuid) from public, anon;
grant execute on function public.is_platform_superadmin(uuid) to authenticated, service_role;

comment on table public.platform_superadmins is
  'Platform-level super administrators. Manage only through trusted service role or Supabase SQL editor.';
