-- RUN ONCE in Supabase SQL Editor after creating the intended superadmin
-- account with Supabase Auth. Replace the email below with your own account email.
-- This file must never be exposed through a public RPC or browser client.

do $$
declare
  v_email text := lower(trim('REPLACE_WITH_YOUR_LOGIN_EMAIL'));
  v_user_id uuid;
begin
  if v_email = '' or v_email = 'replace_with_your_login_email' then
    raise exception 'Replace REPLACE_WITH_YOUR_LOGIN_EMAIL before running this script.';
  end if;

  select id into v_user_id
  from auth.users
  where lower(email) = v_email
  limit 1;

  if v_user_id is null then
    raise exception 'No Supabase Auth user found for %. Create this user first, then rerun.', v_email;
  end if;

  insert into public.platform_superadmins(user_id)
  values (v_user_id)
  on conflict (user_id) do nothing;
end $$;
