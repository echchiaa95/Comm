# E-Commerce Pro Ultimate — V1.1 Repair Release

A multi-store, white-label e-commerce SaaS foundation for physical, digital and hybrid products. This release repairs the original project in place and preserves its existing architecture and modules.

> **Release status: repaired codebase, not production-certified.** Static migration-order, TypeScript/TSX syntax and multi-store prerender checks were executed in the repair environment. PostgreSQL migrations, pgTAP, strict TypeScript checking, Vite production build, Deno checks, Stripe flows and the complete 25-scenario matrix have **not** been executed there. Do not deploy to production until the pending checks in `TESTING.md` pass.

## 1. Delivered architecture

- React 18, Vite 5, TypeScript and Tailwind CSS storefront/admin application.
- Supabase PostgreSQL with seven ordered migrations (`0001`–`0007`), tenant-aware RLS and server-side commerce functions.
- Supabase Edge Functions for store creation, checkout, Stripe webhooks/Connect, downloads, email/marketing workers, SEO endpoints and domain verification.
- Physical, digital and hybrid product/order workflows.
- COD lifecycle separating order confirmation, shipping and cash collection.
- Stripe payment verification through signed webhooks and server-side fulfillment.
- Arabic, French and English URL/metadata support with RTL/LTR output.
- Multi-store prerendering and SEO metadata generation.
- PWA manifest and service worker.

See `REPAIR-REPORT.md` for the detailed changes and known limitations.

## 2. Migration order

Run migrations in this order on a **disposable local/test database first**:

1. `0001_schema.sql`
2. `0002_commerce_core.sql`
3. `0003_phase2.sql`
4. `0004_phase3.sql`
5. `0005_phase4.sql`
6. `0006_commerce_engine_security.sql`
7. `0007_public_product_column_security.sql`

Offline dependency check:

```bash
python3 scripts/check-migrations.py
```

This checks references and ordering statically. It does **not** prove PostgreSQL execution or RLS behavior.

## 3. Local setup

Requirements: Node.js 20+, npm, Docker, and Supabase CLI.

```bash
# From the repository root
cp supabase/.env.example supabase/.env
cp web/.env.example web/.env

# Fill the local environment files with local/test values.
supabase start
supabase db reset
supabase test db

cd web
npm install
npm run typecheck
npm run build
npm run test:seo
```

`web/package-lock.json` is not included in this offline repair archive because the npm registry was unreachable in the repair environment. On a network-connected machine, run `npm install` from `web/` and commit the generated `package-lock.json`. CI now detects the lockfile automatically: it uses deterministic `npm ci` when the lockfile exists, and falls back to `npm install` with a visible warning while it is absent. Until the lockfile is committed, dependency resolution is not fully reproducible.

## 4. Environment and secrets

- Web client variables are documented in `web/.env.example`.
- Supabase/Edge Function secrets are documented in `supabase/.env.example`.
- Values prefixed `VITE_` are public and must never contain secret credentials.
- Never place Stripe secret keys, webhook secrets or the Supabase service-role key in frontend code, committed files or public tables.
- Use Stripe test credentials for validation. Configure real secrets only through Supabase secrets/Vault after test workflows pass.

## 5. Stripe and payment model

The application supports the configured per-store Stripe Connect/direct-charge model. Payment status must be derived from verified webhook processing, not the browser success redirect. Webhook retry, duplicate-event, async-payment and refund behavior must be validated with Stripe test mode before launch.

COD confirmation, shipment and cash collection are distinct states. A COD order becomes paid only after the merchant records collection. Digital-only orders must not use COD.

## 6. SEO and domains

The prerender script supports multiple stores and locales. The repair environment executed its test suite and validated 11 generated pages across two stores and three languages. Production delivery still requires correct CDN/hosting rewrites for store domains, prerendered pages, `/sitemap.xml` and `/robots.txt`.

The prerender test is not a substitute for checking Search Console, crawler access, canonical URLs and structured data on the deployed domains.

## 7. CI

GitHub Actions includes separate static, database, Edge Function and web checks. The web job uses `npm ci` when `web/package-lock.json` exists; otherwise it uses `npm install` and emits a workflow warning. After committing the lockfile, enable setup-node npm caching keyed by `web/package-lock.json` if desired.

The database job requires Supabase CLI/Docker services. The Edge Function job requires Deno. The repository currently contains 12 Edge Functions, including `unsubscribe`. Their success must be read from actual GitHub Actions runs, not inferred from workflow definitions.

## 8. Known limitations

The following are not represented as completed production features:

- No live PostgreSQL migration/test run was performed in the repair environment.
- No live Stripe test-mode transaction or webhook replay was performed.
- No full browser/E2E execution of the 25 business scenarios was performed.
- WhatsApp requires a configured Cloud API/Twilio provider and approved templates.
- AI SEO requires a configured LLM provider.
- Interactive A/B testing, some wishlist/design-customizer surfaces and advanced affiliate/reporting workflows remain incomplete or partial; consult `REPAIR-REPORT.md` and `TESTING.md`.
- Product cost confidentiality has a forward migration (`0007`) and static regression check; its PostgreSQL privilege assertions still require execution against a real Supabase/PostgreSQL database.
- PITR/backup restore drills, edge rate limiting and load testing remain operational requirements.

## 9. Release acceptance

Do not label this release production-ready until all applicable checks in `TESTING.md` pass, including clean database reset, pgTAP, strict typecheck, Vite build, Deno checks, Stripe test-mode workflows, tenant isolation and the full 25-scenario matrix. Record evidence and environment for every result.



## Fresh Supabase setup: platform superadmin and store provisioning

This project uses a platform-level superadmin gate for creating stores. Ordinary
authenticated users cannot register stores through the `create-store` Edge Function.

1. Apply all migrations, including `0008_platform_superadmins.sql`, to the new Supabase project.
2. Create your own account through Supabase Auth (Dashboard → Authentication → Users, or the app's sign-up flow).
3. Open `supabase/bootstrap_superadmin.sql`, replace `REPLACE_WITH_YOUR_LOGIN_EMAIL` with that exact Auth email, and run the script in Supabase SQL Editor as the project owner.
4. Deploy the Edge Function: `supabase functions deploy create-store`.
5. Sign in with the bootstrapped superadmin account and open the store setup wizard.

The bootstrap SQL is a one-time privileged operation. Do not expose it as an RPC,
Edge Function, frontend file, or public endpoint. Never put the Supabase service-role
key in the browser or GitHub Pages build.

The initial store creator is recorded as `stores.created_by`; the existing database
trigger grants that creator the store's `owner` role. If a separate merchant login
must own each store, implement and test an explicit invitation/ownership-transfer
workflow before production use. The platform superadmin registry does not itself
create merchant Auth users.
