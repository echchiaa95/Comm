#!/usr/bin/env python3
"""Static regression check: browser-facing product reads must not expose cost_price."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
errors = []
migration = root / "supabase/migrations/0007_public_product_column_security.sql"
if not migration.exists():
    errors.append("missing 0007_public_product_column_security.sql")
else:
    sql = migration.read_text(encoding="utf-8").lower()
    if not re.search(r"revoke\s+select\s+on\s+table\s+public\.products\s+from\s+anon\s*,\s*authenticated", sql):
        errors.append("products table-level SELECT is not revoked from anon/authenticated")
    grant = re.search(r"grant\s+select\s*\((.*?)\)\s*on\s+table\s+public\.products", sql, re.S)
    if not grant:
        errors.append("missing explicit safe-column SELECT grant on products")
    elif "cost_price" in grant.group(1):
        errors.append("cost_price is included in browser SELECT grant")
    if re.search(r"returns\s+setof\s+public\.products", sql):
        errors.append("search_products still returns the full products composite row")
    if not re.search(r"create\s+function\s+public\.search_products[\s\S]*?returns\s+table\s*\(", sql):
        errors.append("search_products does not declare an explicit safe TABLE projection")

for path in (root / "web/src").rglob("*.tsx"):
    text = path.read_text(encoding="utf-8")
    if re.search(r'from\(["\']products["\']\)\s*\.select\(["\']\*["\']\)', text):
        errors.append(f"unsafe products.select('*') in {path.relative_to(root)}")

security_test = root / "supabase/tests/security.test.sql"
test_text = security_test.read_text(encoding="utf-8") if security_test.exists() else ""
for role in ("anon", "authenticated"):
    if f"has_column_privilege('{role}', 'public.products', 'cost_price', 'SELECT')" not in test_text:
        errors.append(f"missing pgTAP cost_price privilege assertion for {role}")

if errors:
    print("PUBLIC PRODUCT COLUMN CHECK FAILED")
    for error in errors:
        print(f"- {error}")
    raise SystemExit(1)
print("PUBLIC PRODUCT COLUMN CHECK PASSED: no browser-facing cost_price exposure detected statically")
