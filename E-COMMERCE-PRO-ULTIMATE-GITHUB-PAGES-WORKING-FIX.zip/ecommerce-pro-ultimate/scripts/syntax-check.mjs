#!/usr/bin/env node
// Offline syntax gate: parses every .ts/.tsx (web + Edge Functions) with the TypeScript compiler and fails on
// SYNTACTIC errors (invalid JSX, unbalanced braces, bad imports syntax…). It does NOT type-check
// (that needs `npm ci` and `npm run typecheck`).
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, extname } from "node:path";
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
let ts;
try { ts = require("typescript"); } catch { ts = require(join(process.env.NPM_GLOBAL ?? "/home/claude/.npm-global/lib/node_modules", "typescript")); }

const roots = ["web/src", "supabase/functions"];
const files = [];
(function walk(d) {
  for (const n of readdirSync(d)) {
    const p = join(d, n);
    if (statSync(p).isDirectory()) walk(p);
    else if ([".ts", ".tsx"].includes(extname(p))) files.push(p);
  }
}).call(null, roots[0]);
(function walk(d) { for (const n of readdirSync(d)) { const p = join(d, n); statSync(p).isDirectory() ? walk(p) : [".ts", ".tsx"].includes(extname(p)) && files.push(p); } })(roots[1]);

let bad = 0;
for (const f of files) {
  const out = ts.transpileModule(readFileSync(f, "utf8"), {
    fileName: f, reportDiagnostics: true,
    compilerOptions: { jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext, isolatedModules: true },
  });
  for (const d of out.diagnostics ?? []) {
    bad++;
    const { line, character } = d.file ? d.file.getLineAndCharacterOfPosition(d.start) : { line: 0, character: 0 };
    console.log(`${f}:${line + 1}:${character + 1} TS${d.code} ${ts.flattenDiagnosticMessageText(d.messageText, "\n")}`);
  }
}
console.log(`${files.length} files parsed, ${bad} syntax error(s)`);
process.exit(bad ? 1 : 0);
