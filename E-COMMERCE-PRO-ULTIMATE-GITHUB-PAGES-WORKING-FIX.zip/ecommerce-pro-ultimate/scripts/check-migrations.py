#!/usr/bin/env python3
"""Static migration dependency checker (no database needed).

Walks supabase/migrations/*.sql in filename order, splits statements (respecting
$$ bodies and quotes) and verifies, at the point each statement runs, that every
table referenced by DDL (FKs, indexes, policies, triggers, alter/revoke/grant,
inserts) already exists. It also lists tables referenced inside function bodies
that never exist at all, and policy/RLS targets.

This is a STATIC check. It does not replace running `supabase db reset`.
Exit code 1 on any ordering/definition error.
"""
import re, sys, glob, os

root = os.path.join(os.path.dirname(__file__), "..", "supabase", "migrations")

def split_statements(sql):
    out, buf, i, n = [], [], 0, len(sql)
    dollar = None
    while i < n:
        c = sql[i]
        if dollar is None:
            if sql.startswith("--", i):
                j = sql.find("\n", i); j = n if j < 0 else j
                i = j; continue
            if sql.startswith("/*", i):
                j = sql.find("*/", i); i = n if j < 0 else j + 2; continue
            if c == "'":
                j = i + 1
                while j < n:
                    if sql[j] == "'" and sql[j+1:j+2] == "'": j += 2; continue
                    if sql[j] == "'": break
                    j += 1
                buf.append(sql[i:j+1]); i = j + 1; continue
            m = re.match(r"\$(\w*)\$", sql[i:])
            if m:
                dollar = m.group(0); buf.append(dollar); i += len(dollar); continue
            if c == ";":
                st = "".join(buf).strip()
                if st: out.append(st)
                buf = []; i += 1; continue
            buf.append(c); i += 1
        else:
            j = sql.find(dollar, i)
            if j < 0: buf.append(sql[i:]); i = n; continue
            buf.append(sql[i:j+len(dollar)]); i = j + len(dollar); dollar = None
    st = "".join(buf).strip()
    if st: out.append(st)
    return out

created, funcs, errors, warnings = set(), set(), [], []
EXTERNAL = {"auth.users", "vault.secrets", "vault.decrypted_secrets", "storage.objects", "storage.buckets"}

def tbl(name):
    return name.split(".")[-1].strip('"')

def strip_bodies(st):
    return re.sub(r"\$(\w*)\$.*?\$\1\$", "$$BODY$$", st, flags=re.S)

body_refs = {}
for f in sorted(glob.glob(os.path.join(root, "*.sql"))):
    base = os.path.basename(f)
    for st in split_statements(open(f, encoding="utf-8").read()):
        head = strip_bodies(st)
        low = head.lower()
        m = re.match(r"create\s+table\s+(?:if\s+not\s+exists\s+)?(?:public\.)?(\w+)", low)
        refs = set()
        if m:
            name = m.group(1)
            refs |= set(re.findall(r"(?<![\w.])references\s+(?!auth\.|vault\.)(?:public\.)?(\w+)", low))
            refs.discard(name)
        elif re.match(r"create\s+(?:unique\s+)?index", low):
            mm = re.search(r"\bon\s+(?:public\.)?(\w+)", low); refs = {mm.group(1)} if mm else set()
        elif re.match(r"create\s+policy", low) or re.match(r"create\s+trigger", low):
            mm = re.search(r"\bon\s+(?:public\.)?(\w+)", low); refs = {mm.group(1)} if mm else set()
            if "policy" in low[:20]:
                refs |= set(re.findall(r"(?:from|join)\s+public\.(\w+)", low))
        elif re.match(r"alter\s+table", low):
            mm = re.match(r"alter\s+table\s+(?:if\s+exists\s+)?(?:only\s+)?(?:public\.)?(\w+)", low)
            refs = {mm.group(1)} if mm else set()
            refs |= set(re.findall(r"(?<![\w.])references\s+(?!auth\.|vault\.)(?:public\.)?(\w+)", low))
        elif re.match(r"(revoke|grant)\b", low):
            refs = set(re.findall(r"\bon\s+(?:table\s+)?(?:public\.)?(\w+)", low))
            refs -= {"function", "all", "schema", "sequence"}
        elif re.match(r"insert\s+into", low):
            mm = re.match(r"insert\s+into\s+(?:public\.)?(\w+)", low); refs = {mm.group(1)} if mm else set()
        for r in sorted(refs):
            if r not in created and f"public.{r}" not in EXTERNAL and r not in ("users",):
                errors.append(f"{base}: statement references '{r}' before it exists: {head[:90]!r}")
        if m: created.add(m.group(1))
        fm = re.match(r"create\s+(?:or\s+replace\s+)?function\s+(?:public\.)?(\w+)", low)
        if fm:
            funcs.add(fm.group(1))
            for b in re.findall(r"\$(\w*)\$(.*?)\$\1\$", st, flags=re.S):
                for t in re.findall(r"(?:from|join|into|update)\s+public\.(\w+)", b[1], flags=re.I):
                    body_refs.setdefault(t, set()).add(f"{base}:{fm.group(1)}")

for t, where in sorted(body_refs.items()):
    if t not in created:
        errors.append(f"function bodies reference table '{t}' which is never created ({sorted(where)[:3]})")

print(f"tables created: {len(created)}  functions: {len(funcs)}")
for w in warnings: print("WARN ", w)
for e in errors: print("ERROR", e)
if errors:
    print(f"\nFAILED: {len(errors)} problem(s)"); sys.exit(1)
print("OK: no ordering/definition problems detected (static check only)")
