# CI and Local Validation Status — V1.1

Date: 2026-10-31

## Executed successfully in the current repair session

- ZIP integrity: passed (`ZipFile.testzip()` returned no corrupt entry).
- Static migration dependency checker: passed (`python3 scripts/check-migrations.py`); 75 tables and 46 functions detected. This is static analysis only.
- TypeScript/TSX and Edge Function syntax parser: passed (`node scripts/syntax-check.mjs`); 37 files parsed, 0 syntax diagnostics. This is not a full TypeScript typecheck.
- Prerender SEO test: passed (`cd web && node scripts/prerender.test.mjs`); 11 generated pages validated and all assertions passed.
- GitHub Actions YAML: parsed successfully with a YAML parser. Note that YAML 1.1 parsers may display the GitHub key `on` as boolean `true`; GitHub Actions interprets the workflow syntax itself.
- `web/package.json`: parsed as valid JSON.
- Public product column static security checker: passed (`python3 scripts/check-public-product-columns.py`).

## Attempted but blocked

- `cd web && npm install --no-audit --no-fund`: attempted in the repair environment and timed out after 120 seconds. No `package-lock.json` was produced and no complete `node_modules` installation was left behind.

## Not executed

- `npm run typecheck` and `npm run build`: require the web dependencies; not run because installation timed out. A global `tsc --noEmit` attempt also stopped because `vite/client` type definitions were unavailable without project dependencies.
- PostgreSQL migrations, `supabase db reset`, `supabase db lint`, and pgTAP: not run; a local PostgreSQL/Docker/Supabase CLI environment is not available here.
- `deno check`: not run; Deno is unavailable.
- Stripe test-mode checkout, Connect onboarding, webhook signature/retry/replay and refunds: not run; require Stripe test credentials and a running backend.
- Browser-based checkout, PWA installation/update, and the full 25-scenario end-to-end matrix: not run.

## Lockfile

`web/package-lock.json` is not included. It is intentionally not fabricated: npm must resolve the declared dependency graph against the registry to generate a trustworthy lockfile. On a network-connected machine, run from `web/`:

```bash
npm install --no-audit --no-fund
npm run typecheck
npm run build
npm run test:seo
```

Commit the resulting `package-lock.json`. The GitHub Actions web job uses `npm ci` when the lockfile exists; otherwise it falls back to `npm install` and emits a warning. The fallback is temporary and not fully reproducible.

## Release status

**Not production-certified.** The executed checks above are static/local only. Complete clean database reset, pgTAP, strict typecheck, production build, Deno checks, Stripe test-mode workflows, browser testing, PostgreSQL execution of the public-column privilege assertions for `products.cost_price`, and the complete 25-scenario matrix before production deployment.

## Additional V1.1 hardening — public product cost confidentiality

- Added `0007_public_product_column_security.sql`: revokes table-wide browser SELECT on `products`, grants only the storefront-safe columns, and replaces `search_products` (previously `SETOF products`) with an explicit safe projection that excludes `cost_price`.
- Replaced storefront and admin product `select("*")` requests with explicit column projections.
- Added two pgTAP regression assertions proving `anon` and `authenticated` cannot SELECT `products.cost_price`.
- This migration and the pgTAP assertions are written but still require execution on PostgreSQL/Supabase; static checks do not prove runtime behavior.

## Additional security hardening — product cost confidentiality

- Added migration `0007_public_product_column_security.sql` to revoke table-wide browser SELECT on `products`, grant only the public-safe columns, and replace the public search RPC's full-row return with an explicit projection that excludes `cost_price`.
- Storefront product queries and the admin product list now request explicit columns; no frontend `products.select("*")` remains.
- Added `scripts/check-public-product-columns.py` and wired it into the static CI job.
- Added two pgTAP assertions to `security.test.sql` for `anon` and `authenticated` column privileges. The assertions are authored but not executed until Supabase/PostgreSQL is available.
- Re-executed migration dependency check, public-column static check, TS/TSX syntax gate, and prerender test successfully. Full database execution remains outstanding.
