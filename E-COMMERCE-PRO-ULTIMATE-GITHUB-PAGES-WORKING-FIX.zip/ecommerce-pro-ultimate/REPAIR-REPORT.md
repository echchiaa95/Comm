# REPAIR REPORT — E-Commerce Pro Ultimate V1.1

Scope: in-place repair of `ecommerce-pro-ultimate-final.zip` (backup kept untouched as `ORIGINAL-BACKUP.zip` in the work area).
**Sandbox limits:** no Postgres, no network (no `npm ci`, no Stripe, no Supabase). Therefore **no claim of a passing build, SQL execution or
Stripe flow is made.** Only the three checks in `TESTING.md §A` were executed.

## 1. Errors discovered (verified by reading/executing)
| # | Area | Finding |
|---|---|---|
| 1 | React | `Suspended` in `App.tsx` had an unclosed `<div>` and never rendered `{children}` (executed syntax gate: 3 TS errors in the original, 0 now). |
| 2 | Routing | `/admin/setup` was linked but never routed; with no store resolved the "create store" link led to the same dead page. |
| 3 | DB | 13 tables required by the brief + `order_status_history`, `refunds`, `shipments`, `download_logs` were never defined, yet referenced by 21 FKs, RLS, triggers and functions → `0001` could not run on any database. |
| 4 | DB | `has_store_access` joined `permissions` on a non-existent column `p.id` (PK is `code`) and was declared before its tables — it underpins every RLS policy. |
| 5 | DB | `fulfill_paid_order`: undeclared `v_qty`, invalid `?? ` operator, idempotency by `payment_events` that conflicted with the webhook's own insert, and **EXECUTE left on PUBLIC** (any user could mark an order paid / mint downloads). |
| 6 | DB | `decrement_inventory` was callable by anyone, not store-scoped, and raised `INSUFFICIENT_STOCK` for untracked (digital) products — so any basket containing an ebook failed; idempotency key collided for duplicate product lines. |
| 7 | DB | `confirm_cod_order` marked COD orders **paid** at confirmation; `place_order` allowed COD for digital-only baskets, silently granted free shipping when no method was sent, treated unsupported coupon kinds as fixed discounts, matched idempotency keys across stores, merged all phone-only guests into one customer (`''` email) and never linked `customers.user_id` (so `/account` was empty). |
| 8 | DB | `handle_new_store` used undeclared `v_zone`; `sales_summary` had an unbalanced parenthesis; `recalc_loyalty` tier query invalid; referral reward fired at order *placement* (before payment). |
| 9 | Stripe | Webhook used synchronous `constructEvent` (fails on Deno → every webhook rejected), inserted the event row before processing and then rejected retries forever, ignored `payment_status`, handled only 2 event types. |
| 10 | Stripe | `create-checkout` mixed destination charge **and** `stripeAccount` (invalid), omitted shipping/tax/discount from line items, used the Edge Function origin as success URL, had no CORS, fell back to the platform key. Frontend called it without `apikey`/`Authorization` (gateway 401). `connect-stripe` wrote to `vault` via PostgREST (not exposed) and enabled Stripe without any verification. |
| 11 | Security | Workers (`send-email`, `abandoned-cart-worker`, `automation-worker`) were callable by anyone; `verify-domain` allowed taking over another store's domain and set `verified` without proof; `resolve_store` accepted any `slug.anything` host; `integrations.secret_ref` column revoke was ineffective; open `reviews`/`analytics` inserts. |
| 12 | Email | Marketing sent without send-time consent check or unsubscribe link, jobs not atomically claimed, templates not found for jobs without `template_id`, download links pointed at the wrong host, user values injected unescaped into HTML, opt-out reset by `track_abandoned_checkout`, carts not marked recovered after purchase. |
| 13 | SEO | hreflang listed the same URL for all languages; locale lived only in `localStorage`; sitemap/robots emitted Supabase function-host URLs; prerender hard-coded one `STORE_ID` and English only. |
| 14 | PWA | SW served a stale `index.html` after deploys (blank page risk) and cached private routes' shell. |
| 15 | Checkout UI | New idempotency key per click (double orders), COD/address forced for digital-only carts, "Payment verified" shown from the redirect without server confirmation, RLS-blocked order lookup for guests, country case mismatch with server. |
| 16 | CI | `npm install` without lockfile; ran only `db lint`/tests that could not pass. `supabase/config.toml` absent. |

## 2. Database changes
- **Renumbered** (never executable, so safe): `0002_phase2→0003`, `0003_phase3→0004`, `0004_phase4→0005` (content byte-identical).
- **`0001_schema.sql` (minimal edit):** `set check_function_bodies=off`; 21 forward FKs stripped (re-added in 0002); RLS/trigger/index/policy statements that need later tables moved to 0002; pattern-A policy loop skips not-yet-created tables; `sales_summary` paren fixed. No table/column removed.
- **`0002_commerce_core.sql` (new):** customers, customer_addresses, carts, cart_items, shipping_zones, shipping_methods, orders, order_items, order_status_history, payment_providers, payments, payment_events (state machine), refunds, shipments, digital_downloads, license_keys, download_logs; composite `(id, store_id)` FKs so cross-tenant references are impossible at DB level; status/payment/fulfillment kept separate; `has_store_access` fixed; RLS (staff read-only on money tables; writes only through RPCs), column-level grants, secrets revoked.
- **`0006_commerce_engine_security.sql` (new):** hardened `place_order`, `decrement_inventory`, `_finalize_paid_order`, `fulfill_paid_order` (service role + amount/currency check), `confirm_cod_order`, `mark_cod_collected`, `update_order_status` (transition graph), cancel/expiry, event state machine, refunds, Connect sync, `claim_download`, Vault wrappers, `resolve_store`, loyalty/referral fixes, consent-safe newsletter, tighter public policies, **EXECUTE revoked from PUBLIC/anon/authenticated on every function then granted per audience**, `pg_temp`-last search_path on all SECURITY DEFINER functions.
- Validator: `scripts/check-migrations.py` (offline dependency/ordering checker).

## 3. Stripe changes
Destination charges (Connect) **or** direct charges with a Vault key — never mixed; no silent platform-key fallback; amounts from DB and verified against `session.amount_total`; success/cancel URLs on the store's own verified domain (allow-listed origins, no open redirect); CORS allow-list + OPTIONS; webhook: raw-body async signature check, event state machine (`received/processing/succeeded/failed/retryable/ignored`), `payment_status` check, async success/failure, expiry, `charge.refunded`, `account.updated`; retries safe; duplicates are no-ops; entitlement revoked on full refund.

## 4. Security improvements (summary)
Fulfilment/inventory/download RPCs service-role only · direct writes to orders/payments/downloads impossible for clients · tenant FK consistency · tenant-scoped idempotency · cron-secret on workers · HMAC unsubscribe · domain ownership proof · private-route-aware service worker · forged reviews/analytics blocked · signed 60 s download URLs with limit/expiry/rate limit/audit log.

## 5. Build / test results
See `TESTING.md`. Executed ✅: migration dependency check, syntax gate (0 errors; original 3), prerender test (11 pages). **Not executed:** SQL on Postgres, pgTAP (56 assertions written), `tsc` strict typecheck, `vite build`, Deno check, any Stripe/email/browser flow, the 25 scenarios (matrix provided).

## 6. Files
**Modified (29):**
- `.github/workflows/ci.yml`
- `supabase/functions/abandoned-cart-worker/index.ts`
- `supabase/functions/automation-worker/index.ts`
- `supabase/functions/connect-stripe/index.ts`
- `supabase/functions/create-checkout/index.ts`
- `supabase/functions/create-store/index.ts`
- `supabase/functions/deliver-download/index.ts`
- `supabase/functions/robots/index.ts`
- `supabase/functions/send-email/index.ts`
- `supabase/functions/sitemap/index.ts`
- `supabase/functions/stripe-webhook/index.ts`
- `supabase/functions/verify-domain/index.ts`
- `supabase/migrations/0001_schema.sql`
- `supabase/seed.sql`
- `supabase/tests/checkout.test.sql`
- `supabase/tests/rls.test.sql`
- `web/.env.example`
- `web/package.json`
- `web/public/manifest.webmanifest`
- `web/public/sw.js`
- `web/scripts/prerender.mjs`
- `web/src/App.tsx`
- `web/src/lib/cart.ts`
- `web/src/lib/tenant.tsx`
- `web/src/main.tsx`
- `web/src/pages/Login.tsx`
- `web/src/pages/admin.tsx`
- `web/src/pages/payments-admin.tsx`
- `web/src/pages/storefront.tsx`

**Renamed (content unchanged):** `0002_phase2→0003_phase2`, `0003_phase3→0004_phase3`, `0004_phase4→0005_phase4` (`supabase/migrations/`).

**Added (11):**
- `scripts/check-migrations.py`
- `scripts/syntax-check.mjs`
- `supabase/.env.example`
- `supabase/config.toml`
- `supabase/functions/_shared/http.ts`
- `supabase/functions/unsubscribe/index.ts`
- `supabase/migrations/0002_commerce_core.sql`
- `supabase/migrations/0006_commerce_engine_security.sql`
- `supabase/tests/security.test.sql`
- `web/scripts/prerender.test.mjs`
- `web/src/pages/setup.tsx`

**Preserved untouched (23):**
- `FINAL-REPORT.md`
- `README.md`
- `TESTING.md`
- `web/index.html`
- `web/public/icon.svg`
- `web/src/components/Analytics.tsx`
- `web/src/components/Discovery.tsx`
- `web/src/components/PopupEngine.tsx`
- `web/src/index.css`
- `web/src/layouts/Admin.tsx`
- `web/src/layouts/Storefront.tsx`
- `web/src/lib/guards.tsx`
- `web/src/lib/supabase.ts`
- `web/src/pages/account.tsx`
- `web/src/pages/affiliates-admin.tsx`
- `web/src/pages/automations-admin.tsx`
- `web/src/pages/campaigns-admin.tsx`
- `web/src/pages/downloads.tsx`
- `web/src/pages/email-templates-admin.tsx`
- `web/src/pages/popups-admin.tsx`
- `web/src/pages/reviews-admin.tsx`
- `web/tsconfig.json`
- `web/vite.config.ts`

## 7. Behaviour changes you should know about (no feature removed)
COD confirm no longer means paid · referral points granted at payment, not at placement · shipping method/address now mandatory for physical lines · unsupported coupon kinds (`bogo`, `bundle`, `buy_x_get_y`) are rejected instead of mis-applied · COD hidden for digital-only carts · Stripe cannot be enabled until onboarding/key is valid · languages now have URL prefixes · `web/.env.example` overwritten.

## 8. Remaining limitations / not done
1. **Nothing was run against a database or Stripe** — expect first-run SQL fixes; `package-lock.json` could not be generated offline. The V1.1 CI job uses `npm ci` when a lockfile exists and a visible `npm install` fallback while it is absent. This is temporary and does not provide deterministic dependency resolution.
2. `products.cost_price` is addressed in migration `0007_public_product_column_security.sql` with explicit browser column grants and safe projections. Static checks pass; PostgreSQL privilege assertions still require execution.
3. Newsletter is single opt-in (no double opt-in email). WhatsApp has **no provider integration** — not operational (consent gating exists in the schema only).
4. Marketing Center: operational in schema/UI = discounts/coupons, popups, reviews, loyalty, referrals, abandoned carts, email (needs Resend); *partial* = affiliates (no commission generation), A/B tests (tables only), UTM (stored on orders, no reports); *external provider* = email, WhatsApp, Stripe.
5. No admin UI for refunds/shipments (refund in Stripe → webhook updates the order). Zero/3-decimal currencies: zero-decimal handled, 3-decimal not.
6. Sitemap/robots/prerender require CDN rewrite rules documented in README; not tested end-to-end. PWA icons are SVG only; install/update unverified.
7. Tax: simple exclusive rate (`store_settings.tax.rate_percent`).
8. Not production-ready until `TESTING.md` sections B–D are green on a live deployment.


## 9. Follow-up packaging correction
- Updated `README.md` to remove contradictory Phase 1 claims and describe the V1.1 repair status and remaining limitations accurately.
- Updated `TESTING.md` to reflect the missing lockfile and the required follow-up.
- Updated `.github/workflows/ci.yml` so the web job no longer invokes `npm ci` without a lockfile, and removed the invalid npm cache dependency path. The workflow temporarily uses `npm install --no-audit --no-fund`.
- **Not done:** a valid `package-lock.json` could not be generated because the npm registry was unreachable. Do not fabricate a lockfile. Generate it with `npm install` on a network-connected machine, commit it, then restore `npm ci` and npm caching.


## CI follow-up (archive packaging pass)

- Updated the web CI install step to prefer `npm ci` when `web/package-lock.json` is present.
- Added an explicit warning and `npm install` fallback while the lockfile is absent.
- Updated README instructions to match this conditional behavior.
- A real `package-lock.json` was not fabricated: the npm registry was unreachable in the repair environment. Generate it with `npm install` from `web/` on a network-connected machine and commit it.

## 10. Follow-up validation (2026-10-31)
- Re-ran `python3 scripts/check-migrations.py`: passed (75 tables, 46 functions; static only).
- Re-ran `node scripts/syntax-check.mjs`: passed (37 TS/TSX files, 0 syntax diagnostics; not a full typecheck).
- Re-ran `cd web && node scripts/prerender.test.mjs`: passed (11 pages; all assertions passed).
- Parsed `web/package.json` and `.github/workflows/ci.yml`; both parsed successfully.
- Attempted `npm install --no-audit --no-fund` from `web/`; it timed out after 120 seconds. No lockfile was generated.
- PostgreSQL, Deno, Stripe and browser tests remain unexecuted. See `CI-STATUS.md` and `TESTING.md`.

## Additional V1.1 hardening — public product cost confidentiality

- Added `0007_public_product_column_security.sql`: revokes table-wide browser SELECT on `products`, grants only the storefront-safe columns, and replaces `search_products` (previously `SETOF products`) with an explicit safe projection that excludes `cost_price`.
- Replaced storefront and admin product `select("*")` requests with explicit column projections.
- Added two pgTAP regression assertions proving `anon` and `authenticated` cannot SELECT `products.cost_price`.
- This migration and the pgTAP assertions are written but still require execution on PostgreSQL/Supabase; static checks do not prove runtime behavior.


## 11. Documentation reconciliation (2026-11-01)
- Reconciled the migration inventory to `0001`–`0007`.
- Reconciled the Edge Function inventory to 12 functions, including `unsubscribe`.
- Reconciled pgTAP planned assertions to 56 (11 RLS + 26 checkout + 19 security).
- Removed the stale statement that public product `cost_price` exposure remained in storefront queries; migration 0007 and the static checker address the code-level exposure, pending PostgreSQL execution.
- Corrected deployment guidance: scheduling is described through Supabase Cron/Scheduled Functions with `x-cron-secret`; removed unsupported `supabase functions schedule` CLI commands.

## Follow-up TypeScript fixes (2026-11-01)

Fixed the TypeScript errors reported by the ZIP Runner workflow:

- `web/src/components/Analytics.tsx`: widened `window.dataLayer` to accept both queued argument arrays and event objects; gave Meta and TikTok pixel queue functions explicit non-optional local types before assigning them to `window`.
- `web/src/lib/supabase.ts`: narrowed the locale lookup to `keyof Localized` before indexing localized content.
- `web/src/components/PopupEngine.tsx`: removed the unused cart-count variable.
- `web/src/pages/automations-admin.tsx`: removed the unused `ACTION_TYPES` constant.
- `web/src/pages/storefront.tsx`: replaced a filter that did not narrow an optional product with `flatMap`, so each rendered cart row has a defined product.

Validation performed in this repair environment:

- 37 TypeScript/TSX files parsed: 0 syntax errors.
- Static migration checker: passed (75 tables, 46 functions detected).
- Static public product-column check: passed.
- Full dependency installation and `tsc`/Vite build could not be completed here because npm dependency installation timed out. Run the supplied GitHub Actions workflow to perform the full dependency-backed typecheck and build.
- No Supabase database, Stripe, webhook, or live checkout tests were run.
