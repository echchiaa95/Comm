// Executes prerender.mjs against a local fake PostgREST (two stores, three languages) and asserts the output.
// Run: node scripts/prerender.test.mjs   (no network, no dependencies)
import http from "node:http";
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, existsSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawn } from "node:child_process";
import assert from "node:assert/strict";

const S1 = "11111111-1111-1111-1111-111111111111", S2 = "22222222-2222-2222-2222-222222222222";
const data = {
  stores: [
    { id: S1, slug: "noura", name: "Noura Boutique", description: "Fashion", default_locale: "ar", default_currency: "MAD", settings: { extra_locales: ["en", "fr"] } },
    { id: S2, slug: "kitab", name: "Kitab Shop", description: "Books", default_locale: "en", default_currency: "USD", settings: {} },
  ],
  store_domains: [{ store_id: S2, domain: "books.example.org", is_primary: true, verified: true }],
  products: [
    { store_id: S1, id: "p1", slug: "linen-shirt", name: { en: "Linen Shirt", fr: "Chemise en lin", ar: "قميص كتان" }, description: { en: "Breathable", ar: "كتان فاخر" }, price: 349, currency: "MAD", sku: "S1", inventory_qty: 5, track_inventory: true, rating_count: 0 },
    { store_id: S2, id: "p2", slug: "novel", name: { en: "A <Novel>" }, description: { en: "Story" }, price: 12, currency: "USD", inventory_qty: 0, track_inventory: false, rating_count: 3, rating_avg: 4.5 },
  ],
  product_images: [{ store_id: S1, product_id: "p1", url: "https://img.example/shirt.jpg", position: 0, is_primary: true }],
  categories: [{ store_id: S1, id: "c1", slug: "apparel", name: { en: "Apparel", ar: "ملابس" }, description: { en: "Clothes" } }],
  store_pages: [], blog_posts: [], seo_metadata: [],
};
const srv = http.createServer((req, res) => {
  const u = new URL(req.url, "http://x"); const table = u.pathname.split("/").pop();
  let rows = data[table] ?? [];
  const sid = u.searchParams.get("store_id"); if (sid) rows = rows.filter((r) => r.store_id === sid.replace("eq.", ""));
  const slug = u.searchParams.get("slug"); if (slug) rows = rows.filter((r) => r.slug === slug.replace("eq.", ""));
  res.setHeader("content-type", "application/json"); res.end(JSON.stringify(rows));
});
await new Promise((r) => srv.listen(0, r));
const dist = mkdtempSync(join(tmpdir(), "prr-")); mkdirSync(dist, { recursive: true });
writeFileSync(join(dist, "index.html"), `<!doctype html><html lang="en" dir="ltr"><head><meta charset="UTF-8"><title>Store</title></head><body><div id="root"></div></body></html>`);
const r = await new Promise((resolve) => {
  const c = spawn("node", ["scripts/prerender.mjs"], { env: { ...process.env, SUPABASE_URL: `http://127.0.0.1:${srv.address().port}`, SUPABASE_SERVICE_ROLE_KEY: "test", PLATFORM_DOMAIN: "shops.test", DIST_DIR: dist } });
  let out = ""; c.stdout.on("data", (d) => (out += d)); c.stderr.on("data", (d) => (out += d));
  const t = setTimeout(() => { c.kill(); resolve({ status: -1, stdout: out, stderr: "timeout" }); }, 30000);
  c.on("close", (code) => { clearTimeout(t); resolve({ status: code, stdout: out, stderr: "" }); });
});
srv.close(); console.log(r.stdout, r.stderr);
assert.equal(r.status, 0, "prerender exit code");

const ar = readFileSync(join(dist, "_prerender/noura.shops.test/product/linen-shirt/index.html"), "utf8");   // default locale (ar) = unprefixed
const fr = readFileSync(join(dist, "_prerender/noura.shops.test/fr/product/linen-shirt/index.html"), "utf8");
const en2 = readFileSync(join(dist, "_prerender/books.example.org/product/novel/index.html"), "utf8");
assert.match(ar, /<html lang="ar" dir="rtl">/); assert.match(fr, /<html lang="fr" dir="ltr">/);
assert.match(ar, /<link rel="canonical" href="https:\/\/noura\.shops\.test\/product\/linen-shirt">/);
assert.match(fr, /<link rel="canonical" href="https:\/\/noura\.shops\.test\/fr\/product\/linen-shirt">/);
assert.match(ar, /hreflang="fr" href="https:\/\/noura\.shops\.test\/fr\/product\/linen-shirt"/);
assert.match(ar, /hreflang="en" href="https:\/\/noura\.shops\.test\/en\/product\/linen-shirt"/);
assert.match(ar, /hreflang="x-default" href="https:\/\/noura\.shops\.test\/product\/linen-shirt"/);
assert.match(fr, /<title>Chemise en lin — Noura Boutique<\/title>/);
assert.match(ar, /"@type":"Product"/); assert.match(ar, /og:image" content="https:\/\/img\.example\/shirt\.jpg"/);
assert.match(ar, /<div id="root"><main><article><h1>قميص كتان<\/h1>/);
assert.match(en2, /https:\/\/books\.example\.org\/product\/novel/); assert.match(en2, /A &lt;Novel&gt;/); assert.doesNotMatch(en2, /hreflang="fr"/);
assert.match(en2, /OutOfStock|InStock/); assert.equal((en2.match(/application\/ld\+json/g) ?? []).length, 1);
assert.ok(!existsSync(join(dist, "_prerender/noura.shops.test/admin")), "admin must never be prerendered");
console.log("prerender.test: all assertions passed");
