#!/usr/bin/env node
// Multi-store, multi-language prerendering (static HTML with full SEO metadata, written after `vite build`).
//   SUPABASE_URL=… SUPABASE_SERVICE_ROLE_KEY=… PLATFORM_DOMAIN=shops.example.com node scripts/prerender.mjs
//   optional: STORE_SLUG=noura (single store) · DIST_DIR=dist
// For EVERY active store with a public host (verified custom domain → <slug>.PLATFORM_DOMAIN) and EVERY locale of that
// store, it writes  <DIST_DIR>/_prerender/<host>/[<locale>/]<route>/index.html  containing: <html lang dir>, title,
// meta description, canonical, reciprocal hreflang + x-default, Open Graph/Twitter, JSON-LD (one block per page),
// and crawlable product/category/page content inside #root (React replaces it on load).
// Serve rule (CDN/edge): host H, path P → try /_prerender/H/P/index.html, else fall back to the SPA /index.html.
// The service key is read at BUILD time only (CI secret); it is never shipped to browsers. Only PUBLIC rows are read.
import { readFileSync, writeFileSync, mkdirSync, readdirSync, statSync } from "node:fs";
import { dirname, join } from "node:path";

const URL_ = process.env.SUPABASE_URL;
const KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const PLATFORM = (process.env.PLATFORM_DOMAIN ?? "").toLowerCase();
const ONLY = process.env.STORE_SLUG;
const DIST = process.env.DIST_DIR ?? "dist";
if (!URL_ || !KEY) { console.error("Missing SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY"); process.exit(1); }

const h = { apikey: KEY, Authorization: `Bearer ${KEY}` };
async function q(path) {
  const r = await fetch(`${URL_}/rest/v1/${path}`, { headers: h });
  if (!r.ok) throw new Error(`${path}: ${r.status} ${await r.text()}`);
  return r.json();
}
const esc = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const ld = (o) => JSON.stringify(o).replace(/</g, "\\u003c");
const L = (v, locale) => (typeof v === "string" ? v : v?.[locale] ?? v?.en ?? Object.values(v ?? {}).find(Boolean) ?? "");
const clip = (s, n) => { const t = String(s ?? "").replace(/\s+/g, " ").trim(); return t.length > n ? t.slice(0, n - 1).trimEnd() + "…" : t; };
const template = readFileSync(join(DIST, "index.html"), "utf8");

let pagesWritten = 0;
const problems = [];

function render(host, store, locale, locales, route, page) {
  const def = store.default_locale;
  const base = `https://${host}`;
  const pathFor = (l) => `${l === def ? "" : `/${l}`}${route === "/" ? (l === def ? "/" : "") : route}`;
  const canonical = base + pathFor(locale);
  const title = clip(page.title, 70), description = clip(page.description, 160);
  if (!title) { problems.push(`${host}${route} [${locale}]: empty title — page skipped`); return; }
  const dir = locale === "ar" ? "rtl" : "ltr";
  const alt = page.noindex ? "" : locales.map((l) => `<link rel="alternate" hreflang="${l}" href="${esc(base + pathFor(l))}">`).join("\n    ") +
    `\n    <link rel="alternate" hreflang="x-default" href="${esc(base + pathFor(def))}">`;
  const head = `
    <title>${esc(title)}</title>
    ${description ? `<meta name="description" content="${esc(description)}">` : ""}
    <link rel="canonical" href="${esc(canonical)}">
    ${page.noindex ? `<meta name="robots" content="noindex,follow">` : ""}
    ${alt}
    <meta property="og:site_name" content="${esc(store.name)}">
    <meta property="og:type" content="${page.ogType ?? "website"}">
    <meta property="og:title" content="${esc(title)}">
    ${description ? `<meta property="og:description" content="${esc(description)}">` : ""}
    <meta property="og:url" content="${esc(canonical)}">
    <meta property="og:locale" content="${locale}">
    ${page.image ? `<meta property="og:image" content="${esc(page.image)}">` : ""}
    <meta name="twitter:card" content="${page.image ? "summary_large_image" : "summary"}">
    ${page.jsonLd ? `<script type="application/ld+json">${ld(page.jsonLd)}</script>` : ""}`;
  let out = template
    .replace(/<html[^>]*>/i, `<html lang="${locale}" dir="${dir}">`)
    .replace(/<title>[^<]*<\/title>/i, "")
    .replace("</head>", `${head}\n  </head>`)
    .replace('<div id="root"></div>', `<div id="root">${page.bodyHtml ?? ""}</div>`);
  const file = join(DIST, "_prerender", host, locale === def ? "" : locale, route === "/" ? "" : route, "index.html");
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, out);
  pagesWritten++;
}

const stores = await q(`stores?status=in.(active,trial)${ONLY ? `&slug=eq.${encodeURIComponent(ONLY)}` : ""}&select=id,slug,name,description,default_locale,default_currency,settings,logo_url`);
for (const store of stores) {
  const doms = await q(`store_domains?store_id=eq.${store.id}&verified=eq.true&select=domain,is_primary&order=is_primary.desc`);
  const host = doms[0]?.domain ?? (PLATFORM ? `${store.slug}.${PLATFORM}` : null);
  if (!host) { problems.push(`store ${store.slug}: no verified domain and no PLATFORM_DOMAIN — skipped`); continue; }
  const extra = Array.isArray(store.settings?.extra_locales) ? store.settings.extra_locales : [];
  const locales = [...new Set([store.default_locale, ...extra])].filter((l) => ["en", "fr", "ar"].includes(l));
  const sid = store.id;
  const seoRows = await q(`seo_metadata?store_id=eq.${sid}&select=entity_type,entity_id,locale,title,meta_description,robots`);
  const seo = (type, id, locale) => seoRows.find((r) => r.entity_type === type && r.entity_id === id && r.locale === locale) ?? {};
  const products = await q(`products?store_id=eq.${sid}&status=eq.active&select=id,slug,name,short_description,description,price,currency,sku,rating_avg,rating_count,inventory_qty,track_inventory,updated_at&limit=5000`);
  const images = await q(`product_images?store_id=eq.${sid}&select=product_id,url,position,is_primary&order=position.asc&limit=20000`);
  const categories = await q(`categories?store_id=eq.${sid}&is_active=eq.true&select=id,slug,name,description&limit=1000`);
  const pages = await q(`store_pages?store_id=eq.${sid}&status=eq.published&select=id,slug,title,content&limit=1000`);
  const posts = await q(`blog_posts?store_id=eq.${sid}&status=eq.published&select=id,slug,title,excerpt,content,updated_at,published_at&limit=5000`);

  for (const locale of locales) {
    const base = `https://${host}`;
    const pathFor = (r) => `${locale === store.default_locale ? "" : `/${locale}`}${r}`;
    const orgLd = { "@context": "https://schema.org", "@type": "Organization", name: store.name, url: base + (locale === store.default_locale ? "/" : `/${locale}`), ...(store.logo_url ? { logo: store.logo_url } : {}) };
    render(host, store, locale, locales, "/", {
      title: store.name, description: L(store.description, locale), jsonLd: orgLd,
      bodyHtml: `<main><h1>${esc(store.name)}</h1><p>${esc(L(store.description, locale))}</p></main>` });

    for (const p of products) {
      const s = seo("product", p.id, locale);
      const name = L(p.name, locale);
      const desc = s.meta_description || L(p.short_description, locale) || L(p.description, locale);
      const img = images.find((i) => i.product_id === p.id && i.is_primary) ?? images.find((i) => i.product_id === p.id);
      const price = Number(p.price);
      if (!name || !(price >= 0)) { problems.push(`product ${p.slug}: missing name/price — skipped`); continue; }
      const inStock = !p.track_inventory || p.inventory_qty > 0;
      const jsonLd = { "@context": "https://schema.org", "@type": "Product", name, ...(p.sku ? { sku: p.sku } : {}),
        description: clip(L(p.description, locale) || desc, 500), brand: { "@type": "Brand", name: store.name },
        ...(img ? { image: [img.url] } : {}),
        offers: { "@type": "Offer", price: price.toFixed(2), priceCurrency: p.currency ?? store.default_currency,
          availability: inStock ? "https://schema.org/InStock" : "https://schema.org/OutOfStock", url: base + pathFor(`/product/${p.slug}`) },
        ...(p.rating_count > 0 ? { aggregateRating: { "@type": "AggregateRating", ratingValue: Number(p.rating_avg), reviewCount: p.rating_count } } : {}) };
      render(host, store, locale, locales, `/product/${p.slug}`, {
        title: s.title || `${name} — ${store.name}`, description: desc, jsonLd, ogType: "product", image: img?.url, noindex: String(s.robots ?? "").includes("noindex"),
        bodyHtml: `<main><article><h1>${esc(name)}</h1>${img ? `<img src="${esc(img.url)}" alt="${esc(name)}">` : ""}<p>${esc(L(p.description, locale))}</p><p>${price.toFixed(2)} ${esc(p.currency ?? store.default_currency)}</p></article></main>` });
    }
    for (const c of categories) {
      const s = seo("category", c.id, locale), name = L(c.name, locale);
      render(host, store, locale, locales, `/category/${c.slug}`, {
        title: s.title || `${name} — ${store.name}`, description: s.meta_description || L(c.description, locale) || L(store.description, locale),
        noindex: String(s.robots ?? "").includes("noindex"), bodyHtml: `<main><h1>${esc(name)}</h1><p>${esc(L(c.description, locale))}</p></main>` });
    }
    for (const pg of pages) {
      const s = seo("page", pg.id, locale), name = L(pg.title, locale);
      render(host, store, locale, locales, `/page/${pg.slug}`, {
        title: s.title || `${name} — ${store.name}`, description: s.meta_description || clip(L(pg.content, locale), 160),
        noindex: String(s.robots ?? "").includes("noindex"), bodyHtml: `<main><h1>${esc(name)}</h1><div>${esc(L(pg.content, locale))}</div></main>` });
    }
    for (const b of posts) {
      const s = seo("blog_post", b.id, locale), name = L(b.title, locale);
      render(host, store, locale, locales, `/blog/${b.slug}`, {
        title: s.title || `${name} — ${store.name}`, description: s.meta_description || L(b.excerpt, locale), ogType: "article",
        noindex: String(s.robots ?? "").includes("noindex"),
        jsonLd: { "@context": "https://schema.org", "@type": "Article", headline: name, datePublished: b.published_at ?? undefined, dateModified: b.updated_at, author: { "@type": "Organization", name: store.name }, mainEntityOfPage: base + pathFor(`/blog/${b.slug}`) },
        bodyHtml: `<main><article><h1>${esc(name)}</h1><div>${esc(L(b.content, locale))}</div></article></main>` });
    }
  }
}

// ── Output validation: every generated page must be structurally sound ───────────────────────────────────────
function* walk(d) { for (const n of readdirSync(d)) { const p = join(d, n); statSync(p).isDirectory() ? yield* walk(p) : yield p; } }
let checked = 0;
try {
  for (const f of walk(join(DIST, "_prerender"))) {
    if (!f.endsWith("index.html")) continue;
    checked++;
    const html = readFileSync(f, "utf8");
    const count = (re) => (html.match(re) ?? []).length;
    if (count(/<title>/g) !== 1) problems.push(`${f}: expected exactly 1 <title>`);
    if (count(/rel="canonical"/g) !== 1) problems.push(`${f}: expected exactly 1 canonical`);
    if (count(/application\/ld\+json/g) > 1) problems.push(`${f}: duplicated structured data`);
    if (!/<html lang="(en|fr|ar)" dir="(ltr|rtl)">/.test(html)) problems.push(`${f}: missing lang/dir`);
    if (/lang="ar" dir="ltr"|lang="(en|fr)" dir="rtl"/.test(html)) problems.push(`${f}: wrong dir for language`);
    const m = html.match(/<script type="application\/ld\+json">(.*?)<\/script>/s);
    if (m) { try { JSON.parse(m[1]); } catch { problems.push(`${f}: invalid JSON-LD`); } }
    if (/<meta name="description" content="">/.test(html)) problems.push(`${f}: empty meta description`);
  }
} catch { /* no pages written */ }
console.log(`Prerendered ${pagesWritten} pages, validated ${checked}.`);
for (const p of problems) console.log("PROBLEM:", p);
process.exit(problems.some((p) => !p.endsWith("skipped")) ? 1 : 0);
