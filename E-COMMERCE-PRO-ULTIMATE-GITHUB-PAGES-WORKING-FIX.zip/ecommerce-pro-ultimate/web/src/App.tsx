import { lazy, Suspense } from "react";
import { Routes, Route, Link } from "react-router-dom";
import { useTenant } from "./lib/tenant";
import { RequireAuth, RequirePermission } from "./lib/guards";
import StorefrontLayout from "./layouts/Storefront";
import AdminLayout from "./layouts/Admin";
import Login from "./pages/Login";
import StoreSetup from "./pages/setup";

const Home = lazy(() => import("./pages/storefront").then((m) => ({ default: m.Home })));
const CategoryPage = lazy(() => import("./pages/storefront").then((m) => ({ default: m.CategoryPage })));
const ProductPage = lazy(() => import("./pages/storefront").then((m) => ({ default: m.ProductPage })));
const SearchPage = lazy(() => import("./pages/storefront").then((m) => ({ default: m.SearchPage })));
const StaticPage = lazy(() => import("./pages/storefront").then((m) => ({ default: m.StaticPage })));
const BlogPage = lazy(() => import("./pages/storefront").then((m) => ({ default: m.BlogPage })));
const CartPage = lazy(() => import("./pages/storefront").then((m) => ({ default: m.CartPage })));
const CheckoutPage = lazy(() => import("./pages/storefront").then((m) => ({ default: m.CheckoutPage })));
const OrderSuccess = lazy(() => import("./pages/storefront").then((m) => ({ default: m.OrderSuccess })));

const Dashboard = lazy(() => import("./pages/admin").then((m) => ({ default: m.Dashboard })));
const ProductsAdmin = lazy(() => import("./pages/admin").then((m) => ({ default: m.ProductsAdmin })));
const OrdersAdmin = lazy(() => import("./pages/admin").then((m) => ({ default: m.OrdersAdmin })));
const ModulePage = lazy(() => import("./pages/admin").then((m) => ({ default: m.ModulePage })));
const PopupBuilder = lazy(() => import("./pages/popups-admin").then((m) => ({ default: m.PopupBuilder })));
const PaymentsAdmin = lazy(() => import("./pages/payments-admin").then((m) => ({ default: m.PaymentsAdmin })));
const CustomerDownloads = lazy(() => import("./pages/downloads").then((m) => ({ default: m.CustomerDownloads })));
const AccountPage = lazy(() => import("./pages/account").then((m) => ({ default: m.AccountPage })));
const AutomationsAdmin = lazy(() => import("./pages/automations-admin").then((m) => ({ default: m.AutomationsAdmin })));
const EmailTemplatesAdmin = lazy(() => import("./pages/email-templates-admin").then((m) => ({ default: m.EmailTemplatesAdmin })));
const ReviewsAdmin = lazy(() => import("./pages/reviews-admin").then((m) => ({ default: m.ReviewsAdmin })));
const AffiliatesAdmin = lazy(() => import("./pages/affiliates-admin").then((m) => ({ default: m.AffiliatesAdmin })));
const CampaignsAdmin = lazy(() => import("./pages/campaigns-admin").then((m) => ({ default: m.CampaignsAdmin })));

function Suspended({ children }: { children: React.ReactNode }) {
  return (
    <Suspense
      fallback={
        <div className="p-8 space-y-4">
          {[...Array(4)].map((_, i) => <div key={i} className="skeleton h-24" />)}
        </div>
      }
    >
      {children}
    </Suspense>
  );
}

export default function App() {
  const { loading, store } = useTenant();
  if (loading) return <div className="min-h-screen grid place-items-center"><div className="skeleton h-40 w-72" /></div>;
  if (!store) {
    // No store resolved for this host: only the login and the store-creation wizard are reachable.
    return (
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/admin/setup" element={<RequireAuth><StoreSetup /></RequireAuth>} />
        <Route
          path="*"
          element={
            <div className="min-h-screen grid place-items-center p-6 text-center">
              <div>
                <h1 className="text-2xl font-bold mb-2">Store not found</h1>
                <p className="text-slate-500">Check the domain or create a store from the wizard.</p>
                <Link to="/admin/setup" className="brand-primary text-white px-5 py-2 rounded-lg inline-block mt-4">Create your store</Link>
              </div>
            </div>
          }
        />
      </Routes>
    );
  }
  return (
    <Routes>
      <Route element={<StorefrontLayout />}>
        <Route index element={<Suspended><Home /></Suspended>} />
        <Route path="category/:slug" element={<Suspended><CategoryPage /></Suspended>} />
        <Route path="product/:slug" element={<Suspended><ProductPage /></Suspended>} />
        <Route path="search" element={<Suspended><SearchPage /></Suspended>} />
        <Route path="page/:slug" element={<Suspended><StaticPage /></Suspended>} />
        <Route path="blog/:slug" element={<Suspended><BlogPage /></Suspended>} />
        <Route path="cart" element={<Suspended><CartPage /></Suspended>} />
        <Route path="checkout" element={<Suspended><CheckoutPage /></Suspended>} />
        <Route path="order/:id/success" element={<Suspended><OrderSuccess /></Suspended>} />
        <Route path="downloads" element={<Suspended><CustomerDownloads /></Suspended>} />
        <Route path="account" element={<Suspended><AccountPage /></Suspended>} />
      </Route>
      <Route path="/login" element={<Login />} />
      <Route path="/admin/setup" element={<RequireAuth><StoreSetup /></RequireAuth>} />
      <Route path="/admin" element={<RequireAuth><AdminLayout /></RequireAuth>}>
        <Route index element={<Suspended><Dashboard /></Suspended>} />
        <Route path="products" element={<RequirePermission permission="products.manage"><Suspended><ProductsAdmin /></Suspended></RequirePermission>} />
        <Route path="orders" element={<RequirePermission permission="orders.manage"><Suspended><OrdersAdmin /></Suspended></RequirePermission>} />
        <Route path="popups" element={<RequirePermission permission="marketing.manage"><Suspended><PopupBuilder /></Suspended></RequirePermission>} />
        <Route path="payments" element={<RequirePermission permission="store.manage"><Suspended><PaymentsAdmin /></Suspended></RequirePermission>} />
        <Route path="automations" element={<RequirePermission permission="marketing.manage"><Suspended><AutomationsAdmin /></Suspended></RequirePermission>} />
        <Route path="email-templates" element={<RequirePermission permission="marketing.manage"><Suspended><EmailTemplatesAdmin /></Suspended></RequirePermission>} />
        <Route path="reviews" element={<RequirePermission permission="customers.manage"><Suspended><ReviewsAdmin /></Suspended></RequirePermission>} />
        <Route path="affiliates" element={<RequirePermission permission="marketing.manage"><Suspended><AffiliatesAdmin /></Suspended></RequirePermission>} />
        <Route path="campaigns" element={<RequirePermission permission="marketing.manage"><Suspended><CampaignsAdmin /></Suspended></RequirePermission>} />
        <Route path=":section" element={<RequirePermission permission="store.manage"><Suspended><ModulePage /></Suspended></RequirePermission>} />
      </Route>
    </Routes>
  );
}
