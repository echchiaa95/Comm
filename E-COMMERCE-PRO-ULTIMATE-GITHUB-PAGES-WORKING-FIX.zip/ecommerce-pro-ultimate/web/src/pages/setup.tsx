import { useState } from "react";
import { supabase } from "@/lib/supabase";

type Form = {
  name: string; slug: string; business_model: "physical" | "digital" | "hybrid"; country: string; city: string;
  currency: string; default_locale: "en" | "fr" | "ar"; contact_email: string; whatsapp_number: string; category: string;
};

const slugify = (s: string) => s.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60);

// Store creation wizard. Calls the create-store Edge Function (JWT-authenticated, validated server-side);
// the database trigger then configures payments/shipping/templates for the chosen business model.
export default function StoreSetup() {
  const [f, setF] = useState<Form>({ name: "", slug: "", business_model: "physical", country: "", city: "", currency: "USD", default_locale: "en", contact_email: "", whatsapp_number: "", category: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [created, setCreated] = useState<{ slug: string; name: string } | null>(null);
  const set = (k: keyof Form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setF((p) => ({ ...p, [k]: e.target.value, ...(k === "name" && !p.slug ? { slug: slugify(e.target.value) } : {}) }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null);
    const { data: { session } } = await supabase.auth.getSession();
    const body: Record<string, string> = {};
    (Object.keys(f) as (keyof Form)[]).forEach((k) => { if (f[k] !== "") body[k] = f[k]; });
    if (body.country) body.country = body.country.toUpperCase();
    const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-store`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: import.meta.env.VITE_SUPABASE_ANON_KEY as string,
        Authorization: `Bearer ${session?.access_token ?? ""}`,
      },
      body: JSON.stringify(body),
    });
    const json = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      const slugErr = json?.error?.slug?.[0];
      setError(slugErr === "already_taken" ? "This store address is already taken." : typeof json.error === "string" ? json.error : "Check the form fields and try again.");
      return;
    }
    localStorage.setItem("epu_store_slug", json.store.slug);   // dev/localhost: remember which store to open
    setCreated({ slug: json.store.slug, name: json.store.name });
  }

  if (created) {
    return (
      <div className="min-h-screen grid place-items-center p-6">
        <div className="max-w-md text-center space-y-3">
          <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 grid place-items-center text-2xl mx-auto">✓</div>
          <h1 className="text-2xl font-bold">{created.name} is ready</h1>
          <p className="text-slate-500 text-sm">
            Open it on your platform address <code>{created.slug}.&lt;your-platform-domain&gt;</code>, or connect a custom domain from Admin → Settings.
          </p>
          <button className="brand-primary text-white px-5 py-2 rounded-lg" onClick={() => window.location.assign("/admin")}>Go to admin</button>
        </div>
      </div>
    );
  }

  const input = "border border-slate-300 rounded-lg px-3 py-2 w-full";
  return (
    <div className="min-h-screen grid place-items-center p-6">
      <form onSubmit={submit} className="w-full max-w-lg bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
        <h1 className="text-2xl font-bold">Create your store</h1>
        <input required minLength={2} maxLength={120} placeholder="Store name" value={f.name} onChange={set("name")} className={input} />
        <input required pattern="[a-z0-9][a-z0-9-]{1,59}" placeholder="store-address (letters, digits, dashes)" value={f.slug} onChange={set("slug")} className={input} />
        <div className="grid grid-cols-2 gap-3">
          <select value={f.business_model} onChange={set("business_model")} className={input}>
            <option value="physical">Physical products</option>
            <option value="digital">Digital products</option>
            <option value="hybrid">Both</option>
          </select>
          <select value={f.default_locale} onChange={set("default_locale")} className={input}>
            <option value="en">English</option><option value="fr">Français</option><option value="ar">العربية</option>
          </select>
          <input maxLength={2} placeholder="Country (e.g. MA)" value={f.country} onChange={set("country")} className={input} />
          <input placeholder="City" value={f.city} onChange={set("city")} className={input} />
          <input required minLength={3} maxLength={3} placeholder="Currency (e.g. MAD)" value={f.currency} onChange={set("currency")} className={input} />
          <input placeholder="Category" value={f.category} onChange={set("category")} className={input} />
        </div>
        <input type="email" placeholder="Contact email" value={f.contact_email} onChange={set("contact_email")} className={input} />
        <input placeholder="WhatsApp number (optional)" value={f.whatsapp_number} onChange={set("whatsapp_number")} className={input} />
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button disabled={busy} className="w-full brand-primary text-white rounded-xl py-3 font-bold disabled:opacity-60">{busy ? "…" : "Create store"}</button>
      </form>
    </div>
  );
}
