import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { useTenant } from "@/lib/tenant";

export function CampaignsAdmin() {
  const { store, fmtMoney } = useTenant();
  const qc = useQueryClient();
  const [f, setF] = useState({ name: "", channel: "email", source: "", medium: "", content: "", budget: "", starts: "", ends: "" });
  const [utm, setUtm] = useState({ url: "", source: "", medium: "", campaign: "", content: "" });
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { data: campaigns } = useQuery({
    queryKey: ["campaigns", store!.id],
    queryFn: async () => (await supabase.from("campaigns").select("*").eq("store_id", store!.id).order("created_at", { ascending: false })).data ?? [],
  });
  const { data: events } = useQuery({
    queryKey: ["campaigned", store!.id],
    queryFn: async () => (await supabase.from("campaign_events").select("campaign_id, event_type, amount").eq("store_id", store!.id)).data ?? [],
  });
  const invalidate = () => qc.invalidateQueries({ queryKey: ["campaigns"] });

  const create = useMutation({
    mutationFn: async () => {
      setError(null);
      const { error } = await supabase.from("campaigns").insert({
        store_id: store!.id, name: f.name, channel: f.channel,
        source: f.source || null, medium: f.medium || null, content: f.content || null,
        budget: f.budget ? Number(f.budget) : 0,
        status: f.starts || f.ends ? "scheduled" : "active",
        starts_at: f.starts || null, ends_at: f.ends || null,
      });
      if (error) throw new Error(error.message);
    },
    onSuccess: () => { invalidate(); setF({ name: "", channel: "email", source: "", medium: "", content: "", budget: "", starts: "", ends: "" }); },
    onError: (e) => setError((e as Error).message),
  });

  const statsFor = (id: string) => {
    const rows = (events ?? []).filter((e: any) => e.campaign_id === id);
    return {
      clicks: rows.filter((e: any) => e.event_type === "click").length,
      orders: rows.filter((e: any) => e.event_type === "order").length,
      revenue: rows.filter((e: any) => e.event_type === "order").reduce((s: number, e: any) => s + Number(e.amount ?? 0), 0),
    };
  };

  const builtUtm = (() => {
    if (!utm.url) return "";
    const u = new URL(utm.url.startsWith("http") ? utm.url : `https://${utm.url}`);
    if (utm.source) u.searchParams.set("utm_source", utm.source);
    if (utm.medium) u.searchParams.set("utm_medium", utm.medium);
    if (utm.campaign) u.searchParams.set("utm_campaign", utm.campaign);
    if (utm.content) u.searchParams.set("utm_content", utm.content);
    return u.toString();
  })();

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF((x) => ({ ...x, [k]: e.target.value }));
  const setU = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => setUtm((x) => ({ ...x, [k]: e.target.value }));

  return (
    <div className="p-8 space-y-8 max-w-5xl">
      <h1 className="text-2xl font-bold">Marketing Center — Campaigns</h1>

      <form onSubmit={(e) => { e.preventDefault(); create.mutate(); }} className="bg-white rounded-2xl border border-slate-200 p-6 grid sm:grid-cols-4 gap-3">
        <input required placeholder="Campaign name" value={f.name} onChange={set("name")} className="sm:col-span-2 border border-slate-300 rounded-lg px-3 py-2" />
        <select value={f.channel} onChange={set("channel")} className="border border-slate-300 rounded-lg px-3 py-2">
          {["email", "whatsapp", "social", "ads", "affiliate", "other"].map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <input type="number" min={0} placeholder="Budget" value={f.budget} onChange={set("budget")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <input placeholder="utm_source" value={f.source} onChange={set("source")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <input placeholder="utm_medium" value={f.medium} onChange={set("medium")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <input placeholder="utm_content" value={f.content} onChange={set("content")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <input type="date" value={f.starts} onChange={set("starts")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <input type="date" value={f.ends} onChange={set("ends")} className="sm:col-span-3 border border-slate-300 rounded-lg px-3 py-2" />
        {error && <p className="sm:col-span-4 text-sm text-red-600">{error}</p>}
        <button disabled={create.isPending} className="sm:col-span-4 brand-primary text-white rounded-lg py-2.5 font-semibold w-48 disabled:opacity-60">
          {create.isPending ? "Saving…" : "Create campaign"}
        </button>
      </form>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-slate-200 bg-slate-50">
            {["Campaign", "UTM", "Clicks", "Orders", "Revenue", "ROI", "Status"].map((h) => <th key={h} className="text-start font-semibold px-4 py-3 text-slate-600">{h}</th>)}
          </tr></thead>
          <tbody>
            {(campaigns ?? []).map((c: any) => {
              const s = statsFor(c.id);
              const roi = c.cost > 0 && s.revenue > 0 ? `${(((s.revenue - c.cost) / c.cost) * 100).toFixed(0)}%` : "—";
              return (
                <tr key={c.id} className="border-b border-slate-100 last:border-0">
                  <td className="px-4 py-3 font-medium">{c.name}<div className="text-xs text-slate-400">{c.channel}</div></td>
                  <td className="px-4 py-3 text-xs text-slate-400">{[c.source, c.medium, c.content].filter(Boolean).join(" / ") || "—"}</td>
                  <td className="px-4 py-3">{s.clicks}</td>
                  <td className="px-4 py-3">{s.orders}</td>
                  <td className="px-4 py-3 font-semibold">{fmtMoney(s.revenue)}</td>
                  <td className="px-4 py-3">{roi}</td>
                  <td className="px-4 py-3"><span className="text-xs rounded-full px-2 py-0.5 bg-slate-100 text-slate-600">{c.status}</span></td>
                </tr>
              );
            })}
            {!campaigns?.length && <tr><td colSpan={7} className="px-4 py-10 text-center text-slate-400">No campaigns yet</td></tr>}
          </tbody>
        </table>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <h2 className="font-bold mb-3">UTM link builder</h2>
        <div className="grid sm:grid-cols-2 gap-3">
          <input placeholder="https://yourstore.com/product/x" value={utm.url} onChange={setU("url")} className="sm:col-span-2 border border-slate-300 rounded-lg px-3 py-2" />
          <input placeholder="utm_source (google, newsletter…)" value={utm.source} onChange={setU("source")} className="border border-slate-300 rounded-lg px-3 py-2" />
          <input placeholder="utm_medium (cpc, email…)" value={utm.medium} onChange={setU("medium")} className="border border-slate-300 rounded-lg px-3 py-2" />
          <input placeholder="utm_campaign (spring_sale)" value={utm.campaign} onChange={setU("campaign")} className="border border-slate-300 rounded-lg px-3 py-2" />
          <input placeholder="utm_content (optional)" value={utm.content} onChange={setU("content")} className="border border-slate-300 rounded-lg px-3 py-2" />
        </div>
        {builtUtm && (
          <div className="flex gap-2 mt-3">
            <input readOnly value={builtUtm} className="flex-1 border border-slate-200 rounded-lg px-3 py-2 text-xs bg-slate-50 font-mono" onFocus={(e) => e.target.select()} />
            <button onClick={() => { navigator.clipboard.writeText(builtUtm); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
              className="brand-primary text-white rounded-lg px-4 py-2 text-sm font-semibold">{copied ? "Copied ✓" : "Copy"}</button>
          </div>
        )}
      </div>
    </div>
  );
}
