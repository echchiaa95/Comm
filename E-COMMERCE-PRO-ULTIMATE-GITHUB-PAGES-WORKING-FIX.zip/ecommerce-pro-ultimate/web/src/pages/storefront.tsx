import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase, loc } from "@/lib/supabase";
import { useTenant } from "@/lib/tenant";
import { cart, useCart } from "@/lib/cart";

type Product = Record<string, any>;

// Public storefront projection. Never request products.*: cost_price is merchant-only.
const PUBLIC_PRODUCT_COLUMNS =
  "id,store_id,type,status,slug,sku,name,short_description,description,price,compare_at_price,currency,attributes,track_inventory,inventory_qty,low_stock_threshold,weight_grams,has_digital_files,license_key_product,rating_avg,rating_count,sales_count,published_at,created_at,updated_at";

function usePrimaryImages(ids: string[]) {
  return useQuery({
    queryKey: ["pimgs", ids.sort().join(",")],
    enabled: ids.length > 0,
    queryFn: async () => {
      const { data } = await supabase.from("product_images").select("product_id, url, alt")
        .in("product_id", ids).eq("is_primary", true);
      return Object.fromEntries((data ?? []).map((i: any) => [i.product_id, i]));
    },
  });
}

function money(p: Product, amount: number, locale: string) {
  return new Intl.NumberFormat(locale, { style: "currency", currency: p.currency ?? "USD" }).format(amount);
}

function ProductCard({ p, img, locale }: { p: Product; img?: { url: string; alt?: any }; locale: string }) {
  const { store } = useTenant();
  return (
    <Link to={`/product/${p.slug}`} className="group block">
      <div className="aspect-square rounded-xl bg-slate-100 overflow-hidden mb-3">
        {img?.url
          ? <img src={img.url} alt={loc(img.alt, locale) || loc(p.name, locale)} loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
          : <div className="w-full h-full grid place-items-center text-slate-300 text-4xl font-bold">{loc(p.name, locale)?.[0] ?? "P"}</div>}
      </div>
      <div className="font-semibold text-sm line-clamp-1">{loc(p.name, locale)}</div>
      <div className="mt-1 flex items-center gap-2 text-sm">
        <span className="brand-primary-text font-bold">{money(p, Number(p.price), locale)}</span>
        {p.compare_at_price && <span className="text-slate-400 line-through">{money(p, Number(p.compare_at_price), locale)}</span>}
      </div>
      {p.rating_count > 0 && <div className="text-xs text-amber-500 mt-0.5">★ {Number(p.rating_avg).toFixed(1)} ({p.rating_count})</div>}
      {store && null}
    </Link>
  );
}

function useProducts(key: string, fn: () => Promise<any>, enabled = true) {
  return useQuery({ queryKey: key.split("|"), queryFn: fn, enabled });
}

export function Home() {
  const { store, t, locale } = useTenant();
  const id = store!.id;
  const { data: banners } = useProducts(`banners|${id}`, async () =>
    (await supabase.from("store_banners").select("content, link").eq("store_id", id).eq("placement", "home_hero").eq("is_active", true).order("sort_order").limit(3)).data);
  const { data: categories } = useProducts(`cats|${id}`, async () =>
    (await supabase.from("categories").select("slug, name, image_url").eq("store_id", id).eq("is_active", true).order("position").limit(8)).data);
  const { data: featured } = useProducts(`feat|${id}`, async () =>
    (await supabase.from("products").select(PUBLIC_PRODUCT_COLUMNS).eq("store_id", id).eq("status", "active").order("sales_count", { ascending: false }).limit(8)).data ?? []);
  const { data: fresh } = useProducts(`new|${id}`, async () =>
    (await supabase.from("products").select(PUBLIC_PRODUCT_COLUMNS).eq("store_id", id).eq("status", "active").order("published_at", { ascending: false }).limit(8)).data ?? []);

  const ids = [...(featured ?? []), ...(fresh ?? [])].map((p: Product) => p.id);
  const { data: imgs } = usePrimaryImages(ids);

  return (
    <div>
      <section className="max-w-7xl mx-auto px-4 pt-8">
        <div className="grid md:grid-cols-3 gap-4">
          {(banners ?? []).map((b: any, i: number) => (
            <Link key={i} to={b.link ?? "#"} className={`rounded-2xl brand-primary text-white p-8 min-h-44 flex flex-col justify-end ${i === 0 ? "md:col-span-2 md:row-span-1" : ""}`}>
              <h2 className="text-2xl font-extrabold">{loc(b.content?.title, locale)}</h2>
              {b.content?.subtitle && <p className="text-white/80 text-sm mt-1">{loc(b.content.subtitle, locale)}</p>}
            </Link>
          ))}
        </div>
      </section>

      {!!categories?.length && (
        <section className="max-w-7xl mx-auto px-4 mt-12">
          <h2 className="text-xl font-bold mb-4">{t("categories")}</h2>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {categories.map((c: any) => (
              <Link key={c.slug} to={`/category/${c.slug}`} className="shrink-0 rounded-xl border border-slate-200 px-5 py-3 text-sm font-medium hover:border-[var(--brand-primary)]">
                {loc(c.name, locale)}
              </Link>
            ))}
          </div>
        </section>
      )}

      <ProductGrid title={t("best_sellers")} products={featured ?? []} imgs={imgs} />
      <ProductGrid title={t("new_arrivals")} products={fresh ?? []} imgs={imgs} />
    </div>
  );
}

function ProductGrid({ title, products, imgs }: { title: string; products: Product[]; imgs: any }) {
  const { locale } = useTenant();
  if (!products.length) return null;
  return (
    <section className="max-w-7xl mx-auto px-4 mt-12">
      <h2 className="text-xl font-bold mb-4">{title}</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {products.map((p) => <ProductCard key={p.id} p={p} img={imgs?.[p.id]} locale={locale} />)}
      </div>
    </section>
  );
}

export function CategoryPage() {
  const { slug } = useParams();
  const { store, locale, t } = useTenant();
  const id = store!.id;
  const { data: category } = useQuery({
    queryKey: ["cat", id, slug],
    queryFn: async () => (await supabase.from("categories").select("*").eq("store_id", id).eq("slug", slug!).single()).data,
  });
  const { data: links } = useQuery({
    queryKey: ["catprods", id, slug],
    enabled: !!category,
    queryFn: async () => {
      const { data } = await supabase.from("product_categories").select("product_id").eq("category_id", category.id);
      const ids = (data ?? []).map((r: any) => r.product_id);
      if (!ids.length) return [];
      return (await supabase.from("products").select(PUBLIC_PRODUCT_COLUMNS).in("id", ids).eq("status", "active")).data ?? [];
    },
  });
  const { data: imgs } = usePrimaryImages((links ?? []).map((p: Product) => p.id));
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">{category ? loc(category.name, locale) : "…"}</h1>
      {!links?.length ? <p className="text-slate-500">{t("empty_cart") /* reuse empty state */}</p> : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {links.map((p: Product) => <ProductCard key={p.id} p={p} img={imgs?.[p.id]} locale={locale} />)}
        </div>
      )}
    </div>
  );
}

export function SearchPage() {
  const [params] = useSearchParams();
  const q = params.get("q") ?? "";
  const { store, locale, t } = useTenant();
  const { data: results, isFetching } = useQuery({
    queryKey: ["search", store!.id, q],
    enabled: q.length > 1,
    queryFn: async () => (await supabase.rpc("search_products", { p_store_id: store!.id, p_query: q })).data ?? [],
  });
  const { data: imgs } = usePrimaryImages((results ?? []).map((p: Product) => p.id));
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-xl font-bold mb-6">{t("search")}: “{q}”</h1>
      {q.length < 2 ? <p className="text-slate-500">…</p> : isFetching ? <div className="skeleton h-40" /> : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {(results ?? []).map((p: Product) => <ProductCard key={p.id} p={p} img={imgs?.[p.id]} locale={locale} />)}
        </div>
      )}
    </div>
  );
}

export function ProductPage() {
  const { slug } = useParams();
  const { store, locale, t } = useTenant();
  const id = store!.id;
  const navigate = useNavigate();
  const [qty, setQty] = useState(1);
  const [chosen, setChosen] = useState<Record<string, string>>({});

  const { data: p } = useQuery({
    queryKey: ["prod", id, slug],
    queryFn: async () => (await supabase.from("products").select(PUBLIC_PRODUCT_COLUMNS).eq("store_id", id).eq("slug", slug!).single()).data as Product | null,
  });
  useQuery({ // fire-and-forget product view analytics
    queryKey: ["pv", p?.id],
    enabled: !!p,
    queryFn: async () => { await supabase.rpc("record_analytics_event", { p_store_id: id, p_session_key: sessionStorage.getItem("epu_sid") ?? "", p_event: "product_view", p_product_id: p!.id, p_path: window.location.pathname }); return null; },
  });

  const { data: variants } = useQuery({
    queryKey: ["vars", p?.id], enabled: !!p,
    queryFn: async () => (await supabase.from("product_variants").select("*").eq("product_id", p!.id)).data ?? [],
  });
  const { data: images } = useQuery({
    queryKey: ["imgs", p?.id], enabled: !!p,
    queryFn: async () => (await supabase.from("product_images").select("url, alt").eq("product_id", p!.id).order("position")).data ?? [],
  });
  const { data: reviews } = useQuery({
    queryKey: ["revs", p?.id], enabled: !!p,
    queryFn: async () => (await supabase.from("reviews").select("author_name, rating, title, body, verified_purchase, created_at").eq("product_id", p!.id).in("status", ["approved", "featured"]).order("created_at", { ascending: false })).data ?? [],
  });
  const { data: related } = useQuery({
    queryKey: ["rel", p?.id], enabled: !!p,
    queryFn: async () => {
      const { data } = await supabase.from("product_recommendations").select("related_product_id").eq("product_id", p!.id).limit(8);
      const ids = (data ?? []).map((r: any) => r.related_product_id);
      if (!ids.length) return [];
      return (await supabase.from("products").select(PUBLIC_PRODUCT_COLUMNS).in("id", ids).eq("status", "active")).data ?? [];
    },
  });

  const variant = useMemo(() => {
    if (!p || !variants?.length) return null;
    const entries = Object.entries(chosen);
    if (!entries.length) return null;
    return variants.find((v: any) => entries.every(([k, val]) => v.options?.[k] === val)) ?? null;
  }, [p, variants, chosen]);

  if (!p) return <div className="max-w-4xl mx-auto p-8"><div className="skeleton h-72" /></div>;

  const price = variant?.price != null ? Number(variant.price) : Number(p.price);
  const stockQty = variant ? variant.inventory_qty : p.inventory_qty;
  const inStock = !p.track_inventory || stockQty > 0;
  const attributeKeys = Object.keys(p.attributes ?? {});

  const jsonLd: any = {
    "@context": "https://schema.org", "@type": "Product",
    name: loc(p.name, locale), sku: p.sku ?? undefined,
    image: (images ?? []).map((i: any) => i.url),
    description: loc(p.short_description ?? p.description, locale),
    brand: { "@type": "Brand", name: store?.name },
    offers: {
      "@type": "Offer", price, priceCurrency: p.currency ?? "USD",
      availability: inStock ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
      url: window.location.href,
    },
  };
  if (p.rating_count > 0) {
    jsonLd.aggregateRating = { "@type": "AggregateRating", ratingValue: p.rating_avg, reviewCount: p.rating_count };
  }

  const selectedVariantId = variant?.id ?? null;
  const needsSelection = !!variants?.length && !variant;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <div className="grid md:grid-cols-2 gap-10">
        <div>
          <div className="aspect-square rounded-2xl bg-slate-100 overflow-hidden">
            {images?.[0]?.url
              ? <img src={images[0].url} alt={loc(images[0].alt, locale) || loc(p.name, locale)} className="w-full h-full object-cover" />
              : <div className="w-full h-full grid place-items-center text-slate-300 text-6xl font-bold">{loc(p.name, locale)?.[0]}</div>}
          </div>
        </div>
        <div>
          <h1 className="text-3xl font-extrabold">{loc(p.name, locale)}</h1>
          {p.rating_count > 0 && <div className="text-amber-500 mt-2">★ {Number(p.rating_avg).toFixed(1)} · {p.rating_count} {t("reviews")}</div>}
          <div className="mt-4 flex items-baseline gap-3">
            <span className="text-3xl font-bold brand-primary-text">{money(p, price, locale)}</span>
            {p.compare_at_price && <span className="text-slate-400 line-through text-xl">{money(p, Number(p.compare_at_price), locale)}</span>}
          </div>
          {loc(p.description, locale) && <p className="mt-4 text-slate-600 leading-relaxed">{loc(p.description, locale)}</p>}

          {attributeKeys.map((key) => (
            <div key={key} className="mt-4">
              <div className="text-sm font-semibold capitalize mb-2">{key}</div>
              <div className="flex flex-wrap gap-2">
                {(p.attributes[key] ?? []).map((val: string) => (
                  <button key={val} onClick={() => setChosen((c) => ({ ...c, [key]: val }))}
                    className={`px-4 py-1.5 rounded-full border text-sm ${chosen[key] === val ? "brand-primary text-white border-transparent" : "border-slate-300 hover:border-[var(--brand-primary)]"}`}>
                    {val}
                  </button>
                ))}
              </div>
            </div>
          ))}

          <div className="mt-4 text-sm">
            {inStock
              ? <span className="text-emerald-600 font-medium">{t("in_stock")}{p.track_inventory ? ` (${stockQty})` : ""}</span>
              : <span className="text-red-500 font-medium">{t("out_of_stock")}</span>}
          </div>

          <div className="mt-6 flex items-center gap-3">
            <input type="number" min={1} max={99} value={qty} onChange={(e) => setQty(Math.max(1, Math.min(99, Number(e.target.value))))}
              className="w-20 border border-slate-300 rounded-lg px-3 py-2" aria-label="quantity" />
            <button
              disabled={!inStock || needsSelection}
              onClick={() => { cart.add({ product_id: p.id, variant_id: selectedVariantId, qty }); navigate("/cart"); }}
              className="flex-1 brand-primary text-white rounded-xl py-3 font-bold disabled:opacity-50 disabled:cursor-not-allowed">
              {needsSelection ? "…" : t("add_to_cart")}
            </button>
          </div>
          {needsSelection && <p className="text-xs text-slate-500 mt-2">Select {attributeKeys.find((k) => !chosen[k]) ?? "options"}</p>}
        </div>
      </div>

      {!!reviews?.length && (
        <section className="mt-14 max-w-3xl">
          <h2 className="text-xl font-bold mb-4">{t("reviews")} ({reviews.length})</h2>
          <div className="space-y-4">
            {reviews.map((r: any, i: number) => (
              <div key={i} className="border border-slate-200 rounded-xl p-4">
                <div className="flex items-center gap-2 text-sm">
                  <span className="font-semibold">{r.author_name}</span>
                  {r.verified_purchase && <span className="text-xs bg-emerald-50 text-emerald-700 rounded-full px-2 py-0.5">Verified</span>}
                  <span className="text-amber-500">★ {r.rating}</span>
                </div>
                {r.title && <div className="font-medium mt-1">{r.title}</div>}
                <p className="text-sm text-slate-600 mt-1">{r.body}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {!!related?.length && (
        <section className="mt-14">
          <h2 className="text-xl font-bold mb-4">{t("related_products")}</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {related.map((rp: Product) => <ProductCard key={rp.id} p={rp} locale={locale} />)}
          </div>
        </section>
      )}

      <ReviewForm productId={p.id} />
    </div>
  );
}

function ReviewForm({ productId }: { productId: string }) {
  const { store, t } = useTenant();
  const [author, setAuthor] = useState("");
  const [rating, setRating] = useState(5);
  const [body, setBody] = useState("");
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const { error } = await supabase.from("reviews").insert({
      store_id: store!.id, product_id: productId,
      author_name: author, rating, body, status: "pending",
    });
    if (error) setError(error.message); else setDone(true);
  }
  if (done) return <p className="mt-10 text-sm text-emerald-600">Thanks — your review awaits moderation.</p>;
  return (
    <form onSubmit={submit} className="mt-10 max-w-md space-y-3 border-t border-slate-200 pt-8">
      <h3 className="font-bold">{t("reviews")}</h3>
      <input required value={author} onChange={(e) => setAuthor(e.target.value)} placeholder="Your name" className="w-full border border-slate-300 rounded-lg px-3 py-2" />
      <select value={rating} onChange={(e) => setRating(Number(e.target.value))} className="border border-slate-300 rounded-lg px-3 py-2" aria-label="rating">
        {[5, 4, 3, 2, 1].map((r) => <option key={r} value={r}>{r} ★</option>)}
      </select>
      <textarea required value={body} onChange={(e) => setBody(e.target.value)} placeholder="Your review" rows={3} className="w-full border border-slate-300 rounded-lg px-3 py-2" />
      {error && <p className="text-sm text-red-600">{error}</p>}
      <button className="brand-primary text-white rounded-lg px-5 py-2 text-sm font-semibold">Submit review</button>
    </form>
  );
}

export function StaticPage() {
  const { slug } = useParams();
  const { store, locale } = useTenant();
  const { data: page } = useQuery({
    queryKey: ["page", store!.id, slug],
    queryFn: async () => (await supabase.from("store_pages").select("*").eq("store_id", store!.id).eq("slug", slug!).eq("status", "published").single()).data,
  });
  if (!page) return <div className="max-w-3xl mx-auto p-8"><div className="skeleton h-64" /></div>;
  return (
    <article className="max-w-3xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold mb-6">{loc(page.title, locale)}</h1>
      <div className="prose text-slate-700 whitespace-pre-wrap">{loc(page.content, locale)}</div>
    </article>
  );
}

export function BlogPage() {
  const { slug } = useParams();
  const { store, locale } = useTenant();
  const { data: post } = useQuery({
    queryKey: ["post", store!.id, slug],
    queryFn: async () => (await supabase.from("blog_posts").select("*").eq("store_id", store!.id).eq("slug", slug!).eq("status", "published").single()).data,
  });
  if (!post) return <div className="max-w-3xl mx-auto p-8"><div className="skeleton h-64" /></div>;
  return (
    <article className="max-w-3xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold mb-2">{loc(post.title, locale)}</h1>
      <p className="text-sm text-slate-400 mb-6">{post.reading_time_min} min · {new Date(post.published_at).toLocaleDateString(locale)}</p>
      <div className="prose text-slate-700 whitespace-pre-wrap">{loc(post.content, locale)}</div>
    </article>
  );
}

export function CartPage() {
  const { t, locale, store } = useTenant();
  const lines = useCart();
  const [params, setParams] = useSearchParams();
  // Abandoned-cart email link: /cart?restore=<id> refills the cart from the server snapshot (only unrecovered carts).
  useEffect(() => {
    const id = params.get("restore");
    if (!id || !/^[0-9a-f-]{36}$/i.test(id)) return;
    Promise.resolve(supabase.rpc("get_abandoned_cart_lines", { p_id: id })).then(({ data }) => {
      const restored = (data as { product_id: string; variant_id: string | null; qty: number }[] | null) ?? [];
      if (restored.length && !cart.lines().length) cart.replace(restored.map((l) => ({ product_id: l.product_id, variant_id: l.variant_id || null, qty: l.qty })));
      params.delete("restore"); setParams(params, { replace: true });
    });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const ids = lines.map((l) => l.product_id);
  const { data: products } = useQuery({
    queryKey: ["cartprods", ids.join(",")],
    enabled: ids.length > 0,
    queryFn: async () => (await supabase.from("products").select(PUBLIC_PRODUCT_COLUMNS).in("id", ids)).data ?? [],
  });
  const rows = lines.flatMap((line) => {
    const product = (products ?? []).find((item: Product) => item.id === line.product_id);
    return product ? [{ line, p: product }] : [];
  });
  const subtotal = rows.reduce((s, r) => s + Number(r.p.price) * r.line.qty, 0);
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">{t("cart")}</h1>
      {!rows.length ? <p className="text-slate-500">{t("empty_cart")}</p> : (
        <>
          <div className="space-y-4">
            {rows.map(({ line, p }) => (
              <div key={line.product_id + (line.variant_id ?? "")} className="flex items-center gap-4 border border-slate-200 rounded-xl p-4">
                <div className="flex-1">
                  <Link to={`/product/${p.slug}`} className="font-semibold hover:underline">{loc(p.name, locale)}</Link>
                  <div className="text-sm text-slate-500">{new Intl.NumberFormat(locale, { style: "currency", currency: p.currency ?? store?.currency ?? "USD" }).format(Number(p.price))}</div>
                </div>
                <input type="number" min={0} max={99} value={line.qty}
                  onChange={(e) => cart.setQty(line.product_id, line.variant_id, Number(e.target.value))}
                  className="w-16 border border-slate-300 rounded-lg px-2 py-1.5" aria-label="quantity" />
                <div className="w-24 text-end font-semibold">{new Intl.NumberFormat(locale, { style: "currency", currency: p.currency ?? "USD" }).format(Number(p.price) * line.qty)}</div>
              </div>
            ))}
          </div>
          <div className="mt-6 flex justify-between items-center">
            <div className="text-lg"><span className="text-slate-500">{t("subtotal")}:</span> <strong>{new Intl.NumberFormat(locale, { style: "currency", currency: store?.currency ?? "USD" }).format(subtotal)}</strong></div>
            <Link to="/checkout" className="brand-primary text-white rounded-xl px-8 py-3 font-bold">{t("checkout")}</Link>
          </div>
        </>
      )}
    </div>
  );
}

export function CheckoutPage() {
  const { store, t, locale } = useTenant();
  const lines = useCart();
  const navigate = useNavigate();
  const [form, setForm] = useState({ first_name: "", last_name: "", email: "", phone: "", country: store?.country ?? "", city: store?.city ?? "", address1: "", postal_code: "", notes: "" });
  const [methodId, setMethodId] = useState<string | null>(null);
  const [pay, setPay] = useState<"cod" | "stripe">(store?.business_model === "digital" ? "stripe" : "cod");
  const [coupon, setCoupon] = useState(localStorage.getItem("epu_coupon") ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // One idempotency key per checkout attempt: a double click or a network retry can never create two orders.
  const idemKey = useRef<string>(sessionStorage.getItem("epu_idem") ?? (() => { const k = crypto.randomUUID(); sessionStorage.setItem("epu_idem", k); return k; })());

  const ids = lines.map((l) => l.product_id);
  const { data: products } = useQuery({
    queryKey: ["coprods", ids.join(",")], enabled: ids.length > 0,
    queryFn: async () => (await supabase.from("products").select(PUBLIC_PRODUCT_COLUMNS).in("id", ids)).data ?? [],
  });
  const { data: methods } = useQuery({
    queryKey: ["shipmethods", store!.id],
    queryFn: async () => (await supabase.from("shipping_methods").select("*, shipping_zones(countries, cities, is_active)").eq("store_id", store!.id).eq("is_active", true)).data ?? [],
  });
  const country = form.country.trim().toUpperCase(), city = form.city.trim();
  // Digital-only baskets need no address, no shipping and cannot use cash on delivery.
  const needsShipping = (products ?? []).some((p: Product) => (p as any).type !== "digital");
  const available = !needsShipping ? [] : (methods ?? []).filter((m: any) => {
    const z = Array.isArray(m.shipping_zones) ? m.shipping_zones[0] : m.shipping_zones;
    if (!z?.is_active) return false;
    if (z.countries !== undefined && !((z.countries as string[]).includes("*") || (z.countries as string[]).some((c) => c.toUpperCase() === country))) return false;
    if (z.cities != null && !(z.cities as string[]).some((c) => c.toLowerCase() === city.toLowerCase())) return false;
    return true;
  });
  const subtotal = lines.reduce((s, l) => { const p = (products ?? []).find((x: Product) => x.id === l.product_id); return s + (p ? Number(p.price) * l.qty : 0); }, 0);
  const method = available.find((m: any) => m.id === methodId) ?? available[0];
  const shipping = !method ? 0 : method.type === "free_threshold" && subtotal >= Number(method.free_over ?? Infinity) ? 0 : Number(method.base_price);
  const total = Math.max(0, subtotal - 0 + shipping);
  const { data: payOptions } = useQuery({
    queryKey: ["payopts", store!.id],
    queryFn: async () => (await supabase.rpc("store_payment_options", { p_store_id: store!.id })).data ?? [],
  });
  const isCodAvailable = needsShipping && (payOptions ?? []).some((o: any) => o.code === "cod");
  const isStripeAvailable = (payOptions ?? []).some((o: any) => o.code === "stripe");

  // Keep the selected method valid when the basket / store options change.
  useEffect(() => {
    if (pay === "cod" && !isCodAvailable && isStripeAvailable) setPay("stripe");
    if (pay === "stripe" && !isStripeAvailable && isCodAvailable) setPay("cod");
  }, [pay, isCodAvailable, isStripeAvailable]);

  async function placeOrder() {
    if (busy) return;                                           // double-click guard
    if (needsShipping && !method) { setError("No delivery option is available for this address."); return; }
    setBusy(true); setError(null);
    if (form.email) {
      await Promise.resolve(supabase.rpc("track_abandoned_checkout", { p_store_id: store!.id, p_email: form.email, p_items: lines, p_cart_total: total })).catch(() => {});
    }
    const { data, error: e } = await supabase.rpc("place_order", {
      p_payload: {
        store_id: store!.id,
        idempotency_key: idemKey.current,
        items: lines.map((l) => ({ product_id: l.product_id, variant_id: l.variant_id, qty: l.qty })),
        coupon_code: coupon || null,
        payment_method: pay,
        customer: { first_name: form.first_name, last_name: form.last_name, email: form.email, phone: form.phone },
        shipping_address: needsShipping ? { full_name: `${form.first_name} ${form.last_name}`, phone: form.phone, country, city, address1: form.address1, postal_code: form.postal_code } : null,
        shipping_method_id: needsShipping ? (method?.id ?? null) : null,
        notes: form.notes || null,
        utm: { referral_code: localStorage.getItem("epu_ref") || undefined },
      },
    });
    if (e || !data) { setBusy(false); setError(friendlyOrderError(e?.message)); return; }
    const order = data as { order_id: string; requires_online_payment?: boolean };
    const orderId = order.order_id;
    if (!order.requires_online_payment) {                      // COD, or a free order already finalized server-side
      cart.clear(); sessionStorage.removeItem("epu_idem");
      navigate(`/order/${orderId}/success`); return;
    }
    const { data: { session } } = await supabase.auth.getSession();
    const anon = import.meta.env.VITE_SUPABASE_ANON_KEY as string;
    const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-checkout`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: anon, Authorization: `Bearer ${session?.access_token ?? anon}` },
      body: JSON.stringify({ order_id: orderId, return_origin: window.location.origin }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok || !body.checkout_url) { setBusy(false); setError(body.error ?? "Card payment is unavailable right now."); return; }
    cart.clear(); sessionStorage.removeItem("epu_idem");
    window.location.href = body.checkout_url; // Stripe-hosted page; fulfilment happens ONLY from the signed webhook
  }

  if (!lines.length) return <div className="max-w-4xl mx-auto px-4 py-8"><p className="text-slate-500">{t("empty_cart")}</p></div>;
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setForm((f) => ({ ...f, [k]: e.target.value }));

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 grid md:grid-cols-5 gap-8">
      <div className="md:col-span-3 space-y-4">
        <h1 className="text-2xl font-bold mb-2">{t("checkout")}</h1>
        <div className="grid grid-cols-2 gap-3">
          <input required placeholder={t("first_name")} value={form.first_name} onChange={set("first_name")} className="border border-slate-300 rounded-lg px-3 py-2" />
          <input required placeholder={t("last_name")} value={form.last_name} onChange={set("last_name")} className="border border-slate-300 rounded-lg px-3 py-2" />
          <input required type="email" placeholder={t("email")} value={form.email} onChange={set("email")} className="col-span-2 border border-slate-300 rounded-lg px-3 py-2" />
          <input required placeholder={t("phone")} value={form.phone} onChange={set("phone")} className="col-span-2 border border-slate-300 rounded-lg px-3 py-2" />
          {needsShipping && (<>
            <input required maxLength={2} placeholder={t("country")} value={form.country} onChange={set("country")} className="border border-slate-300 rounded-lg px-3 py-2 uppercase" />
            <input required placeholder={t("city")} value={form.city} onChange={set("city")} className="border border-slate-300 rounded-lg px-3 py-2" />
            <input required placeholder={t("address")} value={form.address1} onChange={set("address1")} className="col-span-2 border border-slate-300 rounded-lg px-3 py-2" />
          </>)}
        </div>

        {!!available.length && (
          <div>
            <div className="font-semibold mt-2 mb-2">{t("shipping")}</div>
            <div className="space-y-2">
              {available.map((m: any) => {
                const cost = m.type === "free_threshold" && subtotal >= Number(m.free_over ?? Infinity) ? 0 : Number(m.base_price);
                return (
                  <label key={m.id} className={`flex items-center gap-3 border rounded-xl px-4 py-3 cursor-pointer ${method?.id === m.id ? "border-[var(--brand-primary)] ring-2" : "border-slate-200"}`}>
                    <input type="radio" name="ship" checked={method?.id === m.id} onChange={() => setMethodId(m.id)} />
                    <span className="flex-1">{loc(m.name, locale)}</span>
                    <span className="font-semibold">{cost === 0 ? "FREE" : new Intl.NumberFormat(locale, { style: "currency", currency: store?.currency ?? "USD" }).format(cost)}</span>
                  </label>
                );
              })}
            </div>
          </div>
        )}

        <div>
          <div className="font-semibold mt-2 mb-2">{t("payment")}</div>
          <div className="space-y-2">
            {isCodAvailable && (
              <label className={`flex items-center gap-3 border rounded-xl px-4 py-3 cursor-pointer ${pay === "cod" ? "border-[var(--brand-primary)] ring-2" : "border-slate-200"}`}>
                <input type="radio" name="pay" checked={pay === "cod"} onChange={() => setPay("cod")} />
                <span className="flex-1 font-medium">{t("cod")}</span>
              </label>
            )}
            {isStripeAvailable && (
              <label className={`flex items-center gap-3 border rounded-xl px-4 py-3 cursor-pointer ${pay === "stripe" ? "border-[var(--brand-primary)] ring-2" : "border-slate-200"}`}>
                <input type="radio" name="pay" checked={pay === "stripe"} onChange={() => setPay("stripe")} />
                <span className="flex-1 font-medium">{t("pay_card")}</span>
                <span className="text-xs text-slate-400">Stripe · 3-D Secure</span>
              </label>
            )}
            {!isCodAvailable && !isStripeAvailable && <p className="text-sm text-amber-700">No payment method is enabled for this store yet.</p>}
          </div>
        </div>

        <input placeholder={t("coupon_code")} value={coupon} onChange={(e) => setCoupon(e.target.value)} className="border border-slate-300 rounded-lg px-3 py-2 w-full" />
        <textarea placeholder={t("notes")} value={form.notes} onChange={set("notes")} rows={2} className="w-full border border-slate-300 rounded-lg px-3 py-2" />
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button disabled={busy || (!isCodAvailable && !isStripeAvailable)} onClick={placeOrder}
          className="w-full brand-primary text-white rounded-xl py-3.5 font-bold text-lg disabled:opacity-60">
          {busy ? "…" : `${t("place_order")} — ${new Intl.NumberFormat(locale, { style: "currency", currency: store?.currency ?? "USD" }).format(total)}`}
        </button>
      </div>
      <aside className="md:col-span-2">
        <div className="border border-slate-200 rounded-2xl p-5 sticky top-24">
          <h2 className="font-bold mb-4">{t("cart")}</h2>
          {lines.map((l) => {
            const p = (products ?? []).find((x: Product) => x.id === l.product_id);
            return p ? <div key={l.product_id} className="flex justify-between text-sm py-1.5"><span className="line-clamp-1">{loc(p.name, locale)} × {l.qty}</span><span>{money(p, Number(p.price) * l.qty, locale)}</span></div> : null;
          })}
          <div className="border-t border-slate-200 mt-3 pt-3 space-y-1.5 text-sm">
            <div className="flex justify-between"><span className="text-slate-500">{t("subtotal")}</span><span>{new Intl.NumberFormat(locale, { style: "currency", currency: store?.currency ?? "USD" }).format(subtotal)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">{t("shipping")}</span><span>{new Intl.NumberFormat(locale, { style: "currency", currency: store?.currency ?? "USD" }).format(shipping)}</span></div>
            <div className="flex justify-between text-lg font-bold pt-1"><span>{t("total")}</span><span>{new Intl.NumberFormat(locale, { style: "currency", currency: store?.currency ?? "USD" }).format(total)}</span></div>
          </div>
        </div>
      </aside>
    </div>
  );
}

const ORDER_ERRORS: Record<string, string> = {
  INSUFFICIENT_STOCK: "Some items are no longer available in the requested quantity.",
  PRODUCT_UNAVAILABLE: "A product in your cart is no longer available.",
  SHIPPING_METHOD_UNAVAILABLE: "The selected delivery option is not available for this address.",
  SHIPPING_ADDRESS_REQUIRED: "Please complete your delivery address.",
  COD_NOT_ALLOWED_FOR_DIGITAL: "Cash on delivery is not available for digital products.",
  PAYMENT_METHOD_UNAVAILABLE: "This payment method is not available right now.",
  INVALID_COUPON: "This coupon code is not valid.", COUPON_EXPIRED: "This coupon has expired.",
  COUPON_EXHAUSTED: "This coupon has reached its usage limit.", MIN_ORDER_NOT_MET: "Your order does not reach the coupon minimum.",
  EMAIL_REQUIRED: "Please enter a valid email address.", INVALID_EMAIL: "Please enter a valid email address.",
};
function friendlyOrderError(msg?: string): string {
  if (!msg) return "Your order could not be placed. Please try again.";
  const hit = Object.keys(ORDER_ERRORS).find((k) => msg.includes(k));
  return hit ? ORDER_ERRORS[hit] : "Your order could not be placed. Please check your details and try again.";
}

export function OrderSuccess() {
  const { id } = useParams();
  const { t } = useTenant();
  // The server is the source of truth: never claim "paid" from the browser redirect alone.
  const { data: order } = useQuery({
    queryKey: ["order", id],
    refetchInterval: (q) => {
      const d = q.state.data as { payment_method?: string; payment_status?: string } | null | undefined;
      return d?.payment_method === "stripe" && d?.payment_status !== "paid" ? 3000 : false;
    },
    queryFn: async () => (await supabase.rpc("get_order_confirmation", { p_order_id: id! })).data as
      { order_number: string; payment_method: string; payment_status: string; status: string; has_digital: boolean } | null,
  });
  if (!order) return <div className="max-w-xl mx-auto p-8"><div className="skeleton h-32" /></div>;
  const awaiting = order.payment_method === "stripe" && order.payment_status !== "paid";
  return (
    <div className="max-w-xl mx-auto px-4 py-16 text-center">
      <div className={`w-16 h-16 rounded-full grid place-items-center text-3xl mx-auto mb-4 ${awaiting ? "bg-amber-100 text-amber-600" : "bg-emerald-100 text-emerald-600"}`}>{awaiting ? "…" : "✓"}</div>
      <h1 className="text-2xl font-bold">{awaiting ? "Waiting for payment confirmation" : t("order_confirmed")}</h1>
      <p className="text-slate-500 mt-2">{order.order_number} · {order.payment_method === "cod" ? t("cod") : t("pay_card")}</p>
      {awaiting && <p className="text-sm text-slate-500 mt-2">This page updates automatically once your bank confirms the payment.</p>}
      {order.payment_method === "cod" && <p className="text-sm text-slate-500 mt-2">We received your order and will contact you to confirm it. You pay on delivery.</p>}
      {order.payment_method === "stripe" && !awaiting && order.has_digital && <p className="text-sm text-slate-500 mt-2">Payment verified — your secure download links are on their way by email and in your account.</p>}
    </div>
  );
}
