import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { useTenant } from "@/lib/tenant";

type Block = { type: string; text?: string; url?: string; level?: number };
const LOCALE_LABELS: Record<string, string> = { en: "English", fr: "Français", ar: "العربية" };

function Preview({ blocks, vars }: { blocks: Block[]; vars: Record<string, string> }) {
  const r = (t?: string) => Object.entries(vars).reduce((s, [k, v]) => s.replaceAll(`{{${k}}}`, v), t ?? "");
  return (
    <div className="border border-slate-200 rounded-xl p-5 bg-white text-sm space-y-2" style={{ fontFamily: "Inter, sans-serif" }}>
      {blocks.map((b, i) => {
        if (b.type === "heading") return <div key={i} className={`font-bold ${b.level === 1 ? "text-xl" : "text-lg"}`}>{r(b.text)}</div>;
        if (b.type === "button") return <span key={i} className="inline-block brand-primary text-white rounded-lg px-4 py-2 font-semibold">{r(b.text)}</span>;
        if (b.type === "order_summary") return <div key={i} className="text-slate-400 italic">[ order summary ]</div>;
        if (b.type === "cart_items") return <div key={i} className="text-slate-400 italic">[ cart items ]</div>;
        if (b.type === "download_links") return <div key={i} className="text-slate-400 italic">[ download links ]</div>;
        return <p key={i} className="text-slate-600">{r(b.text)}</p>;
      })}
    </div>
  );
}

export function EmailTemplatesAdmin() {
  const { store } = useTenant();
  const qc = useQueryClient();
  const [selected, setSelected] = useState<string | null>(null);
  const [subjects, setSubjects] = useState<Record<string, string>>({});
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [saved, setSaved] = useState(false);

  const { data: templates } = useQuery({
    queryKey: ["etpls", store!.id],
    queryFn: async () => (await supabase.from("email_templates").select("*").eq("store_id", store!.id).order("key")).data ?? [],
  });

  const current = (templates ?? []).find((t: any) => t.id === selected);
  useEffect(() => {
    if (current) {
      setSubjects(current.subject ?? {});
      setBlocks(Array.isArray(current.body?.en) ? current.body.en : []);
      setSaved(false);
    }
  }, [selected]); // eslint-disable-line react-hooks/exhaustive-deps

  const save = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("email_templates").update({
        subject: subjects, body: { en: blocks, fr: blocks, ar: blocks },
      }).eq("id", selected);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["etpls"] }); setSaved(true); },
  });

  const move = (i: number, dir: number) => setBlocks((b) => {
    const n = [...b]; const j = i + dir;
    if (j < 0 || j >= n.length) return b;
    [n[i], n[j]] = [n[j], n[i]];
    return n;
  });

  const addBlock = (type: string) => setBlocks((b) => [...b, type === "heading" ? { type, text: "Heading", level: 2 } : type === "button" ? { type, text: "Click here", url: "https://" } : { type }]);

  return (
    <div className="p-8 grid lg:grid-cols-2 gap-8 max-w-6xl">
      <div>
        <h1 className="text-2xl font-bold mb-4">Email Template Editor</h1>
        <div className="space-y-2 mb-6">
          {(templates ?? []).map((t: any) => (
            <button key={t.id} onClick={() => setSelected(t.id)}
              className={`w-full text-start border rounded-xl px-4 py-2.5 text-sm ${selected === t.id ? "border-[var(--brand-primary)] ring-2" : "border-slate-200"}`}>
              <span className="font-semibold">{t.name}</span>
              <span className="text-slate-400 ms-2">{t.key}</span>
            </button>
          ))}
        </div>
        {current && (
          <div className="space-y-3">
            {["en", "fr", "ar"].map((l) => (
              <input key={l} value={subjects[l] ?? ""} onChange={(e) => setSubjects((s) => ({ ...s, [l]: e.target.value }))}
                placeholder={`Subject — ${LOCALE_LABELS[l]}`} dir={l === "ar" ? "rtl" : "ltr"}
                className="w-full border border-slate-300 rounded-lg px-3 py-2" />
            ))}
            {blocks.map((b, i) => (
              <div key={i} className="border border-slate-200 rounded-xl p-3 space-y-2 bg-slate-50">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase text-slate-400">{b.type}</span>
                  <span className="flex-1" />
                  <button onClick={() => move(i, -1)} className="text-xs px-2 py-1 border rounded">↑</button>
                  <button onClick={() => move(i, 1)} className="text-xs px-2 py-1 border rounded">↓</button>
                  <button onClick={() => setBlocks((x) => x.filter((_, j) => j !== i))} className="text-xs px-2 py-1 border rounded text-red-500">×</button>
                </div>
                {b.type === "heading" && <input value={b.text ?? ""} onChange={(e) => setBlocks((x) => x.map((y, j) => j === i ? { ...y, text: e.target.value } : y))} className="w-full border rounded-lg px-3 py-1.5 text-sm" placeholder="Heading text" />}
                {b.type === "text" && <textarea value={b.text ?? ""} onChange={(e) => setBlocks((x) => x.map((y, j) => j === i ? { ...y, text: e.target.value } : y))} rows={2} className="w-full border rounded-lg px-3 py-1.5 text-sm" placeholder="Text…" />}
                {b.type === "button" && (
                  <div className="flex gap-2">
                    <input value={b.text ?? ""} onChange={(e) => setBlocks((x) => x.map((y, j) => j === i ? { ...y, text: e.target.value } : y))} className="flex-1 border rounded-lg px-3 py-1.5 text-sm" placeholder="Button label" />
                    <input value={b.url ?? ""} onChange={(e) => setBlocks((x) => x.map((y, j) => j === i ? { ...y, url: e.target.value } : y))} className="flex-1 border rounded-lg px-3 py-1.5 text-sm" placeholder="https://…" />
                  </div>
                )}
              </div>
            ))}
            <div className="flex flex-wrap gap-2 pt-1">
              {["heading", "text", "button", "order_summary", "cart_items", "download_links"].map((t) => (
                <button key={t} onClick={() => addBlock(t)} className="text-xs border border-slate-300 rounded-lg px-2.5 py-1.5 hover:border-[var(--brand-primary)]">+ {t}</button>
              ))}
            </div>
            <button onClick={() => save.mutate()} disabled={save.isPending}
              className="brand-primary text-white rounded-lg px-6 py-2.5 font-semibold disabled:opacity-60">
              {save.isPending ? "Saving…" : saved ? "Saved ✓" : "Save template"}
            </button>
            {save.isError && <p className="text-sm text-red-600">{(save.error as Error).message}</p>}
          </div>
        )}
      </div>
      <div>
        <h2 className="text-xl font-bold mb-4">Live preview</h2>
        {selected
          ? <Preview blocks={blocks} vars={{ order_number: "ORD-20261030-ABC123", total: "129.00", first_name: "Sara" }} />
          : <p className="text-slate-400">Select a template to edit.</p>}
      </div>
    </div>
  );
}
