import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { useTenant } from "@/lib/tenant";
import { useSession } from "@/lib/guards";

export function AccountPage() {
  const { store, locale, fmtMoney, fmtDate } = useTenant();
  const { user, loading } = useSession();
  const qc = useQueryClient();
  const [copied, setCopied] = useState(false);

  const { data: customer } = useQuery({
    queryKey: ["mycustomer", store!.id],
    enabled: !!user,
    queryFn: async () => (await supabase.from("customers").select("id, first_name, referral_code, total_orders, total_spent").eq("store_id", store!.id).eq("user_id", user!.id).maybeSingle()).data,
  });
  const { data: loyalty } = useQuery({
    queryKey: ["myloyalty", store!.id],
    enabled: !!user,
    queryFn: async () => (await supabase.rpc("my_loyalty", { p_store_id: store!.id })).data as any,
  });
  const { data: consents } = useQuery({
    queryKey: ["myconsents", store!.id],
    enabled: !!user,
    queryFn: async () => (await supabase.rpc("my_consents", { p_store_id: store!.id })).data as { channel: string; status: string }[],
  });
  const { data: orders } = useQuery({
    queryKey: ["myorders", store!.id],
    enabled: !!user,
    queryFn: async () => (await supabase.from("orders").select("id, order_number, total, status, payment_status, created_at").eq("store_id", store!.id).order("created_at", { ascending: false }).limit(20)).data ?? [],
  });

  const consent = useMutation({
    mutationFn: async ({ channel, status }: { channel: string; status: string }) => {
      await supabase.rpc("set_marketing_consent", { p_store_id: store!.id, p_channel: channel, p_status: status });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["myconsents"] }),
  });

  if (loading) return <div className="max-w-3xl mx-auto px-4 py-10"><div className="skeleton h-40" /></div>;
  if (!user) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">{locale === "ar" ? "حسابي" : locale === "fr" ? "Mon compte" : "My account"}</h1>
        <p className="text-slate-500 mb-6">Sign in to see your orders, loyalty points and downloads.</p>
        <Link to="/login" className="brand-primary text-white rounded-xl px-6 py-3 font-bold inline-block">Sign in</Link>
      </div>
    );
  }

  const refLink = customer?.referral_code
    ? `${window.location.origin}/?ref=${customer.referral_code}`
    : null;
  const consentFor = (channel: string) => (consents ?? []).find((c) => c.channel === channel)?.status === "opted_in";

  return (
    <div className="max-w-4xl mx-auto px-4 py-10 space-y-8">
      <h1 className="text-2xl font-bold">{locale === "ar" ? "حسابي" : locale === "fr" ? "Mon compte" : "My account"}</h1>

      {loyalty && (
        <div className="grid sm:grid-cols-3 gap-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <div className="text-sm text-slate-500">Points balance</div>
            <div className="text-2xl font-extrabold mt-1">{loyalty.balance}</div>
          </div>
          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <div className="text-sm text-slate-500">Lifetime points</div>
            <div className="text-2xl font-extrabold mt-1 capitalize">{loyalty.lifetime}</div>
          </div>
          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <div className="text-sm text-slate-500">Tier</div>
            <div className="text-2xl font-extrabold mt-1 capitalize brand-primary-text">{loyalty.tier}</div>
          </div>
        </div>
      )}

      <div className="bg-white border border-slate-200 rounded-2xl p-6">
        <h2 className="font-bold mb-3">Referral program</h2>
        <p className="text-sm text-slate-500 mb-3">Share your link — you earn points when friends place their first order.</p>
        {refLink && (
          <div className="flex gap-2">
            <input readOnly value={refLink} className="flex-1 border border-slate-300 rounded-lg px-3 py-2 text-sm bg-slate-50" onFocus={(e) => e.target.select()} />
            <button onClick={() => { navigator.clipboard.writeText(refLink); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
              className="brand-primary text-white rounded-lg px-4 py-2 text-sm font-semibold">
              {copied ? "Copied ✓" : "Copy"}
            </button>
          </div>
        )}
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl p-6">
        <h2 className="font-bold mb-3">Communication preferences</h2>
        <div className="space-y-2">
          {["email", "whatsapp"].map((channel) => (
            <label key={channel} className="flex items-center justify-between border border-slate-100 rounded-xl px-4 py-3">
              <span className="text-sm font-medium capitalize">{channel}</span>
              <button
                onClick={() => consent.mutate({ channel, status: consentFor(channel) ? "opted_out" : "opted_in" })}
                className={`w-11 h-6 rounded-full relative transition-colors ${consentFor(channel) ? "bg-emerald-500" : "bg-slate-300"}`}>
                <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${consentFor(channel) ? "start-0.5" : "end-0.5"}`} />
              </button>
            </label>
          ))}
        </div>
        <Link to="/downloads" className="text-sm brand-primary-text font-semibold inline-block mt-4">→ My downloads</Link>
      </div>

      <div>
        <h2 className="font-bold mb-3">Order history</h2>
        <div className="space-y-2">
          {(orders ?? []).map((o: any) => (
            <div key={o.id} className="bg-white border border-slate-200 rounded-xl px-4 py-3 flex items-center gap-3 text-sm">
              <span className="font-semibold">{o.order_number}</span>
              <span className="text-slate-400">{fmtDate(o.created_at)}</span>
              <span className="text-xs rounded-full px-2 py-0.5 bg-slate-100 text-slate-600">{o.status}</span>
              <span className="ms-auto font-bold">{fmtMoney(Number(o.total))}</span>
            </div>
          ))}
          {!orders?.length && <p className="text-slate-400">No orders yet.</p>}
        </div>
      </div>
    </div>
  );
}
