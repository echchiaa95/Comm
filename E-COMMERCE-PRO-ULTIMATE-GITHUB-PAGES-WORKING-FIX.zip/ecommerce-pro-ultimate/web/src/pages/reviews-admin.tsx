import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { useTenant } from "@/lib/tenant";

type Filter = "pending" | "approved" | "featured" | "all";

export function ReviewsAdmin() {
  const { store } = useTenant();
  const qc = useQueryClient();
  const [filter, setFilter] = useState<Filter>("pending");
  const [responses, setResponses] = useState<Record<string, string>>({});

  const { data: reviews } = useQuery({
    queryKey: ["areviews", store!.id],
    queryFn: async () => (await supabase.from("reviews").select("*").eq("store_id", store!.id).order("created_at", { ascending: false }).limit(100)).data ?? [],
  });
  const invalidate = () => qc.invalidateQueries({ queryKey: ["areviews"] });

  const setStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("reviews").update({ status }).eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: invalidate,
  });
  const respond = useMutation({
    mutationFn: async ({ id }: { id: string }) => {
      const { error } = await supabase.from("reviews")
        .update({ response: responses[id] ?? "", responded_at: new Date().toISOString() }).eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: invalidate,
  });

  const filtered = (reviews ?? []).filter((r: any) => filter === "all" || r.status === filter);

  return (
    <div className="p-8 max-w-4xl space-y-6">
      <h1 className="text-2xl font-bold">Reviews Moderation</h1>
      <div className="flex gap-2">
        {(["pending", "approved", "featured", "all"] as Filter[]).map((f) => (
          <button key={f} onClick={() => setFilter(f)}
            className={`text-sm rounded-lg px-4 py-2 font-medium ${filter === f ? "brand-primary text-white" : "bg-slate-100 text-slate-600"}`}>
            {f} {f !== "all" && `(${(reviews ?? []).filter((r: any) => r.status === f).length})`}
          </button>
        ))}
      </div>
      <div className="space-y-3">
        {filtered.map((r: any) => (
          <div key={r.id} className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="flex items-center gap-2 text-sm flex-wrap">
              <span className="font-semibold">{r.author_name}</span>
              <span className="text-amber-500">★ {r.rating}</span>
              {r.verified_purchase && <span className="text-xs bg-emerald-50 text-emerald-700 rounded-full px-2 py-0.5">Verified purchase</span>}
              <span className={`text-xs rounded-full px-2 py-0.5 ${r.status === "pending" ? "bg-amber-50 text-amber-700" : r.status === "featured" ? "bg-violet-50 text-violet-700" : "bg-slate-100 text-slate-500"}`}>{r.status}</span>
              <span className="flex-1" />
              {r.status === "pending" && (
                <>
                  <button onClick={() => setStatus.mutate({ id: r.id, status: "approved" })} className="text-xs font-semibold text-emerald-600 hover:underline">Approve</button>
                  <button onClick={() => setStatus.mutate({ id: r.id, status: "rejected" })} className="text-xs font-semibold text-red-500 hover:underline">Reject</button>
                </>
              )}
              {r.status !== "pending" && (
                <button onClick={() => setStatus.mutate({ id: r.id, status: r.status === "featured" ? "approved" : "featured" })} className="text-xs font-semibold brand-primary-text hover:underline">
                  {r.status === "featured" ? "Unfeature" : "Feature"}
                </button>
              )}
            </div>
            {r.title && <div className="font-medium mt-2">{r.title}</div>}
            <p className="text-sm text-slate-600 mt-1">{r.body}</p>
            {r.response && <p className="text-sm mt-2 bg-slate-50 border-s-2 border-[var(--brand-primary)] rounded-r-lg p-3"><b>Response:</b> {r.response}</p>}
            <div className="flex gap-2 mt-3">
              <input value={responses[r.id] ?? r.response ?? ""} onChange={(e) => setResponses((s) => ({ ...s, [r.id]: e.target.value }))}
                placeholder="Reply publicly (optional)" className="flex-1 border border-slate-300 rounded-lg px-3 py-2 text-sm" />
              <button onClick={() => respond.mutate({ id: r.id })} disabled={respond.isPending} className="text-sm border border-slate-300 rounded-lg px-4 py-2 hover:border-[var(--brand-primary)]">
                {r.response ? "Update reply" : "Reply"}
              </button>
            </div>
          </div>
        ))}
        {!filtered.length && <p className="text-slate-400">No {filter} reviews.</p>}
      </div>
    </div>
  );
}
