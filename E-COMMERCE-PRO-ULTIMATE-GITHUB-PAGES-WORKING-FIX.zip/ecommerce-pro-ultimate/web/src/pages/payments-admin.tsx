import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { useTenant } from "@/lib/tenant";

type ProviderStatus = { enabled: boolean; mode?: string; status?: string; connected_account_id?: string | null; charges_enabled?: boolean; payouts_enabled?: boolean; has_own_key?: boolean };

async function callFn(action: string, storeId: string, body: Record<string, unknown> = {}) {
  const { data: { session } } = await supabase.auth.getSession();
  const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/connect-stripe`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: import.meta.env.VITE_SUPABASE_ANON_KEY as string,
      Authorization: `Bearer ${session?.access_token ?? ""}`,
    },
    body: JSON.stringify({ store_id: storeId, action, ...body }),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error ?? `request failed (${res.status})`);
  return json;
}

export function PaymentsAdmin() {
  const { store } = useTenant();
  const qc = useQueryClient();
  const [key, setKey] = useState("");
  const [whsec, setWhsec] = useState("");
  const [message, setMessage] = useState<string | null>(null);

  const { data } = useQuery({
    queryKey: ["payadmin", store!.id],
    queryFn: async () => {
      const [stripe, cod] = await Promise.all([
        callFn("status", store!.id, { code: "stripe" }),
        callFn("status", store!.id, { code: "cod" }),
      ]);
      return { stripe: stripe as ProviderStatus, cod: cod as ProviderStatus };
    },
  });

  const invalidate = () => { qc.invalidateQueries({ queryKey: ["payadmin"] }); setMessage(null); };
  const toggle = useMutation({
    mutationFn: ({ code, enabled }: { code: string; enabled: boolean }) => callFn("toggle", store!.id, { code, enabled }),
    onSuccess: invalidate,
    onError: (e) => setMessage((e as Error).message),
  });
  const saveKeys = useMutation({
    mutationFn: () => callFn("save_keys", store!.id, { secret_key: key, webhook_secret: whsec || undefined }),
    onSuccess: (r) => { setKey(""); setWhsec(""); invalidate(); setMessage(`Stripe key saved to Vault ✓ — webhook endpoint: ${r.webhook_endpoint}`); },
    onError: (e) => setMessage((e as Error).message),
  });
  const sync = useMutation({
    mutationFn: () => callFn("sync", store!.id),
    onSuccess: (r) => { invalidate(); setMessage(r.charges_enabled ? "Stripe account can accept payments ✓" : "Stripe onboarding is not complete yet."); },
    onError: (e) => setMessage((e as Error).message),
  });
  const removeKeys = useMutation({
    mutationFn: () => callFn("remove_keys", store!.id),
    onSuccess: () => { invalidate(); setMessage("Stripe key removed."); },
    onError: (e) => setMessage((e as Error).message),
  });
  const onboard = useMutation({
    mutationFn: () => callFn("onboarding", store!.id),
    onSuccess: (json) => { window.location.href = json.onboarding_url; },
    onError: (e) => setMessage((e as Error).message),
  });

  return (
    <div className="p-8 max-w-3xl space-y-4">
      <h1 className="text-2xl font-bold">Payments</h1>
      {message && <p className="text-sm bg-slate-50 border border-slate-200 rounded-xl p-3">{message}</p>}

      <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="font-bold text-lg">Stripe</div>
            <div className="text-sm text-slate-500">
              {data?.stripe?.enabled
                ? <>Enabled · {data.stripe.status} · {data.stripe.mode} mode{data.stripe.connected_account_id ? ` · account ${data.stripe.connected_account_id}` : ""}</>
                : "Not enabled"}
            </div>
          </div>
          <span className={`text-xs rounded-full px-3 py-1 font-semibold ${data?.stripe?.enabled ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
            {data?.stripe?.enabled ? "ACTIVE" : "OFF"}
          </span>
        </div>
        <div className="flex flex-wrap gap-2">
          <button onClick={() => onboard.mutate()} disabled={onboard.isPending}
            className="bg-violet-600 text-white rounded-lg px-4 py-2 text-sm font-semibold disabled:opacity-60">
            {onboard.isPending ? "…" : data?.stripe?.connected_account_id ? "Resume Stripe onboarding" : "Connect Stripe (Express)"}
          </button>
          {data?.stripe?.connected_account_id && (
            <button onClick={() => sync.mutate()} disabled={sync.isPending}
              className="border border-slate-300 rounded-lg px-4 py-2 text-sm font-medium disabled:opacity-60">
              {sync.isPending ? "…" : "Refresh Stripe status"}
            </button>
          )}
          {data?.stripe?.has_own_key && (
            <button onClick={() => removeKeys.mutate()} disabled={removeKeys.isPending}
              className="border border-red-200 text-red-600 rounded-lg px-4 py-2 text-sm font-medium disabled:opacity-60">
              Remove key
            </button>
          )}
          {data?.stripe?.enabled !== undefined && (
            <button onClick={() => toggle.mutate({ code: "stripe", enabled: !data.stripe.enabled })}
              className="border border-slate-300 rounded-lg px-4 py-2 text-sm font-medium">
              {data.stripe.enabled ? "Disable" : "Enable"}
            </button>
          )}
        </div>
        <div className="border-t border-slate-100 pt-4">
          <div className="text-sm font-semibold mb-2">Or paste an API secret key directly (test or live)</div>
          <div className="flex gap-2">
            <input type="password" value={key} onChange={(e) => setKey(e.target.value)} placeholder="sk_test_… or sk_live_…"
              className="flex-1 border border-slate-300 rounded-lg px-3 py-2 font-mono text-sm" />
            <button onClick={() => saveKeys.mutate()} disabled={saveKeys.isPending || !key}
              className="brand-primary text-white rounded-lg px-4 py-2 text-sm font-semibold disabled:opacity-60">
              {saveKeys.isPending ? "…" : "Save to Vault"}
            </button>
          </div>
          <input type="password" value={whsec} onChange={(e) => setWhsec(e.target.value)} placeholder="whsec_… (optional webhook signing secret)"
            className="mt-2 w-full border border-slate-300 rounded-lg px-3 py-2 font-mono text-sm" />
          <p className="text-xs text-slate-400 mt-1">Stored encrypted in Supabase Vault — never in the database or frontend.</p>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl p-6 flex items-center justify-between">
        <div>
          <div className="font-bold text-lg">Cash on Delivery</div>
          <div className="text-sm text-slate-500">{data?.cod?.enabled ? "Available at checkout for shippable products" : "Disabled"}</div>
        </div>
        <button onClick={() => toggle.mutate({ code: "cod", enabled: !data?.cod?.enabled })}
          className={`rounded-lg px-4 py-2 text-sm font-semibold ${data?.cod?.enabled ? "bg-slate-100 text-slate-700" : "bg-emerald-600 text-white"}`}>
          {data?.cod?.enabled ? "Disable COD" : "Enable COD"}
        </button>
      </div>
    </div>
  );
}
