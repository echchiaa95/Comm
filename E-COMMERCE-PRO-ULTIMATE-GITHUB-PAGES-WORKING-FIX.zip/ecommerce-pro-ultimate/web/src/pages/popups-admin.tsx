import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { useTenant } from "@/lib/tenant";

const TYPES = ["welcome", "newsletter", "exit_intent", "discount", "announcement", "product", "free_shipping"];

export function PopupBuilder() {
  const { store } = useTenant();
  const qc = useQueryClient();
  const [f, setF] = useState({
    name: "", type: "newsletter", title: "", body: "", cta_text: "", cta_link: "", coupon_code: "",
    delay_seconds: "5", frequency_cap: "3", cooldown_hours: "24", min_cart: "0", starts_at: "", ends_at: "",
  });
  const [error, setError] = useState<string | null>(null);

  const { data: popups } = useQuery({
    queryKey: ["popups-admin", store!.id],
    queryFn: async () => (await supabase.from("popups").select("*").eq("store_id", store!.id).order("priority")).data ?? [],
  });

  const invalidate = () => qc.invalidateQueries({ queryKey: ["popups-admin"] });
  const create = useMutation({
    mutationFn: async () => {
      setError(null);
      const { error } = await supabase.from("popups").insert({
        store_id: store!.id, name: f.name, type: f.type, status: "active",
        content: { title: f.title, body: f.body, cta_text: f.cta_text || null, cta_link: f.cta_link || null, coupon_code: f.coupon_code || null },
        targeting: { min_cart: Number(f.min_cart) || undefined },
        behavior: {
          delay_seconds: Number(f.delay_seconds) || 5,
          frequency_cap: Number(f.frequency_cap) || 3,
          cooldown_hours: Number(f.cooldown_hours) || 24,
        },
        starts_at: f.starts_at || null, ends_at: f.ends_at || null,
      });
      if (error) throw new Error(error.message);
    },
    onSuccess: () => { invalidate(); setF({ ...f, name: "", title: "", body: "", cta_text: "", cta_link: "", coupon_code: "" }); },
    onError: (e) => setError((e as Error).message),
  });
  const toggle = useMutation({
    mutationFn: async (p: any) => {
      await supabase.from("popups").update({ status: p.status === "active" ? "paused" : "active" }).eq("id", p.id);
    },
    onSuccess: invalidate,
  });
  const remove = useMutation({
    mutationFn: async (id: string) => { await supabase.from("popups").delete().eq("id", id); },
    onSuccess: invalidate,
  });

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setF((x) => ({ ...x, [k]: e.target.value }));

  return (
    <div className="p-8 space-y-8 max-w-5xl">
      <h1 className="text-2xl font-bold">Popups & Lead Generation</h1>
      <form onSubmit={(e) => { e.preventDefault(); create.mutate(); }} className="bg-white rounded-2xl border border-slate-200 p-6 grid sm:grid-cols-4 gap-3">
        <input required placeholder="Popup name (internal)" value={f.name} onChange={set("name")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <select value={f.type} onChange={set("type")} className="border border-slate-300 rounded-lg px-3 py-2">
          {TYPES.map((t) => <option key={t} value={t}>{t.replace("_", " ")}</option>)}
        </select>
        <input placeholder="Headline" value={f.title} onChange={set("title")} className="sm:col-span-2 border border-slate-300 rounded-lg px-3 py-2" />
        <textarea placeholder="Body text" value={f.body} onChange={set("body")} rows={2} className="sm:col-span-2 border border-slate-300 rounded-lg px-3 py-2" />
        <input placeholder="CTA text" value={f.cta_text} onChange={set("cta_text")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <input placeholder="CTA link" value={f.cta_link} onChange={set("cta_link")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <input placeholder="Coupon code (optional)" value={f.coupon_code} onChange={set("coupon_code")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <input type="number" min={0} placeholder="Delay (sec)" value={f.delay_seconds} onChange={set("delay_seconds")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <input type="number" min={1} placeholder="Frequency cap" value={f.frequency_cap} onChange={set("frequency_cap")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <input type="number" min={0} placeholder="Cooldown (hours)" value={f.cooldown_hours} onChange={set("cooldown_hours")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <input type="number" min={0} placeholder="Min cart lines" value={f.min_cart} onChange={set("min_cart")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <input type="datetime-local" value={f.starts_at} onChange={set("starts_at")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <input type="datetime-local" value={f.ends_at} onChange={set("ends_at")} className="border border-slate-300 rounded-lg px-3 py-2" />
        {error && <p className="sm:col-span-4 text-sm text-red-600">{error}</p>}
        <button disabled={create.isPending} className="sm:col-span-4 brand-primary text-white rounded-lg py-2.5 font-semibold w-48 disabled:opacity-60">
          {create.isPending ? "Saving…" : "Create popup"}
        </button>
      </form>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-slate-200 bg-slate-50">
            {["Name", "Type", "Headline", "Status", ""].map((h) => <th key={h} className="text-start font-semibold px-4 py-3 text-slate-600">{h}</th>)}
          </tr></thead>
          <tbody>
            {(popups ?? []).map((p: any) => (
              <tr key={p.id} className="border-b border-slate-100 last:border-0">
                <td className="px-4 py-2.5 font-medium">{p.name}</td>
                <td className="px-4 py-2.5 capitalize">{p.type.replace("_", " ")}</td>
                <td className="px-4 py-2.5">{p.content?.title ?? "—"}</td>
                <td className="px-4 py-2.5">
                  <span className={`text-xs rounded-full px-2 py-0.5 ${p.status === "active" ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>{p.status}</span>
                </td>
                <td className="px-4 py-2.5 space-x-3 whitespace-nowrap">
                  <button onClick={() => toggle.mutate(p)} className="text-xs font-semibold brand-primary-text hover:underline">
                    {p.status === "active" ? "Pause" : "Activate"}
                  </button>
                  <button onClick={() => remove.mutate(p.id)} className="text-xs font-semibold text-red-500 hover:underline">Delete</button>
                </td>
              </tr>
            ))}
            {!popups?.length && <tr><td colSpan={5} className="px-4 py-10 text-center text-slate-400">No popups yet</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
