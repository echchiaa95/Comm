import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { supabase } from "@/lib/supabase";
import { useTenant } from "@/lib/tenant";
import { useSession } from "@/lib/guards";

type Download = {
  download_id: string; token: string; file_name: string; mime_type: string; size_bytes: number;
  order_number: string; download_count: number; download_limit: number;
  expires_at: string | null; revoked: boolean; created_at: string;
};

export function CustomerDownloads() {
  const { store, locale } = useTenant();
  const { user, loading } = useSession();
  const { data: downloads, isFetching } = useQuery({
    queryKey: ["mydownloads", store!.id],
    enabled: !!user,
    queryFn: async () => (await supabase.rpc("customer_downloads", { p_store_id: store!.id })).data as Download[],
  });

  if (loading || isFetching) return <div className="max-w-3xl mx-auto px-4 py-10"><div className="skeleton h-40" /></div>;

  if (!user) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-2">Sign in to view your downloads</h1>
        <p className="text-slate-500 mb-6">Your secure download library is linked to your account email.</p>
        <Link to="/login" className="brand-primary text-white rounded-xl px-6 py-3 font-bold inline-block">Sign in</Link>
      </div>
    );
  }

  const fnBase = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/deliver-download`;
  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold mb-6">{locale === "ar" ? "مكتبة التنزيلات" : locale === "fr" ? "Vos téléchargements" : "Your downloads"}</h1>
      {!downloads?.length ? (
        <p className="text-slate-500">No downloads yet — purchases appear here once payment is verified.</p>
      ) : (
        <div className="space-y-3">
          {downloads.map((d) => {
            const usable = !d.revoked && (!d.expires_at || new Date(d.expires_at) > new Date()) && d.download_count < d.download_limit;
            return (
              <div key={d.download_id} className="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-4">
                <div className="flex-1 min-w-0">
                  <div className="font-semibold truncate">{d.file_name}</div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    {d.order_number} · {(d.size_bytes / 1024 / 1024).toFixed(1)} MB · {d.download_count}/{d.download_limit} downloads
                    {d.expires_at && ` · expires ${new Date(d.expires_at).toLocaleDateString(locale)}`}
                  </div>
                </div>
                {usable ? (
                  <a href={`${fnBase}?token=${d.token}`}
                    className="brand-primary text-white rounded-lg px-4 py-2 text-sm font-semibold shrink-0">
                    Download
                  </a>
                ) : (
                  <span className="text-xs text-slate-400 shrink-0">{d.revoked ? "revoked" : "limit/expired"}</span>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
