import { useState } from "react";
import { useParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase, loc } from "@/lib/supabase";
import { useTenant } from "@/lib/tenant";

type Row = Record<string, any>;

// Generic module registry: every sidebar section renders its real table.
export const MODULES: Record<string, { title: string; table: string; columns: string[]; orderBy?: string; select?: string }> = {
  "analytics": { title: "Analytics — Conversion Events", table: "conversion_events", columns: ["event", "value", "currency", "created_at"] },
  "ab-testing": { title: "A/B Testing — Experiments", table: "experiments", columns: ["key", "name", "target", "status", "starts_at", "ends_at"] },
  "categories": { title: "Categories", table: "categories", columns: ["slug", "name", "position", "is_active"] },
  "inventory": { title: "Inventory", table: "inventory", columns: ["product_id", "variant_id", "qty_on_hand", "qty_reserved"] },
  "digital-downloads": { title: "Digital Downloads", table: "digital_downloads", columns: ["order_id", "product_id", "download_count", "download_limit", "expires_at", "revoked"] },
  "customers": { title: "Customers (CRM)", table: "customers", columns: ["email", "phone", "total_orders", "total_spent", "accepts_marketing", "created_at"] },
  "shipping": { title: "Shipping Methods", table: "shipping_methods", columns: ["name", "type", "base_price", "free_over", "is_active"] },
  "marketing": { title: "Marketing Center — Campaigns", table: "campaigns", columns: ["name", "channel", "source", "medium", "budget", "cost", "status"] },
  "email-campaigns": { title: "Email Campaigns — Templates", table: "email_templates", columns: ["key", "name", "subject", "is_active"] },
  "whatsapp": { title: "WhatsApp — Integration (requires a configured provider)", table: "integrations", columns: ["provider", "enabled", "status", "last_sync_at"], select: "id,store_id,provider,enabled,status,last_sync_at,created_at" },
  "loyalty": { title: "Loyalty Program", table: "loyalty_accounts", columns: ["customer_id", "points_balance", "lifetime_points", "tier"] },
  "affiliates": { title: "Affiliate Marketing", table: "affiliates", columns: ["name", "email", "code", "commission_percent", "status"] },
  "reviews": { title: "Reviews", table: "reviews", columns: ["author_name", "rating", "status", "verified_purchase", "created_at"] },
  "discounts": { title: "Discounts & Coupons", table: "coupons", columns: ["code", "kind", "value", "min_order_total", "used_count", "usage_limit", "is_active", "expires_at"] },
  "seo": { title: "SEO Center", table: "seo_metadata", columns: ["entity_type", "entity_id", "locale", "title", "robots"] },
  "blog": { title: "Blog — Posts", table: "blog_posts", columns: ["slug", "title", "status", "published_at"] },
  "design": { title: "Store Design — Banners", table: "store_banners", columns: ["placement", "content", "is_active", "starts_at", "ends_at"] },
  "integrations": { title: "Integrations", table: "integrations", columns: ["provider", "enabled", "status", "last_sync_at"], select: "id,store_id,provider,enabled,status,last_sync_at,created_at" },
  "settings": { title: "Settings", table: "store_settings", columns: ["key", "value"], orderBy: "key" },
  "users": { title: "Users & Permissions — Team", table: "store_users", columns: ["user_id", "role_id", "status", "created_at"] },
};

function Cell({ value }: { value: any }) {
  if (value == null) return <span className="text-slate-300">—</span>;
  if (typeof value === "object") return <span className="line-clamp-1 max-w-56 inline-block align-middle">{JSON.stringify(value)}</span>;
  if (typeof value === "boolean") return value ? "✓" : "—";
  return String(value).length > 60 ? String(value).slice(0, 60) + "…" : String(value);
}

export function ModulePage() {
  const { section } = useParams();
  const { store } = useTenant();
  const cfg = MODULES[section ?? ""];
  const { data: rows } = useQuery({
    queryKey: ["module", store!.id, section],
    enabled: !!cfg,
    queryFn: async () =>
      (await supabase.from(cfg.table).select(cfg.select ?? "*").eq("store_id", store!.id)
        .order(cfg.orderBy ?? "created_at", { ascending: cfg.orderBy === "key" })
        .limit(100)).data ?? [],
  });

  if (section === "payments") return <PaymentsPage />;
  if (!cfg) return <div className="p-8 text-slate-500">Unknown section: {section}</div>;

  return (
    <div className="p-8">
      <div className="flex items-baseline justify-between mb-6">
        <h1 className="text-2xl font-bold">{cfg.title}</h1>
        <span className="text-sm text-slate-500">{rows?.length ?? 0} records</span>
      </div>
      <div className="bg-white rounded-2xl border border-slate-200 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-start border-b border-slate-200 bg-slate-50">
              {cfg.columns.map((c) => <th key={c} className="text-start font-semibold px-4 py-3 text-slate-600">{c}</th>)}
            </tr>
          </thead>
          <tbody>
            {(rows ?? []).map((r: Row) => (
              <tr key={r.id ?? JSON.stringify(r[cfg.columns[0]])} className="border-b border-slate-100 last:border-0">
                {cfg.columns.map((c) => <td key={c} className="px-4 py-2.5"><Cell value={r[c]} /></td>)}
              </tr>
            ))}
            {!rows?.length && <tr><td colSpan={cfg.columns.length} className="px-4 py-10 text-center text-slate-400">No records yet</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function PaymentsPage() {
  const { store } = useTenant();
  const { data } = useQuery({
    queryKey: ["paystatus", store!.id],
    queryFn: async () => {
      const [stripe, cod] = await Promise.all([
        supabase.rpc("get_payment_provider_status", { p_store_id: store!.id, p_code: "stripe" }),
        supabase.rpc("get_payment_provider_status", { p_store_id: store!.id, p_code: "cod" }),
      ]);
      return { stripe: stripe.data as any, cod: cod.data as any };
    },
  });
  return (
    <div className="p-8 max-w-3xl">
      <h1 className="text-2xl font-bold mb-6">Payments</h1>
      <div className="space-y-4">
        {(["stripe", "cod"] as const).map((code) => {
          const s = data?.[code] ?? { enabled: false, status: "disconnected" };
          return (
            <div key={code} className="bg-white border border-slate-200 rounded-2xl p-6 flex items-center justify-between">
              <div>
                <div className="font-bold text-lg capitalize">{code === "cod" ? "Cash on Delivery" : "Stripe"}</div>
                <div className="text-sm text-slate-500">
                  Status: <span className={s.enabled ? "text-emerald-600 font-medium" : "text-slate-500"}>{s.enabled ? `enabled (${s.status}, ${s.mode ?? ""} mode)` : "disabled"}</span>
                </div>
              </div>
              <span className={`text-xs rounded-full px-3 py-1 font-semibold ${s.enabled ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
                {s.enabled ? "ACTIVE" : "OFF"}
              </span>
            </div>
          );
        })}
      </div>
      <p className="text-sm text-slate-500 mt-6 bg-slate-50 border border-slate-200 rounded-xl p-4">
        Stripe keys are stored in Supabase Vault per store and connected via the <code>connect-stripe</code> Edge
        Function (Stripe Connect onboarding) — no code changes or redeploys required. This admin connection UI ships
        in Phase 2 along with the function.
      </p>
    </div>
  );
}

export function Dashboard() {
  const { store, fmtMoney } = useTenant();
  const { data } = useQuery({
    queryKey: ["summary", store!.id],
    queryFn: async () => (await supabase.rpc("sales_summary", { p_store_id: store!.id })).data as any,
  });
  const { data: recent } = useQuery({
    queryKey: ["recent", store!.id],
    queryFn: async () => (await supabase.from("orders").select("id, order_number, total, status, payment_status, created_at").eq("store_id", store!.id).order("created_at", { ascending: false }).limit(6)).data ?? [],
  });
  const kpis = [
    { label: "Gross revenue (30d)", value: fmtMoney(Number(data?.gross_revenue ?? 0)) },
    { label: "Net revenue (30d)", value: fmtMoney(Number(data?.net_revenue ?? 0)) },
    { label: "Orders", value: String(data?.orders ?? 0) },
    { label: "Avg order value", value: fmtMoney(Number(data?.aov ?? 0)) },
  ];
  const days = (data?.by_day ?? []) as { day: string; revenue: number; orders: number }[];
  const max = Math.max(1, ...days.map((d) => Number(d.revenue)));
  return (
    <div className="p-8 space-y-8">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((k) => (
          <div key={k.label} className="bg-white rounded-2xl border border-slate-200 p-5">
            <div className="text-sm text-slate-500">{k.label}</div>
            <div className="text-2xl font-extrabold mt-1">{k.value}</div>
          </div>
        ))}
      </div>
      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <h2 className="font-bold mb-4">Revenue — last {days.length} days</h2>
        <div className="flex items-end gap-1.5 h-40">
          {days.map((d) => (
            <div key={d.day} title={`${d.day}: ${fmtMoney(Number(d.revenue))}`}
              className="flex-1 brand-primary rounded-t"
              style={{ height: `${Math.max(3, (Number(d.revenue) / max) * 100)}%`, opacity: 0.85 }} />
          ))}
          {!days.length && <div className="w-full skeleton h-full" />}
        </div>
      </div>
      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <h2 className="font-bold mb-4">Recent orders</h2>
        <div className="divide-y divide-slate-100 text-sm">
          {(recent ?? []).map((o: Row) => (
            <div key={o.id} className="py-2.5 flex items-center gap-4">
              <span className="font-semibold">{o.order_number}</span>
              <span className={`text-xs rounded-full px-2 py-0.5 ${o.payment_status === "paid" ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`}>{o.payment_status}</span>
              <span className="text-slate-500">{o.status}</span>
              <span className="ms-auto font-semibold">{fmtMoney(Number(o.total))}</span>
            </div>
          ))}
          {!recent?.length && <p className="text-slate-400 py-4">No orders yet.</p>}
        </div>
      </div>
    </div>
  );
}

export function ProductsAdmin() {
  const { store, locale } = useTenant();
  const qc = useQueryClient();
  const [form, setForm] = useState({ name: "", price: "", type: "physical", sku: "", inventory_qty: "0", slug: "" });
  const [error, setError] = useState<string | null>(null);
  const { data: products } = useQuery({
    queryKey: ["aproducts", store!.id],
    queryFn: async () => (await supabase.from("products").select("id,store_id,type,status,slug,sku,name,price,currency,track_inventory,inventory_qty,created_at,published_at").eq("store_id", store!.id).order("created_at", { ascending: false }).limit(100)).data ?? [],
  });
  const create = useMutation({
    mutationFn: async () => {
      setError(null);
      const slug = form.slug || form.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
      const { error } = await supabase.from("products").insert({
        store_id: store!.id, type: form.type, status: "draft",
        slug, sku: form.slug ? undefined : form.sku || null,
        name: { en: form.name, fr: form.name, ar: form.name },
        price: Number(form.price), inventory_qty: Number(form.inventory_qty),
        currency: store!.currency,
      });
      if (error) throw new Error(error.message);
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["aproducts"] }); setForm({ name: "", price: "", type: "physical", sku: "", inventory_qty: "0", slug: "" }); },
    onError: (e) => setError(e.message),
  });
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const publish = useMutation({
    mutationFn: async (p: Row) => {
      await supabase.from("products").update({ status: p.status === "active" ? "archived" : "active", published_at: new Date().toISOString() }).eq("id", p.id);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["aproducts"] }),
  });

  return (
    <div className="p-8 space-y-8">
      <h1 className="text-2xl font-bold">Products</h1>
      <form onSubmit={(e) => { e.preventDefault(); create.mutate(); }} className="bg-white rounded-2xl border border-slate-200 p-6 grid sm:grid-cols-6 gap-3">
        <input required placeholder="Product name" value={form.name} onChange={set("name")} className="sm:col-span-2 border border-slate-300 rounded-lg px-3 py-2" />
        <input required type="number" step="0.01" min="0" placeholder="Price" value={form.price} onChange={set("price")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <select value={form.type} onChange={set("type")} className="border border-slate-300 rounded-lg px-3 py-2">
          <option value="physical">Physical</option><option value="digital">Digital</option><option value="hybrid">Hybrid</option>
        </select>
        <input placeholder="SKU" value={form.sku} onChange={set("sku")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <input type="number" min="0" placeholder="Stock" value={form.inventory_qty} onChange={set("inventory_qty")} className="border border-slate-300 rounded-lg px-3 py-2" />
        {error && <p className="sm:col-span-6 text-sm text-red-600">{error}</p>}
        <button disabled={create.isPending} className="sm:col-span-6 brand-primary text-white rounded-lg py-2.5 font-semibold disabled:opacity-60 w-48">
          {create.isPending ? "Saving…" : "Add product"}
        </button>
      </form>
      <div className="bg-white rounded-2xl border border-slate-200 overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-slate-200 bg-slate-50 text-start">
            {["Name", "Price", "Type", "Stock", "Status", ""].map((h) => <th key={h} className="text-start font-semibold px-4 py-3 text-slate-600">{h}</th>)}
          </tr></thead>
          <tbody>
            {(products ?? []).map((p: Row) => (
              <tr key={p.id} className="border-b border-slate-100 last:border-0">
                <td className="px-4 py-2.5 font-medium">{loc(p.name, locale)}</td>
                <td className="px-4 py-2.5">{p.currency} {p.price}</td>
                <td className="px-4 py-2.5 capitalize">{p.type}</td>
                <td className="px-4 py-2.5">{p.track_inventory ? p.inventory_qty : "—"}</td>
                <td className="px-4 py-2.5">
                  <span className={`text-xs rounded-full px-2 py-0.5 ${p.status === "active" ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>{p.status}</span>
                </td>
                <td className="px-4 py-2.5">
                  <button onClick={() => publish.mutate(p)} className="text-xs font-semibold brand-primary-text hover:underline">
                    {p.status === "active" ? "Archive" : "Publish"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const ORDER_FLOW: Record<string, string[]> = {
  pending: ["confirmed", "cancelled"],
  confirmed: ["processing", "shipped", "cancelled"],
  processing: ["shipped", "cancelled"],
  shipped: ["delivered", "cancelled"],
  delivered: ["completed"],
  completed: [], cancelled: [],
};
const ADMIN_ERRORS: Record<string, string> = {
  PAYMENT_REQUIRED: "This online order is not paid yet — it cannot progress until Stripe confirms the payment.",
  REFUND_REQUIRED: "A paid order cannot be cancelled: refund it in Stripe first (the webhook updates the order).",
  PAYMENT_NOT_COLLECTED: "Confirm the cash collection before completing the order.",
  COD_NOT_DISPATCHED: "Cash can only be confirmed after the order has shipped.",
  ILLEGAL_TRANSITION: "That status change is not allowed from the current status.",
  ALREADY_SETTLED: "This payment is already settled.",
};

export function OrdersAdmin() {
  const { store, fmtMoney, fmtDate } = useTenant();
  const qc = useQueryClient();
  const [selected, setSelected] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const { data: orders } = useQuery({
    queryKey: ["aorders", store!.id],
    queryFn: async () => (await supabase.from("orders").select("*").eq("store_id", store!.id).order("created_at", { ascending: false }).limit(50)).data ?? [],
  });
  const { data: items } = useQuery({
    queryKey: ["oitems", selected], enabled: !!selected,
    queryFn: async () => (await supabase.from("order_items").select("*").eq("order_id", selected!)).data ?? [],
  });
  const act = useMutation({
    mutationFn: async ({ order, status }: { order: Row; status: string }) => {
      // Confirming an order, shipping it and collecting the cash are three separate, audited steps.
      const [rpc, args] =
        status === "__confirm_cod__" ? ["confirm_cod_order", { p_order_id: order.id }] :
        status === "__cod_collected__" ? ["mark_cod_collected", { p_order_id: order.id, p_note: note || null }] :
        ["update_order_status", { p_order_id: order.id, p_status: status, p_note: note || null }];
      const { error } = await supabase.rpc(rpc as string, args as never);
      if (error) {
        const hit = Object.keys(ADMIN_ERRORS).find((k) => error.message.includes(k));
        throw new Error(hit ? ADMIN_ERRORS[hit] : error.message);
      }
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["aorders"] }); qc.invalidateQueries({ queryKey: ["oitems"] }); setNote(""); },
  });

  return (
    <div className="p-8 grid lg:grid-cols-2 gap-8">
      <div>
        <h1 className="text-2xl font-bold mb-6">Orders</h1>
        <div className="space-y-2">
          {(orders ?? []).map((o: Row) => (
            <button key={o.id} onClick={() => setSelected(o.id)}
              className={`w-full text-start bg-white border rounded-xl p-4 flex items-center gap-3 ${selected === o.id ? "border-[var(--brand-primary)] ring-2" : "border-slate-200"}`}>
              <div className="flex-1">
                <div className="font-semibold text-sm">{o.order_number}</div>
                <div className="text-xs text-slate-500">{fmtDate(o.created_at)} · {o.customer_snapshot?.email ?? o.customer_snapshot?.phone ?? "guest"}</div>
              </div>
              <span className="text-xs rounded-full px-2 py-0.5 bg-amber-50 text-amber-700">{o.status}</span>
              <span className={`text-xs rounded-full px-2 py-0.5 ${["paid", "partially_refunded"].includes(o.payment_status) ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>{o.payment_status}</span>
              <span className="font-bold">{fmtMoney(Number(o.total))}</span>
            </button>
          ))}
          {!orders?.length && <p className="text-slate-400">No orders yet.</p>}
        </div>
      </div>
      <div>
        {selected && (() => {
          const order = (orders ?? []).find((o: Row) => o.id === selected);
          if (!order) return null;
          const paid = ["paid", "partially_refunded"].includes(order.payment_status);
          return (
            <div className="bg-white border border-slate-200 rounded-2xl p-6 sticky top-6">
              <h2 className="font-bold text-lg">{order.order_number}</h2>
              <p className="text-sm text-slate-500 mt-1">
                {String(order.payment_method).toUpperCase()} · payment: <b>{order.payment_status}</b> · fulfilment: {order.fulfillment_status}
              </p>
              <div className="mt-4 space-y-1.5 text-sm border-t border-slate-100 pt-4">
                {(items ?? []).map((i: Row) => (
                  <div key={i.id} className="flex justify-between"><span>{loc(i.name, "en")} × {i.qty}{i.is_digital ? " · digital" : ""}</span><span>{fmtMoney(Number(i.total))}</span></div>
                ))}
                {Number(order.discount_total) > 0 && <div className="flex justify-between text-slate-500"><span>Discount</span><span>−{fmtMoney(Number(order.discount_total))}</span></div>}
                {Number(order.shipping_total) > 0 && <div className="flex justify-between text-slate-500"><span>Shipping</span><span>{fmtMoney(Number(order.shipping_total))}</span></div>}
                {Number(order.tax_total) > 0 && <div className="flex justify-between text-slate-500"><span>Tax</span><span>{fmtMoney(Number(order.tax_total))}</span></div>}
                <div className="flex justify-between font-bold border-t border-slate-100 pt-2"><span>Total</span><span>{fmtMoney(Number(order.total))}</span></div>
              </div>
              {order.status === "pending" && order.payment_method === "cod" && (
                <button disabled={act.isPending} onClick={() => act.mutate({ order, status: "__confirm_cod__" })}
                  className="mt-4 w-full bg-emerald-600 text-white rounded-xl py-2.5 font-semibold disabled:opacity-60">
                  Confirm COD order (payment stays unpaid)
                </button>
              )}
              {order.payment_method === "cod" && !paid && ["shipped", "delivered"].includes(order.status) && (
                <button disabled={act.isPending} onClick={() => act.mutate({ order, status: "__cod_collected__" })}
                  className="mt-3 w-full bg-indigo-600 text-white rounded-xl py-2.5 font-semibold disabled:opacity-60">
                  Cash collected — mark as paid
                </button>
              )}
              <div className="mt-3 flex flex-wrap gap-2">
                {(ORDER_FLOW[order.status] ?? [])
                  .filter((s) => !(s === "confirmed" && order.payment_method === "cod" && order.status === "pending"))
                  .filter((s) => !(s === "cancelled" && paid))
                  .filter((s) => !(s === "completed" && !paid))
                  .map((s) => (
                    <button key={s} disabled={act.isPending} onClick={() => act.mutate({ order, status: s })}
                      className={`text-sm rounded-lg px-4 py-2 font-medium ${s === "cancelled" ? "bg-red-50 text-red-600" : "bg-slate-100 text-slate-700 hover:bg-slate-200"}`}>
                      Mark {s}
                    </button>
                  ))}
              </div>
              <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Status note (optional)" className="mt-3 w-full border border-slate-300 rounded-lg px-3 py-2 text-sm" />
              {act.isError && <p className="text-sm text-red-600 mt-2">{(act.error as Error).message}</p>}
            </div>
          );
        })()}
      </div>
    </div>
  );
}
