import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { useTenant } from "@/lib/tenant";

export function AffiliatesAdmin() {
  const { store, fmtMoney } = useTenant();
  const qc = useQueryClient();
  const [f, setF] = useState({ name: "", email: "", commission: "10" });
  const [error, setError] = useState<string | null>(null);

  const { data: affiliates } = useQuery({
    queryKey: ["affiliates", store!.id],
    queryFn: async () => (await supabase.from("affiliates").select("*").eq("store_id", store!.id).order("created_at")).data ?? [],
  });
  const { data: commissions } = useQuery({
    queryKey: ["commissions", store!.id],
    queryFn: async () => (await supabase.from("affiliate_commissions").select("*, affiliates(name, code)").eq("store_id", store!.id).order("created_at", { ascending: false }).limit(100)).data ?? [],
  });
  const invalidate = () => { qc.invalidateQueries({ queryKey: ["affiliates"] }); qc.invalidateQueries({ queryKey: ["commissions"] }); };

  const create = useMutation({
    mutationFn: async () => {
      setError(null);
      const code = f.name.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10) || Math.random().toString(36).slice(2, 8).toUpperCase();
      const { error } = await supabase.from("affiliates").insert({
        store_id: store!.id, name: f.name, email: f.email,
        code, commission_percent: Number(f.commission), status: "active",
      });
      if (error) throw new Error(error.message);
    },
    onSuccess: () => { invalidate(); setF({ name: "", email: "", commission: "10" }); },
    onError: (e) => setError((e as Error).message),
  });
  const setCommissionStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("affiliate_commissions").update({ status, paid_at: status === "paid" ? new Date().toISOString() : null }).eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: invalidate,
  });

  const pending = (commissions ?? []).filter((c: any) => c.status === "pending");
  const totals = {
    pending: pending.reduce((s: number, c: any) => s + Number(c.amount), 0),
    paid: (commissions ?? []).filter((c: any) => c.status === "paid").reduce((s: number, c: any) => s + Number(c.amount), 0),
  };

  return (
    <div className="p-8 space-y-8 max-w-5xl">
      <h1 className="text-2xl font-bold">Affiliate Marketing</h1>

      <div className="grid sm:grid-cols-2 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-5">
          <div className="text-sm text-slate-500">Pending commissions</div>
          <div className="text-2xl font-extrabold mt-1 text-amber-600">{fmtMoney(totals.pending)}</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-5">
          <div className="text-sm text-slate-500">Paid out</div>
          <div className="text-2xl font-extrabold mt-1 text-emerald-600">{fmtMoney(totals.paid)}</div>
        </div>
      </div>

      <form onSubmit={(e) => { e.preventDefault(); create.mutate(); }} className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-wrap gap-3 items-end">
        <div>
          <label className="text-xs font-semibold text-slate-500 block mb-1">Name</label>
          <input required value={f.name} onChange={(e) => setF((x) => ({ ...x, name: e.target.value }))} className="border border-slate-300 rounded-lg px-3 py-2" />
        </div>
        <div>
          <label className="text-xs font-semibold text-slate-500 block mb-1">Email</label>
          <input required type="email" value={f.email} onChange={(e) => setF((x) => ({ ...x, email: e.target.value }))} className="border border-slate-300 rounded-lg px-3 py-2" />
        </div>
        <div>
          <label className="text-xs font-semibold text-slate-500 block mb-1">Commission %</label>
          <input required type="number" min={0} max={100} step="0.5" value={f.commission} onChange={(e) => setF((x) => ({ ...x, commission: e.target.value }))} className="w-24 border border-slate-300 rounded-lg px-3 py-2" />
        </div>
        <button disabled={create.isPending} className="brand-primary text-white rounded-lg px-5 py-2 font-semibold disabled:opacity-60">
          {create.isPending ? "…" : "Add affiliate"}
        </button>
        {error && <p className="w-full text-sm text-red-600">{error}</p>}
      </form>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-slate-200 overflow-x-auto">
          <div className="px-5 py-4 font-bold border-b border-slate-100">Affiliates ({(affiliates ?? []).length})</div>
          <table className="w-full text-sm">
            <tbody>
              {(affiliates ?? []).map((a: any) => (
                <tr key={a.id} className="border-b border-slate-50 last:border-0">
                  <td className="px-5 py-3">
                    <div className="font-medium">{a.name}</div>
                    <div className="text-xs text-slate-400">{a.email} · {a.commission_percent}%</div>
                  </td>
                  <td className="px-5 py-3 font-mono text-xs">{a.code}</td>
                  <td className="px-5 py-3">
                    <span className={`text-xs rounded-full px-2 py-0.5 ${a.status === "active" ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>{a.status}</span>
                  </td>
                </tr>
              ))}
              {!affiliates?.length && <tr><td className="px-5 py-8 text-center text-slate-400">No affiliates yet</td></tr>}
            </tbody>
          </table>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 overflow-x-auto">
          <div className="px-5 py-4 font-bold border-b border-slate-100">Commissions ({(commissions ?? []).length})</div>
          <table className="w-full text-sm">
            <tbody>
              {(commissions ?? []).map((c: any) => (
                <tr key={c.id} className="border-b border-slate-50 last:border-0">
                  <td className="px-5 py-3">
                    <div className="font-medium">{c.affiliates?.name ?? "—"}</div>
                    <div className="text-xs text-slate-400">{fmtMoney(Number(c.amount))} · {c.rate}%</div>
                  </td>
                  <td className="px-5 py-3">
                    <span className={`text-xs rounded-full px-2 py-0.5 ${c.status === "paid" ? "bg-emerald-50 text-emerald-700" : c.status === "pending" ? "bg-amber-50 text-amber-700" : "bg-slate-100 text-slate-500"}`}>{c.status}</span>
                  </td>
                  <td className="px-5 py-3 space-x-2 whitespace-nowrap">
                    {c.status === "pending" && (
                      <>
                        <button onClick={() => setCommissionStatus.mutate({ id: c.id, status: "approved" })} className="text-xs font-semibold brand-primary-text hover:underline">Approve</button>
                        <button onClick={() => setCommissionStatus.mutate({ id: c.id, status: "paid" })} className="text-xs font-semibold text-emerald-600 hover:underline">Pay</button>
                      </>
                    )}
                    {c.status === "approved" && (
                      <button onClick={() => setCommissionStatus.mutate({ id: c.id, status: "paid" })} className="text-xs font-semibold text-emerald-600 hover:underline">Pay</button>
                    )}
                  </td>
                </tr>
              ))}
              {!commissions?.length && <tr><td className="px-5 py-8 text-center text-slate-400">No commissions yet</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
