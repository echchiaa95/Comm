import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { useTenant } from "@/lib/tenant";

const TRIGGERS = ["new_order", "payment_confirmed", "order_delivered", "customer_inactive", "low_stock"];

export function AutomationsAdmin() {
  const { store } = useTenant();
  const qc = useQueryClient();
  const [f, setF] = useState({ name: "", trigger: "new_order", min_total: "", days: "30", template: "order_confirmation", to: "customer", points: "50", code_prefix: "WIN", value: "10", subject: "Notification" });
  const [error, setError] = useState<string | null>(null);

  const { data: rules } = useQuery({
    queryKey: ["rules", store!.id],
    queryFn: async () => (await supabase.from("automation_rules").select("*").eq("store_id", store!.id).order("created_at")).data ?? [],
  });
  const invalidate = () => qc.invalidateQueries({ queryKey: ["rules"] });

  const buildActions = () => {
    if (f.trigger === "new_order" || f.trigger === "payment_confirmed" || f.trigger === "order_delivered") {
      if (f.template === "__points__") return [{ type: "add_loyalty_points", points: Number(f.points) }];
      return [{ type: "send_email", template_key: f.template, to: f.to }];
    }
    if (f.trigger === "customer_inactive") return [{ type: "generate_coupon", code_prefix: f.code_prefix, kind: "percent", value: Number(f.value), expires_days: 7 }];
    return [{ type: "notify_admin", subject: f.subject }];
  };

  const create = useMutation({
    mutationFn: async () => {
      setError(null);
      const { error } = await supabase.from("automation_rules").insert({
        store_id: store!.id, name: f.name, trigger_key: f.trigger,
        conditions: f.min_total ? { min_total: Number(f.min_total) } : f.days ? { days: Number(f.days) } : {},
        actions: buildActions(),
      });
      if (error) throw new Error(error.message);
    },
    onSuccess: () => { invalidate(); setF({ ...f, name: "" }); },
    onError: (e) => setError((e as Error).message),
  });
  const toggle = useMutation({
    mutationFn: async (r: any) => { await supabase.from("automation_rules").update({ enabled: !r.enabled }).eq("id", r.id); },
    onSuccess: invalidate,
  });
  const remove = useMutation({
    mutationFn: async (id: string) => { await supabase.from("automation_rules").delete().eq("id", id); },
    onSuccess: invalidate,
  });

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF((x) => ({ ...x, [k]: e.target.value }));

  return (
    <div className="p-8 space-y-8 max-w-4xl">
      <h1 className="text-2xl font-bold">Automation Engine — WHEN / IF / THEN</h1>

      <form onSubmit={(e) => { e.preventDefault(); create.mutate(); }} className="bg-white rounded-2xl border border-slate-200 p-6 grid sm:grid-cols-3 gap-3">
        <input required placeholder="Rule name" value={f.name} onChange={set("name")} className="border border-slate-300 rounded-lg px-3 py-2" />
        <select value={f.trigger} onChange={set("trigger")} className="border border-slate-300 rounded-lg px-3 py-2">
          {TRIGGERS.map((t) => <option key={t} value={t}>{t.replace(/_/g, " ")}</option>)}
        </select>
        {(f.trigger === "new_order" || f.trigger === "payment_confirmed" || f.trigger === "order_delivered") && (
          <input type="number" min={0} placeholder="IF total ≥ (optional)" value={f.min_total} onChange={set("min_total")} className="border border-slate-300 rounded-lg px-3 py-2" />
        )}
        {f.trigger === "customer_inactive" && (
          <input type="number" min={1} placeholder="IF inactive days" value={f.days} onChange={set("days")} className="border border-slate-300 rounded-lg px-3 py-2" />
        )}
        {(f.trigger === "new_order" || f.trigger === "payment_confirmed" || f.trigger === "order_delivered") && (
          <>
            <select value={f.template} onChange={set("template")} className="border border-slate-300 rounded-lg px-3 py-2">
              <option value="order_confirmation">THEN send: order confirmation</option>
              <option value="digital_delivery">THEN send: digital delivery</option>
              <option value="__points__">THEN add loyalty points</option>
            </select>
            {f.template !== "__points__" && (
              <select value={f.to} onChange={set("to")} className="border border-slate-300 rounded-lg px-3 py-2">
                <option value="customer">to customer</option><option value="admin">to admin</option>
              </select>
            )}
            {f.template === "__points__" && (
              <input type="number" min={1} placeholder="Points" value={f.points} onChange={set("points")} className="border border-slate-300 rounded-lg px-3 py-2" />
            )}
          </>
        )}
        {f.trigger === "customer_inactive" && (
          <>
            <input placeholder="Coupon prefix" value={f.code_prefix} onChange={set("code_prefix")} className="border border-slate-300 rounded-lg px-3 py-2" />
            <input type="number" min={1} max={100} placeholder="Discount %" value={f.value} onChange={set("value")} className="border border-slate-300 rounded-lg px-3 py-2" />
          </>
        )}
        {f.trigger === "low_stock" && (
          <input placeholder="Admin subject" value={f.subject} onChange={set("subject")} className="border border-slate-300 rounded-lg px-3 py-2" />
        )}
        {error && <p className="sm:col-span-3 text-sm text-red-600">{error}</p>}
        <button disabled={create.isPending} className="sm:col-span-3 brand-primary text-white rounded-lg py-2.5 font-semibold w-48 disabled:opacity-60">
          {create.isPending ? "Saving…" : "Create rule"}
        </button>
      </form>

      <div className="space-y-2">
        {(rules ?? []).map((r: any) => (
          <div key={r.id} className="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-4">
            <div className="flex-1">
              <div className="font-semibold">{r.name}</div>
              <div className="text-sm text-slate-500">
                WHEN <b>{r.trigger_key.replace(/_/g, " ")}</b>
                {Object.keys(r.conditions ?? {}).length > 0 && <> IF {JSON.stringify(r.conditions)}</>}
                <> THEN {(r.actions ?? []).map((a: any) => a.type).join(", ")}</>
              </div>
            </div>
            <button onClick={() => toggle.mutate(r)} className={`text-xs rounded-full px-3 py-1 font-semibold ${r.enabled ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
              {r.enabled ? "ON" : "OFF"}
            </button>
            <button onClick={() => remove.mutate(r.id)} className="text-xs font-semibold text-red-500 hover:underline">Delete</button>
          </div>
        ))}
        {!rules?.length && <p className="text-slate-400">No rules yet. Prebuilt templates ship in Phase 3.1.</p>}
      </div>
    </div>
  );
}
