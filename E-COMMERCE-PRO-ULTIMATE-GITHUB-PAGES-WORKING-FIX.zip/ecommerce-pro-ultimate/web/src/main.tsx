import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import App from "./App";
import { TenantProvider } from "./lib/tenant";
import "./index.css";

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 30_000, retry: 1 } },
});

// GitHub Pages hosts this project below /<repository>/.
// Use Vite's BASE_URL for routing and disable the root-scoped PWA worker there.
// GitHub Pages project sites are served below /<repository>/.
// BASE_URL is supplied by Vite and always ends with a slash.
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");
const pathname = window.location.pathname;
const pathWithoutBase = pathname.startsWith(`${basePath}/`)
  ? pathname.slice(basePath.length)
  : pathname === basePath
    ? "/"
    : pathname;
const prefix = pathWithoutBase.match(/^\/(en|fr|ar)(?=\/|$)/)?.[0] ?? "";
const routerBase = `${basePath}${prefix}` || "/";

if ("serviceWorker" in navigator && import.meta.env.PROD && import.meta.env.BASE_URL === "/") {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register(`${import.meta.env.BASE_URL}sw.js`).catch(() => {});
  });
}

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <BrowserRouter basename={routerBase}>
        <TenantProvider>
          <App />
        </TenantProvider>
      </BrowserRouter>
    </QueryClientProvider>
  </React.StrictMode>,
);
