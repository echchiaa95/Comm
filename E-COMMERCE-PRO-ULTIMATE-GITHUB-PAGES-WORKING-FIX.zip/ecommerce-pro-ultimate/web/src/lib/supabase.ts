import { createClient } from "@supabase/supabase-js";

// Public anon client. RLS + SECURITY DEFINER functions enforce every rule;
// no secret ever ships to the browser.
export const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL as string,
  import.meta.env.VITE_SUPABASE_ANON_KEY as string,
);

export type Localized = { en?: string; fr?: string; ar?: string };
export const loc = (v: Localized | string | null | undefined, locale: string): string => {
  if (!v) return "";
  if (typeof v === "string") return v;
  const key = locale as keyof Localized;
  return v[key] ?? v.en ?? v.fr ?? v.ar ?? "";
};
