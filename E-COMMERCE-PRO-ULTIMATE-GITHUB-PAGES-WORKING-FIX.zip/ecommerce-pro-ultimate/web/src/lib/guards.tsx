import { ReactNode, useEffect, useState } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { supabase } from "./supabase";
import { useTenant } from "./tenant";

export function useSession() {
  const [state, setState] = useState<{ user: { id: string; email?: string } | null; loading: boolean }>({
    user: null, loading: true,
  });
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setState({ user: data.session?.user ?? null, loading: false });
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setState({ user: session?.user ?? null, loading: false });
    });
    return () => sub.subscription.unsubscribe();
  }, []);
  return state;
}

export function RequireAuth({ children }: { children: ReactNode }) {
  const { user, loading } = useSession();
  const loc = useLocation();
  if (loading) return <div className="p-10 skeleton h-40" />;
  if (!user) return <Navigate to="/login" state={{ from: loc.pathname }} replace />;
  return <>{children}</>;
}

// Permission check goes through the SECURITY DEFINER SQL function — the client
// never decides access itself.
export function RequirePermission({ permission, children }: { permission: string; children: ReactNode }) {
  const { store } = useTenant();
  const [allowed, setAllowed] = useState<boolean | null>(null);
  useEffect(() => {
    if (!store) return;
    supabase.rpc("has_store_access", { p_store_id: store.id, p_permission: permission })
      .then(({ data }) => setAllowed(Boolean(data)));
  }, [store, permission]);
  if (allowed === null) return <div className="p-10 skeleton h-40" />;
  if (!allowed) return <Navigate to="/admin" replace />;
  return <>{children}</>;
}
