import { createContext, useContext, useEffect, useMemo, useState, ReactNode } from "react";
import { supabase } from "./supabase";

export type Store = {
  id: string; slug: string; name: string; description?: string;
  business_model: "physical" | "digital" | "hybrid";
  locale: string; currency: string; timezone: string;
  brand: Record<string, string>; design: Record<string, unknown>;
  logo_url?: string; whatsapp_number?: string; social_links?: Record<string, string>;
  country?: string; city?: string; locales?: string[];
};

const DICT = {
  en: { home: "Home", search: "Search", cart: "Cart", checkout: "Checkout", add_to_cart: "Add to cart", buy_now: "Buy now", categories: "Categories", new_arrivals: "New arrivals", best_sellers: "Best sellers", featured: "Featured", in_stock: "In stock", out_of_stock: "Out of stock", reviews: "Reviews", related_products: "Related products", subtotal: "Subtotal", shipping: "Shipping", total: "Total", discount: "Discount", coupon_code: "Coupon code", apply: "Apply", place_order: "Place order", first_name: "First name", last_name: "Last name", email: "Email", phone: "Phone", country: "Country", city: "City", address: "Address", continue: "Continue", order_confirmed: "Order confirmed", cod: "Cash on Delivery", pay_card: "Pay by card", empty_cart: "Your cart is empty", newsletter: "Subscribe to our newsletter", subscribe: "Subscribe", free_shipping_over: "Free shipping over", all: "All", sort: "Sort", price: "Price", name: "Name", newest: "Newest", notes: "Order notes", payment: "Payment", my_account: "My account", language: "Language" },
  fr: { home: "Accueil", search: "Rechercher", cart: "Panier", checkout: "Paiement", add_to_cart: "Ajouter au panier", buy_now: "Acheter maintenant", categories: "Catégories", new_arrivals: "Nouveautés", best_sellers: "Meilleures ventes", featured: "En vedette", in_stock: "En stock", out_of_stock: "Rupture de stock", reviews: "Avis", related_products: "Produits similaires", subtotal: "Sous-total", shipping: "Livraison", total: "Total", discount: "Remise", coupon_code: "Code promo", apply: "Appliquer", place_order: "Passer la commande", first_name: "Prénom", last_name: "Nom", email: "E-mail", phone: "Téléphone", country: "Pays", city: "Ville", address: "Adresse", continue: "Continuer", order_confirmed: "Commande confirmée", cod: "Paiement à la livraison", pay_card: "Payer par carte", empty_cart: "Votre panier est vide", newsletter: "Abonnez-vous à notre newsletter", subscribe: "S'abonner", free_shipping_over: "Livraison gratuite dès", all: "Tout", sort: "Trier", price: "Prix", name: "Nom", newest: "Nouveauté", notes: "Notes de commande", payment: "Paiement", my_account: "Mon compte", language: "Langue" },
  ar: { home: "الرئيسية", search: "بحث", cart: "السلة", checkout: "إتمام الشراء", add_to_cart: "أضف إلى السلة", buy_now: "اشترِ الآن", categories: "الفئات", new_arrivals: "وصل حديثاً", best_sellers: "الأكثر مبيعاً", featured: "مميز", in_stock: "متوفر", out_of_stock: "نفدت الكمية", reviews: "التقييمات", related_products: "منتجات مشابهة", subtotal: "المجموع الفرعي", shipping: "التوصيل", total: "الإجمالي", discount: "الخصم", coupon_code: "كود الخصم", apply: "تطبيق", place_order: "تأكيد الطلب", first_name: "الاسم الأول", last_name: "الاسم الأخير", email: "البريد الإلكتروني", phone: "الهاتف", country: "الدولة", city: "المدينة", address: "العنوان", continue: "متابعة", order_confirmed: "تم تأكيد الطلب", cod: "الدفع عند الاستلام", pay_card: "الدفع بالبطاقة", empty_cart: "سلتك فارغة", newsletter: "اشترك في نشرتنا البريدية", subscribe: "اشترك", free_shipping_over: "توصيل مجاني للطلبات فوق", all: "الكل", sort: "ترتيب", price: "السعر", name: "الاسم", newest: "الأحدث", notes: "ملاحظات الطلب", payment: "الدفع", my_account: "حسابي", language: "اللغة" },
} as const;
export type Locale = "en" | "fr" | "ar";

type TenantCtx = {
  store: Store | null;
  loading: boolean;
  locale: Locale;
  dir: "ltr" | "rtl";
  setLocale: (l: Locale) => void;
  t: (key: keyof typeof DICT.en) => string;
  fmtMoney: (amount: number) => string;
  fmtDate: (d: string | Date) => string;
};

const Ctx = createContext<TenantCtx | null>(null);

export function TenantProvider({ children }: { children: ReactNode }) {
  const [store, setStore] = useState<Store | null>(null);
  const [loading, setLoading] = useState(true);
  const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");
  const currentPath = window.location.pathname.startsWith(`${basePath}/`)
    ? window.location.pathname.slice(basePath.length)
    : window.location.pathname === basePath ? "/" : window.location.pathname;
  const urlLocale = currentPath.match(/^\/(en|fr|ar)(?=\/|$)/)?.[1] as Locale | undefined;
  const [locale, setLocaleState] = useState<Locale>(
    urlLocale ?? (localStorage.getItem("epu_locale") as Locale) ?? "en",
  );

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const host = window.location.hostname;
        const { data, error } = await supabase.rpc("resolve_store", { p_domain: host });
        if (error) console.error("Store domain lookup failed:", error.message);
        let resolved = (data as Store | null) ?? null;
        const fallbackSlug = (import.meta.env.VITE_DEFAULT_STORE_SLUG as string | undefined)
          || localStorage.getItem("epu_store_slug");
        if (!resolved && fallbackSlug) {
          const fallback = await supabase.rpc("resolve_store", { p_domain: fallbackSlug });
          if (fallback.error) console.error("Store slug lookup failed:", fallback.error.message);
          resolved = (fallback.data as Store | null) ?? null;
        }
        if (!active) return;
        setStore(resolved);
        if (resolved && !urlLocale && !localStorage.getItem("epu_locale")) {
          setLocaleState((resolved.locale as Locale) || "en");
        }
      } catch (error) {
        console.error("Store initialization failed:", error);
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => { active = false; };
  }, []);

  const dir = locale === "ar" ? "rtl" : "ltr";
  useEffect(() => {
    document.documentElement.dir = dir;
    document.documentElement.lang = locale;
  }, [dir, locale]);

  // Brand tokens → CSS variables: design changes apply with zero code edits.
  useEffect(() => {
    const r = document.documentElement.style;
    if (!store) return;
    if (store.brand?.primary) r.setProperty("--brand-primary", store.brand.primary);
    if (store.brand?.accent) r.setProperty("--brand-accent", store.brand.accent);
    if (store.brand?.bg) r.setProperty("--brand-bg", store.brand.bg);
    if (store.brand?.text) r.setProperty("--brand-text", store.brand.text);
  }, [store]);

  const value = useMemo<TenantCtx>(() => ({
    store, loading, locale, dir,
    setLocale: (l) => {
      localStorage.setItem("epu_locale", l);
      // Navigate to the localized URL (full load so hreflang/canonical/lang/dir are all consistent).
      const rest = currentPath.replace(/^\/(en|fr|ar)(?=\/|$)/, "") || "/";
      const localized = store && l === store.locale
        ? rest
        : `/${l}${rest === "/" ? "" : rest}`;
      window.location.assign(`${basePath}${localized}` + window.location.search + window.location.hash);
    },
    t: (key) => DICT[locale][key] ?? DICT.en[key] ?? key,
    fmtMoney: (amount) => new Intl.NumberFormat(locale, {
      style: "currency", currency: store?.currency ?? "USD",
    }).format(amount),
    fmtDate: (d) => new Intl.DateTimeFormat(locale, { dateStyle: "medium" }).format(new Date(d)),
  }), [store, loading, locale, dir]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useTenant() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useTenant must be used inside TenantProvider");
  return ctx;
}
