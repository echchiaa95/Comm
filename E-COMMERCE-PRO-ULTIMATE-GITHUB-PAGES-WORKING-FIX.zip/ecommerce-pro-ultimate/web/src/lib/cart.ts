import { useEffect, useState } from "react";

export type CartLine = { product_id: string; variant_id: string | null; qty: number };

const KEY = "epu_cart";
const read = (): CartLine[] => {
  try { return JSON.parse(localStorage.getItem(KEY) ?? "[]"); } catch { return []; }
};
const write = (lines: CartLine[]) => {
  localStorage.setItem(KEY, JSON.stringify(lines));
  window.dispatchEvent(new Event("epu_cart"));
};

export const cart = {
  lines: read,
  add(line: CartLine) {
    const lines = read();
    const hit = lines.find((l) => l.product_id === line.product_id && l.variant_id === line.variant_id);
    if (hit) hit.qty = Math.min(99, hit.qty + line.qty); else lines.push(line);
    write(lines);
  },
  setQty(product_id: string, variant_id: string | null, qty: number) {
    write(read().map((l) => (l.product_id === product_id && l.variant_id === variant_id ? { ...l, qty } : l)).filter((l) => l.qty > 0));
  },
  replace: (lines: CartLine[]) => write(lines.filter((l) => l.qty > 0 && l.qty <= 99)),
  clear: () => write([]),
};

export function useCart() {
  const [lines, setLines] = useState<CartLine[]>(read);
  useEffect(() => {
    const sync = () => setLines(read());
    window.addEventListener("epu_cart", sync);
    window.addEventListener("storage", sync);
    return () => { window.removeEventListener("epu_cart", sync); window.removeEventListener("storage", sync); };
  }, []);
  return lines;
}

export function useCartCount() {
  const lines = useCart();
  return lines.reduce((n, l) => n + l.qty, 0);
}
