import { NavLink, Outlet, Link } from "react-router-dom";
import { useTenant } from "@/lib/tenant";

const GROUPS: { label: string; items: { label: string; to: string }[] }[] = [
  { label: "Overview", items: [
    { label: "Dashboard", to: "/admin" },
    { label: "Analytics", to: "/admin/analytics" },
    { label: "A/B Testing", to: "/admin/ab-testing" },
  ]},
  { label: "Catalog", items: [
    { label: "Products", to: "/admin/products" },
    { label: "Categories", to: "/admin/categories" },
    { label: "Inventory", to: "/admin/inventory" },
    { label: "Digital Downloads", to: "/admin/digital-downloads" },
  ]},
  { label: "Sales", items: [
    { label: "Orders", to: "/admin/orders" },
    { label: "Customers", to: "/admin/customers" },
    { label: "Shipping", to: "/admin/shipping" },
  ]},
  { label: "Growth", items: [
    { label: "Marketing Center", to: "/admin/campaigns" },
    { label: "Automations", to: "/admin/automations" },
    { label: "Email Templates", to: "/admin/email-templates" },
    { label: "Popups", to: "/admin/popups" },
    { label: "WhatsApp Marketing", to: "/admin/whatsapp" },
    { label: "Loyalty Program", to: "/admin/loyalty" },
    { label: "Affiliate Marketing", to: "/admin/affiliates" },
    { label: "Reviews", to: "/admin/reviews" },
    { label: "Discounts", to: "/admin/discounts" },
  ]},
  { label: "Content", items: [
    { label: "SEO Center", to: "/admin/seo" },
    { label: "Blog", to: "/admin/blog" },
    { label: "Store Design", to: "/admin/design" },
  ]},
  { label: "System", items: [
    { label: "Payments", to: "/admin/payments" },
    { label: "Integrations", to: "/admin/integrations" },
    { label: "Settings", to: "/admin/settings" },
    { label: "Users & Permissions", to: "/admin/users" },
  ]},
];

export default function AdminLayout() {
  const { store, dir } = useTenant();
  return (
    <div className="min-h-screen bg-slate-100 flex" dir={dir}>
      <aside className="w-64 shrink-0 bg-slate-900 text-slate-300 flex flex-col sticky top-0 h-screen overflow-y-auto">
        <div className="px-5 py-4 text-white font-bold border-b border-slate-800">
          {store?.name ?? "Store"} <span className="block text-xs font-normal text-slate-400">Administration</span>
        </div>
        <nav className="flex-1 p-3 space-y-5">
          {GROUPS.map((g) => (
            <div key={g.label}>
              <div className="px-2 text-xs uppercase tracking-wider text-slate-500 mb-1">{g.label}</div>
              {g.items.map((item) => (
                <NavLink key={item.to} to={item.to} end={item.to === "/admin"}
                  className={({ isActive }) =>
                    `block px-2 py-1.5 rounded-lg text-sm ${isActive ? "bg-slate-800 text-white" : "hover:text-white"}`}>
                  {item.label}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>
        <div className="p-3 border-t border-slate-800 text-sm">
          <Link to="/" className="block px-2 py-1.5 hover:text-white">← View storefront</Link>
        </div>
      </aside>
      <div className="flex-1 min-w-0">
        <Outlet />
      </div>
    </div>
  );
}
