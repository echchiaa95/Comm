import { useQuery } from "@tanstack/react-query";
import { Link, NavLink, Outlet } from "react-router-dom";
import { supabase, loc } from "@/lib/supabase";
import { useTenant } from "@/lib/tenant";
import { useCartCount } from "@/lib/cart";
import { PopupEngine } from "@/components/PopupEngine";
import { Analytics } from "@/components/Analytics";
import { NewsletterForm, RecentlyViewedRail, Track } from "@/components/Discovery";

export default function StorefrontLayout() {
  const { store, t, locale, setLocale, dir } = useTenant();
  const cartCount = useCartCount();

  const { data: nav } = useQuery({
    queryKey: ["nav", store?.id],
    queryFn: async () => {
      const { data } = await supabase.from("store_navigation").select("items").eq("store_id", store!.id).eq("menu_key", "header").maybeSingle();
      return (data?.items ?? []) as { label: Record<string, string>; path: string }[];
    },
    enabled: !!store,
  });

  const { data: announcement } = useQuery({
    queryKey: ["announcement", store?.id],
    queryFn: async () => {
      const { data } = await supabase.from("store_banners").select("content")
        .eq("store_id", store!.id).eq("placement", "announcement").eq("is_active", true)
        .order("sort_order").limit(1).maybeSingle();
      return data?.content as { text?: Record<string, string> } | null;
    },
    enabled: !!store,
  });

  return (
    <div className="min-h-screen flex flex-col" dir={dir}>
      {announcement?.text && (
        <div className="brand-primary text-white text-center text-sm py-2 px-4">
          {loc(announcement.text, locale)}
        </div>
      )}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center gap-6">
          <Link to="/" className="font-extrabold text-lg brand-primary-text shrink-0">
            {store?.logo_url ? <img src={store.logo_url} alt={store.name} className="h-8" /> : store?.name}
          </Link>
          <nav className="hidden md:flex items-center gap-5 text-sm font-medium">
            {nav?.map((item, i) => (
              <NavLink key={i} to={item.path} className={({ isActive }) => isActive ? "brand-primary-text" : "text-slate-600 hover:text-slate-900"}>
                {loc(item.label, locale)}
              </NavLink>
            ))}
          </nav>
          <form action="/search" className="flex-1 max-w-md ms-auto">
            <input name="q" placeholder={t("search")} className="w-full rounded-full border border-slate-300 px-4 py-2 text-sm focus:outline-none focus:ring-2" style={{ ["--tw-ring-color" as string]: "var(--brand-primary)" }} />
          </form>
          <select value={locale} onChange={(e) => setLocale(e.target.value as "en" | "fr" | "ar")}
            className="text-sm border border-slate-300 rounded-lg px-2 py-1.5" aria-label={t("language")}>
            <option value="en">EN</option><option value="fr">FR</option><option value="ar">عربي</option>
          </select>
          <Link to="/account" className="hidden sm:block text-sm font-semibold">{t("my_account")}</Link>
          <Link to="/cart" className="relative text-sm font-semibold">
            {t("cart")}
            {cartCount > 0 && <span className="absolute -top-2 -end-2 brand-primary text-white text-xs rounded-full px-1.5">{cartCount}</span>}
          </Link>
        </div>
      </header>
      <main className="flex-1">
        <Track />
        <Outlet />
        <RecentlyViewedRail />
      </main>
      <PopupEngine />
      <Analytics />
      <footer className="border-t border-slate-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 py-10 text-sm text-slate-500 flex flex-wrap gap-6 justify-between">
          <div>© {new Date().getFullYear()} {store?.name}</div>
          <NewsletterForm />
          {store?.whatsapp_number && (
            <a href={`https://wa.me/${store.whatsapp_number.replace(/[^0-9]/g, "")}`} target="_blank" rel="noreferrer" className="brand-primary-text font-semibold">WhatsApp</a>
          )}
        </div>
      </footer>
    </div>
  );
}
