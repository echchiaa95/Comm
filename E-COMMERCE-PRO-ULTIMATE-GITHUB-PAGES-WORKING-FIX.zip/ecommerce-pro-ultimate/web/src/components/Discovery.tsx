import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase, loc } from "@/lib/supabase";
import { useTenant } from "@/lib/tenant";

const sid = () => {
  let s = sessionStorage.getItem("epu_sid");
  if (!s) { s = crypto.randomUUID(); sessionStorage.setItem("epu_sid", s); }
  return s;
};

type Recent = { id: string; slug: string };
const readRecents = (): Recent[] => {
  try { return JSON.parse(localStorage.getItem("epu_recent") ?? "[]"); } catch { return []; }
};

// Invisible tracker: page_view analytics + recently-viewed (localStorage, max 10).
export function Track() {
  const { pathname, search } = useLocation();
  const { store } = useTenant();
  useEffect(() => {
    if (!store) return;
    // Referral capture: ?ref=CODE persists until order placement attributes it
    const ref = new URLSearchParams(search).get("ref");
    if (ref) localStorage.setItem("epu_ref", ref.toUpperCase());
    const visits = Number(localStorage.getItem("epu_visits") ?? "0") + 1;
    localStorage.setItem("epu_visits", String(visits));
    if (visits > 1) localStorage.setItem("epu_returning", "1");

    supabase.rpc("record_analytics_event", {
      p_store_id: store.id, p_session_key: sid(),
      p_event: "page_view", p_path: pathname,
    }).then(() => {});

    const m = pathname.match(/^\/product\/([^/]+)/);
    if (m) {
      supabase.from("products").select("id, slug").eq("store_id", store.id).eq("slug", m[1]).maybeSingle()
        .then(({ data }) => {
          if (!data) return;
          const next = [{ id: data.id, slug: data.slug }, ...readRecents().filter((r) => r.id !== data.id)].slice(0, 10);
          localStorage.setItem("epu_recent", JSON.stringify(next));
          window.dispatchEvent(new Event("epu_recent"));
        });
    }
  }, [pathname, store]);
  return null;
}

export function RecentlyViewedRail() {
  const { store, locale } = useTenant();
  const { pathname } = useLocation();
  const [recents, setRecents] = useState<Recent[]>(readRecents);
  useEffect(() => {
    const sync = () => setRecents(readRecents());
    window.addEventListener("epu_recent", sync);
    return () => window.removeEventListener("epu_recent", sync);
  }, []);
  const ids = recents.map((r) => r.id).filter((id) => !pathname.startsWith(`/product/${recents.find((r) => r.id === id)?.slug}`) || true);
  const { data: products } = useQuery({
    queryKey: ["recent", store!.id, ids.join(",")],
    enabled: recents.length > 0,
    queryFn: async () => (await supabase.from("products").select("id, slug, name, price, currency").in("id", ids).eq("status", "active")).data ?? [],
  });
  if (!products?.length) return null;
  const ordered = ids.map((id) => products.find((p: any) => p.id === id)).filter(Boolean).filter((p: any) => !pathname.startsWith(`/product/${p.slug}`));
  if (ordered.length < 2) return null;
  return (
    <section className="max-w-7xl mx-auto px-4 mt-14">
      <h2 className="text-xl font-bold mb-4">{locale === "ar" ? "شوهدت مؤخراً" : locale === "fr" ? "Vus récemment" : "Recently viewed"}</h2>
      <div className="flex gap-4 overflow-x-auto pb-2">
        {ordered.slice(0, 8).map((p: any) => (
          <Link key={p.id} to={`/product/${p.slug}`} className="w-40 shrink-0">
            <div className="aspect-square rounded-xl bg-slate-100 grid place-items-center text-2xl font-bold text-slate-300">{loc(p.name, locale)?.[0]}</div>
            <div className="text-sm font-medium mt-2 line-clamp-1">{loc(p.name, locale)}</div>
            <div className="text-sm brand-primary-text font-semibold">{new Intl.NumberFormat(locale, { style: "currency", currency: p.currency ?? "USD" }).format(Number(p.price))}</div>
          </Link>
        ))}
      </div>
    </section>
  );
}

export function NewsletterForm() {
  const { store } = useTenant();
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "busy" | "done" | "error">("idle");
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setState("busy");
    const { error } = await supabase.rpc("subscribe_newsletter", { p_store_id: store!.id, p_email: email, p_source: "footer" });
    setState(error ? "error" : "done");
  }
  if (state === "done") return <p className="text-emerald-600 font-medium">✓</p>;
  return (
    <form onSubmit={submit} className="flex gap-2">
      <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com"
        className="border border-slate-300 rounded-lg px-3 py-2 text-slate-800 text-sm" />
      <button disabled={state === "busy"} className="brand-primary text-white rounded-lg px-4 py-2 text-sm font-semibold disabled:opacity-60">
        {state === "error" ? "Retry" : "Subscribe"}
      </button>
    </form>
  );
}
