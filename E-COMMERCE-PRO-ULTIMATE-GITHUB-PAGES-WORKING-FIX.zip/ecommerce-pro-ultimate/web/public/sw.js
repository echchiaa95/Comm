// E-Commerce Pro — service worker v2.
// Strategy: hashed build assets are cache-first (immutable); page navigations are NETWORK-FIRST so a new deploy is
// never masked by a stale index.html (stale index → missing hashed assets → blank page). Offline: cached shell.
// NEVER cached: non-GET, Supabase/API traffic, Edge Functions, Stripe, signed download URLs, and any private
// route (admin, account, checkout, orders, downloads, login). Private pages are not stored even as a shell.
const CACHE = "epu-v2";
const PRIVATE = /^\/(?:(?:en|fr|ar)\/)?(?:admin|account|checkout|order|downloads|login|cart)(?:\/|$)/;

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(["/", "/icon.svg", "/manifest.webmanifest"])).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;                                   // Supabase, Stripe, fonts: network only
  if (url.pathname.startsWith("/functions/") || url.pathname.startsWith("/rest/") || url.pathname.startsWith("/auth/")) return;
  if (req.headers.has("authorization") || req.headers.has("range")) return;

  if (url.pathname.startsWith("/assets/")) {                                         // immutable hashed files
    e.respondWith(caches.match(req).then((hit) => hit ?? fetch(req).then((res) => {
      if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); }
      return res;
    })));
    return;
  }

  if (req.mode === "navigate") {
    if (PRIVATE.test(url.pathname)) return;                                          // private routes: always network, never stored
    e.respondWith(fetch(req).catch(() => caches.match("/")));                       // offline → generic shell
  }
});
