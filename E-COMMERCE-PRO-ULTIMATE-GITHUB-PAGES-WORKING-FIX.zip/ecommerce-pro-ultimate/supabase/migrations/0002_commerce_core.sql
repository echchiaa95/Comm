-- ============================================================================
-- 0002_commerce_core — V1.1 repair: the commerce tables that 0001 referenced
-- but never defined, the forward foreign keys that were deferred from 0001,
-- the relocated policies/triggers, and a corrected has_store_access().
--
-- Dependency order inside this file:
--   customers → addresses → carts → shipping → orders → order_items/history →
--   payment_providers → payments → payment_events → refunds → shipments →
--   digital_downloads → license_keys → download_logs → forward FKs → RLS.
-- Idempotent: every object uses IF NOT EXISTS / guarded DO blocks.
-- ============================================================================
set check_function_bodies = off;

-- ----------------------------------------------------------------------------
-- 0. Tenant-consistency anchors: (id, store_id) unique so child tables can use
--    composite FKs and the database itself rejects cross-store references.
-- ----------------------------------------------------------------------------
do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'products_id_store_uk') then
    alter table public.products add constraint products_id_store_uk unique (id, store_id);
  end if;
end $$;

-- ----------------------------------------------------------------------------
-- 1. Customers
-- ----------------------------------------------------------------------------
create table if not exists public.customers (
  id            uuid primary key default gen_random_uuid(),
  store_id      uuid not null references public.stores(id) on delete cascade,
  user_id       uuid references auth.users(id) on delete set null,   -- linked shopper account (optional: guest checkout)
  first_name    text, last_name text,
  email         text check (email is null or email = lower(email)),
  phone         text,
  accepts_marketing boolean not null default false,                   -- mirror only; marketing_consents is the source of truth
  referral_code text,
  total_orders  int not null default 0,
  total_spent   numeric(14,2) not null default 0,
  last_order_at timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  constraint customers_id_store_uk unique (id, store_id)
);
create unique index if not exists customers_store_email_uidx on public.customers (store_id, email) where email is not null;
create unique index if not exists customers_store_user_uidx  on public.customers (store_id, user_id) where user_id is not null;
create unique index if not exists customers_store_refcode_uidx on public.customers (store_id, referral_code) where referral_code is not null;
create index if not exists customers_user_idx on public.customers (user_id) where user_id is not null;
drop trigger if exists customers_updated on public.customers;
create trigger customers_updated before update on public.customers
  for each row execute function public.set_updated_at();

create table if not exists public.customer_addresses (
  id          uuid primary key default gen_random_uuid(),
  store_id    uuid not null references public.stores(id) on delete cascade,
  customer_id uuid not null,
  label       text,
  recipient   text,
  phone       text,
  country     char(2) not null,
  region      text, city text not null,
  address1    text not null, address2 text, postal_code text,
  is_default  boolean not null default false,
  created_at  timestamptz not null default now(),
  foreign key (customer_id, store_id) references public.customers (id, store_id) on delete cascade
);
create index if not exists customer_addresses_customer_idx on public.customer_addresses (customer_id);

-- ----------------------------------------------------------------------------
-- 2. Carts (server-side snapshot written by place_order; recovery source)
-- ----------------------------------------------------------------------------
create table if not exists public.carts (
  id          uuid primary key default gen_random_uuid(),
  store_id    uuid not null references public.stores(id) on delete cascade,
  customer_id uuid,
  session_key text,
  status      text not null default 'active' check (status in ('active','converted','abandoned')),
  currency    char(3) not null default 'USD',
  coupon_id   uuid references public.coupons(id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  constraint carts_id_store_uk unique (id, store_id),
  foreign key (customer_id, store_id) references public.customers (id, store_id) on delete set null (customer_id)
);
create index if not exists carts_store_status_idx on public.carts (store_id, status);
drop trigger if exists carts_updated on public.carts;
create trigger carts_updated before update on public.carts for each row execute function public.set_updated_at();

create table if not exists public.cart_items (
  id         uuid primary key default gen_random_uuid(),
  cart_id    uuid not null,
  store_id   uuid not null references public.stores(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  variant_id uuid references public.product_variants(id) on delete set null,
  qty        int not null check (qty between 1 and 99),
  unit_price numeric(12,2) not null check (unit_price >= 0),
  created_at timestamptz not null default now(),
  foreign key (cart_id, store_id) references public.carts (id, store_id) on delete cascade
);
create index if not exists cart_items_cart_idx on public.cart_items (cart_id);

-- ----------------------------------------------------------------------------
-- 3. Shipping
-- ----------------------------------------------------------------------------
create table if not exists public.shipping_zones (
  id        uuid primary key default gen_random_uuid(),
  store_id  uuid not null references public.stores(id) on delete cascade,
  name      text not null,
  countries jsonb not null default '[]'::jsonb check (jsonb_typeof(countries) = 'array'),   -- ["MA"] or ["*"]
  cities    jsonb check (cities is null or jsonb_typeof(cities) = 'array'),                  -- null = every city
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  constraint shipping_zones_id_store_uk unique (id, store_id)
);
create index if not exists shipping_zones_store_idx on public.shipping_zones (store_id);

create table if not exists public.shipping_methods (
  id        uuid primary key default gen_random_uuid(),
  store_id  uuid not null references public.stores(id) on delete cascade,
  zone_id   uuid not null,
  name      jsonb not null,                                   -- localized {"en":…,"fr":…,"ar":…}
  type      text not null default 'flat' check (type in ('flat','free_threshold','weight_based','pickup')),
  base_price numeric(12,2) not null default 0 check (base_price >= 0),
  free_over  numeric(12,2) check (free_over is null or free_over >= 0),
  per_kg_price numeric(12,2) not null default 0 check (per_kg_price >= 0),
  estimated_days_min int, estimated_days_max int,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  foreign key (zone_id, store_id) references public.shipping_zones (id, store_id) on delete cascade
);
create index if not exists shipping_methods_store_idx on public.shipping_methods (store_id) where is_active;

-- ----------------------------------------------------------------------------
-- 4. Orders (order status ≠ payment status ≠ fulfillment status)
-- ----------------------------------------------------------------------------
create table if not exists public.orders (
  id            uuid primary key default gen_random_uuid(),
  store_id      uuid not null references public.stores(id) on delete restrict,   -- financial record: close the store, never cascade-delete orders
  order_number  text not null,
  customer_id   uuid,
  customer_snapshot jsonb not null default '{}'::jsonb,
  currency      char(3) not null,
  subtotal      numeric(14,2) not null check (subtotal >= 0),
  discount_total numeric(14,2) not null default 0 check (discount_total >= 0),
  shipping_total numeric(14,2) not null default 0 check (shipping_total >= 0),
  tax_total     numeric(14,2) not null default 0 check (tax_total >= 0),
  total         numeric(14,2) not null check (total >= 0),
  -- lifecycle: pending (awaiting confirmation) → confirmed → processing → shipped → delivered → completed | cancelled
  status        text not null default 'pending'
                check (status in ('pending','confirmed','processing','shipped','delivered','completed','cancelled')),
  -- money: unpaid → paid | failed ; paid → partially_refunded | refunded. COD stays unpaid until the merchant confirms collection.
  payment_status text not null default 'unpaid'
                check (payment_status in ('unpaid','paid','failed','partially_refunded','refunded')),
  fulfillment_status text not null default 'unfulfilled'
                check (fulfillment_status in ('unfulfilled','partial','fulfilled','not_required')),
  payment_method text not null check (payment_method in ('cod','stripe')),
  coupon_id     uuid references public.coupons(id) on delete set null,
  coupon_code   text,
  shipping_method_name jsonb,
  shipping_address jsonb, billing_address jsonb,
  notes         text,
  utm           jsonb not null default '{}'::jsonb,
  idempotency_key text not null,
  cod_collected_at timestamptz, cod_collected_by uuid,
  paid_at timestamptz, confirmed_at timestamptz, shipped_at timestamptz,
  delivered_at timestamptz, completed_at timestamptz, cancelled_at timestamptz,
  cancel_reason text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  constraint orders_id_store_uk unique (id, store_id),
  constraint orders_number_uk unique (store_id, order_number),
  constraint orders_idem_uk unique (store_id, idempotency_key),           -- idempotency is per tenant (no cross-store leakage)
  constraint orders_total_ck check (total = greatest(0, subtotal - discount_total + shipping_total + tax_total)),
  foreign key (customer_id, store_id) references public.customers (id, store_id) on delete set null (customer_id)
);
create index if not exists orders_store_created_idx on public.orders (store_id, created_at desc);
create index if not exists orders_customer_idx on public.orders (customer_id);
create index if not exists orders_payment_status_idx on public.orders (store_id, payment_status);
create index if not exists orders_status_idx on public.orders (store_id, status);
drop trigger if exists orders_updated on public.orders;
create trigger orders_updated before update on public.orders for each row execute function public.set_updated_at();
drop trigger if exists audit_orders on public.orders;
create trigger audit_orders after insert or update or delete on public.orders
  for each row execute function public.audit_row();

create table if not exists public.order_items (
  id        uuid primary key default gen_random_uuid(),
  store_id  uuid not null references public.stores(id) on delete restrict,
  order_id  uuid not null,
  product_id uuid references public.products(id) on delete set null,
  variant_id uuid references public.product_variants(id) on delete set null,
  name      jsonb not null,
  sku       text,
  qty       int not null check (qty between 1 and 99),
  unit_price numeric(12,2) not null check (unit_price >= 0),
  total     numeric(14,2) not null check (total >= 0),
  is_digital boolean not null default false,
  requires_shipping boolean not null default true,
  delivered boolean not null default false,
  created_at timestamptz not null default now(),
  constraint order_items_id_store_uk unique (id, store_id),
  foreign key (order_id, store_id) references public.orders (id, store_id) on delete cascade
);
create index if not exists order_items_order_idx on public.order_items (order_id);

create table if not exists public.order_status_history (
  id        bigint generated always as identity primary key,
  store_id  uuid not null references public.stores(id) on delete restrict,
  order_id  uuid not null,
  from_status text, to_status text not null,
  actor     uuid,                                -- auth.uid() of staff; null = system/webhook
  note      text,
  created_at timestamptz not null default now(),
  foreign key (order_id, store_id) references public.orders (id, store_id) on delete cascade
);
create index if not exists order_status_history_order_idx on public.order_status_history (order_id, created_at);

-- ----------------------------------------------------------------------------
-- 5. Payments. Secrets are NEVER stored here: secret_ref points into Vault.
-- ----------------------------------------------------------------------------
create table if not exists public.payment_providers (
  id        uuid primary key default gen_random_uuid(),
  store_id  uuid not null references public.stores(id) on delete cascade,
  code      text not null check (code in ('cod','stripe')),
  display_name text not null,
  enabled   boolean not null default false,
  mode      text not null default 'test' check (mode in ('test','live')),
  status    text not null default 'disconnected' check (status in ('disconnected','pending','connected','restricted','error')),
  connected_account_id text,                      -- Stripe Connect (Express) account: destination-charge model
  charges_enabled boolean not null default false,
  payouts_enabled boolean not null default false,
  details_submitted boolean not null default false,
  secret_ref text,                                -- Vault id of a merchant-owned secret key (alternative to Connect)
  webhook_secret_ref text,                        -- Vault id of that merchant's webhook signing secret
  platform_fee_bps int not null default 200 check (platform_fee_bps between 0 and 3000),
  last_synced_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (store_id, code),
  constraint payment_providers_one_model_ck check (not (connected_account_id is not null and secret_ref is not null))
);
create unique index if not exists payment_providers_account_uidx on public.payment_providers (connected_account_id) where connected_account_id is not null;
drop trigger if exists payment_providers_updated on public.payment_providers;
create trigger payment_providers_updated before update on public.payment_providers for each row execute function public.set_updated_at();

create table if not exists public.payments (
  id        uuid primary key default gen_random_uuid(),
  store_id  uuid not null references public.stores(id) on delete restrict,
  order_id  uuid not null,
  provider  text not null check (provider in ('cod','stripe')),
  provider_payment_id text,                       -- Checkout Session id (stripe) → later the PaymentIntent id
  checkout_session_id text,
  payment_intent_id text,
  amount    numeric(14,2) not null check (amount >= 0),
  amount_refunded numeric(14,2) not null default 0 check (amount_refunded >= 0 and amount_refunded <= amount),
  currency  char(3) not null,
  status    text not null default 'pending'
            check (status in ('pending','succeeded','failed','cancelled','partially_refunded','refunded')),
  method_type text,
  failure_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint payments_one_per_order_uk unique (order_id),
  foreign key (order_id, store_id) references public.orders (id, store_id) on delete cascade
);
create index if not exists payments_intent_idx on public.payments (payment_intent_id) where payment_intent_id is not null;
create index if not exists payments_session_idx on public.payments (checkout_session_id) where checkout_session_id is not null;
drop trigger if exists payments_updated on public.payments;
create trigger payments_updated before update on public.payments for each row execute function public.set_updated_at();

-- Webhook inbox + processing state machine: received → processing → succeeded | failed | retryable | ignored
create table if not exists public.payment_events (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid references public.stores(id) on delete set null,
  order_id   uuid references public.orders(id) on delete set null,
  provider   text not null,
  event_id   text not null,
  type       text not null,
  account_id text,                                -- Stripe Connect account context (event.account), if any
  status     text not null default 'received'
             check (status in ('received','processing','succeeded','failed','retryable','ignored')),
  attempts   int not null default 0,
  last_error text,
  payload    jsonb not null,
  received_at timestamptz not null default now(),
  processing_started_at timestamptz,
  processed_at timestamptz,
  constraint payment_events_uk unique (provider, event_id)
);
create index if not exists payment_events_status_idx on public.payment_events (status, received_at) where status in ('received','retryable','failed','processing');
create index if not exists payment_events_order_idx on public.payment_events (order_id);

create table if not exists public.refunds (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete restrict,
  order_id   uuid not null,
  payment_id uuid references public.payments(id) on delete set null,
  provider_refund_id text,
  amount     numeric(14,2) not null check (amount > 0),
  currency   char(3) not null,
  reason     text,
  status     text not null default 'succeeded' check (status in ('pending','succeeded','failed')),
  created_by uuid,
  created_at timestamptz not null default now(),
  foreign key (order_id, store_id) references public.orders (id, store_id) on delete cascade
);
create unique index if not exists refunds_provider_uidx on public.refunds (provider_refund_id) where provider_refund_id is not null;
create index if not exists refunds_order_idx on public.refunds (order_id);

create table if not exists public.shipments (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete restrict,
  order_id   uuid not null,
  carrier    text, tracking_number text, tracking_url text,
  status     text not null default 'pending' check (status in ('pending','in_transit','delivered','returned')),
  shipped_at timestamptz, delivered_at timestamptz,
  created_at timestamptz not null default now(),
  foreign key (order_id, store_id) references public.orders (id, store_id) on delete cascade
);
create index if not exists shipments_order_idx on public.shipments (order_id);

-- ----------------------------------------------------------------------------
-- 6. Digital delivery
-- ----------------------------------------------------------------------------
create table if not exists public.digital_downloads (
  id          uuid primary key default gen_random_uuid(),
  store_id    uuid not null references public.stores(id) on delete restrict,
  order_id    uuid not null,
  order_item_id uuid not null,
  customer_id uuid,
  product_id  uuid not null references public.products(id) on delete restrict,
  product_file_id uuid not null references public.product_files(id) on delete restrict,
  token       text not null unique default encode(gen_random_bytes(24), 'hex'),
  download_limit int not null default 5 check (download_limit between 1 and 1000),
  download_count int not null default 0 check (download_count >= 0),
  expires_at  timestamptz,
  revoked     boolean not null default false,
  revoked_reason text,
  last_download_at timestamptz,
  created_at  timestamptz not null default now(),
  constraint digital_downloads_item_file_uk unique (order_item_id, product_file_id),   -- exactly one entitlement per paid file
  foreign key (order_id, store_id) references public.orders (id, store_id) on delete cascade,
  foreign key (order_item_id, store_id) references public.order_items (id, store_id) on delete cascade,
  foreign key (customer_id, store_id) references public.customers (id, store_id) on delete set null (customer_id)
);
create index if not exists digital_downloads_order_idx on public.digital_downloads (order_id);
create index if not exists digital_downloads_customer_idx on public.digital_downloads (customer_id);

create table if not exists public.license_keys (
  id          uuid primary key default gen_random_uuid(),
  store_id    uuid not null references public.stores(id) on delete cascade,
  product_id  uuid not null,
  license_key text not null,
  status      text not null default 'available' check (status in ('available','assigned','revoked')),
  order_item_id uuid references public.order_items(id) on delete set null,
  customer_id uuid,
  assigned_at timestamptz,
  created_at  timestamptz not null default now(),
  constraint license_keys_unique_per_product unique (product_id, license_key),
  foreign key (product_id, store_id) references public.products (id, store_id) on delete cascade,
  foreign key (customer_id, store_id) references public.customers (id, store_id) on delete set null (customer_id)
);
create index if not exists license_keys_available_idx on public.license_keys (product_id) where status = 'available';
create index if not exists license_keys_order_item_idx on public.license_keys (order_item_id);

create table if not exists public.download_logs (
  id          bigint generated always as identity primary key,
  store_id    uuid not null references public.stores(id) on delete cascade,
  download_id uuid not null references public.digital_downloads(id) on delete cascade,
  outcome     text not null default 'granted' check (outcome in ('granted','denied','expired','limit','revoked')),
  ip          text, user_agent text,
  created_at  timestamptz not null default now()
);
create index if not exists download_logs_download_idx on public.download_logs (download_id, created_at desc);

-- ----------------------------------------------------------------------------
-- 7. Forward foreign keys deferred from 0001 (tables did not exist yet there)
-- ----------------------------------------------------------------------------
do $$
declare r record;
begin
  for r in select * from (values
    ('reviews','customer_id','customers','on delete set null'),
    ('wishlists','customer_id','customers','on delete cascade'),
    ('coupon_usage','order_id','orders','on delete cascade'),
    ('coupon_usage','customer_id','customers','on delete set null'),
    ('campaign_events','order_id','orders','on delete set null'),
    ('abandoned_carts','cart_id','carts','on delete set null'),
    ('abandoned_carts','customer_id','customers','on delete set null'),
    ('email_jobs','to_customer_id','customers','on delete set null'),
    ('marketing_consents','customer_id','customers','on delete set null'),
    ('loyalty_accounts','customer_id','customers','on delete cascade'),
    ('loyalty_transactions','order_id','orders','on delete set null'),
    ('referrals','referrer_customer_id','customers','on delete cascade'),
    ('referrals','referred_customer_id','customers','on delete set null'),
    ('referrals','order_id','orders','on delete set null'),
    ('affiliate_commissions','order_id','orders','on delete cascade'),
    ('analytics_events','customer_id','customers','on delete set null'),
    ('analytics_events','order_id','orders','on delete set null'),
    ('conversion_events','order_id','orders','on delete set null'),
    ('conversion_events','customer_id','customers','on delete set null'),
    ('marketing_attribution','order_id','orders','on delete cascade'),
    ('marketing_attribution','customer_id','customers','on delete set null')
  ) as x(tbl, col, ref, act)
  loop
    if not exists (select 1 from pg_constraint where conname = r.tbl || '_' || r.col || '_fkey' and conrelid = ('public.' || r.tbl)::regclass) then
      execute format('alter table public.%I add constraint %I foreign key (%I) references public.%I (id) %s',
                     r.tbl, r.tbl || '_' || r.col || '_fkey', r.col, r.ref, r.act);
    end if;
  end loop;
end $$;

-- ----------------------------------------------------------------------------
-- 8. Authorization helper (REPLACES the 0001 version, which joined permissions
--    on a non-existent column p.id and was declared before its tables).
--    Fixed search_path, NULL-safe, optional permission.
-- ----------------------------------------------------------------------------
create or replace function public.has_store_access(p_store_id uuid, p_permission text default null)
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$
  select auth.uid() is not null and exists (
    select 1
    from public.store_users su
    where su.user_id = auth.uid()
      and su.store_id = p_store_id
      and su.status = 'active'
      and (p_permission is null or exists (
            select 1 from public.role_permissions rp
            where rp.role_id = su.role_id and rp.permission_id = p_permission))
  );
$$;
revoke all on function public.has_store_access(uuid, text) from public, anon;
grant execute on function public.has_store_access(uuid, text) to authenticated, service_role;

-- ----------------------------------------------------------------------------
-- 9. Row level security for the new tables
-- ----------------------------------------------------------------------------
alter table public.customers            enable row level security;
alter table public.customer_addresses   enable row level security;
alter table public.carts                enable row level security;
alter table public.cart_items           enable row level security;
alter table public.shipping_zones       enable row level security;
alter table public.shipping_methods     enable row level security;
alter table public.orders               enable row level security;
alter table public.order_items          enable row level security;
alter table public.order_status_history enable row level security;
alter table public.payment_providers    enable row level security;
alter table public.payments             enable row level security;
alter table public.payment_events       enable row level security;
alter table public.refunds              enable row level security;
alter table public.shipments            enable row level security;
alter table public.digital_downloads    enable row level security;
alter table public.license_keys         enable row level security;
alter table public.download_logs        enable row level security;
alter table public.coupon_usage         enable row level security;
alter table public.abandoned_carts      enable row level security;

do $$
declare r record;
begin
  -- Staff-managed tables (full access with the matching permission, scoped by store_id).
  for r in select * from (values
      ('customers','customers.manage'), ('customer_addresses','customers.manage'),
      ('shipping_zones','store.manage'), ('shipping_methods','store.manage'),
      ('shipments','orders.manage'), ('license_keys','products.manage'),
      ('coupon_usage','discounts.manage'), ('abandoned_carts','marketing.manage')
    ) as x(t, perm)
  loop
    execute format('drop policy if exists %I on public.%I', r.t || '_tenant', r.t);
    execute format('create policy %I on public.%I for all to authenticated using (public.has_store_access(store_id, %L)) with check (public.has_store_access(store_id, %L))',
                   r.t || '_tenant', r.t, r.perm, r.perm);
  end loop;
  -- Money / fulfilment tables: staff may READ. Writes happen only through audited SECURITY DEFINER RPCs
  -- (place_order, update_order_status, confirm_cod_order, mark_cod_collected, fulfill_paid_order …).
  for r in select * from (values
      ('carts','orders.manage'), ('cart_items','orders.manage'), ('orders','orders.manage'),
      ('order_items','orders.manage'), ('order_status_history','orders.manage'), ('payments','orders.manage'),
      ('refunds','orders.manage'), ('digital_downloads','orders.manage'), ('download_logs','orders.manage')
    ) as x(t, perm)
  loop
    execute format('drop policy if exists %I on public.%I', r.t || '_tenant', r.t);
    execute format('drop policy if exists %I on public.%I', r.t || '_staff_read', r.t);
    execute format('create policy %I on public.%I for select to authenticated using (public.has_store_access(store_id, %L))',
                   r.t || '_staff_read', r.t, r.perm);
  end loop;
end $$;

-- limited staff edits that do not touch money
drop policy if exists orders_staff_notes on public.orders;
create policy orders_staff_notes on public.orders for update to authenticated
  using (public.has_store_access(store_id, 'orders.manage')) with check (public.has_store_access(store_id, 'orders.manage'));
drop policy if exists digital_downloads_staff_update on public.digital_downloads;
create policy digital_downloads_staff_update on public.digital_downloads for update to authenticated
  using (public.has_store_access(store_id, 'orders.manage')) with check (public.has_store_access(store_id, 'orders.manage'));

-- Storefront reads: only ACTIVE shipping options of ACTIVE stores
drop policy if exists shipping_zones_public on public.shipping_zones;
create policy shipping_zones_public on public.shipping_zones for select to anon, authenticated
  using (is_active and exists (select 1 from public.stores s where s.id = store_id and s.status in ('active','trial')));
drop policy if exists shipping_methods_public on public.shipping_methods;
create policy shipping_methods_public on public.shipping_methods for select to anon, authenticated
  using (is_active and exists (select 1 from public.stores s where s.id = store_id and s.status in ('active','trial')));

-- Shoppers: only their own rows (relocated from 0001 and tightened)
drop policy if exists customers_own on public.customers;
create policy customers_own on public.customers for select to authenticated using (user_id = auth.uid());
drop policy if exists orders_own on public.orders;
create policy orders_own on public.orders for select to authenticated
  using (exists (select 1 from public.customers c where c.id = orders.customer_id and c.user_id = auth.uid()));
drop policy if exists order_items_own on public.order_items;
create policy order_items_own on public.order_items for select to authenticated
  using (exists (select 1 from public.orders o join public.customers c on c.id = o.customer_id
                 where o.id = order_items.order_id and c.user_id = auth.uid()));
drop policy if exists customer_addresses_own on public.customer_addresses;
create policy customer_addresses_own on public.customer_addresses for all to authenticated
  using (exists (select 1 from public.customers c where c.id = customer_id and c.user_id = auth.uid()))
  with check (exists (select 1 from public.customers c where c.id = customer_id and c.user_id = auth.uid() and c.store_id = customer_addresses.store_id));
drop policy if exists wishlists_own on public.wishlists;
create policy wishlists_own on public.wishlists for all to authenticated
  using (public.has_store_access(store_id) or exists (select 1 from public.customers c where c.id = wishlists.customer_id and c.user_id = auth.uid()))
  with check (public.has_store_access(store_id) or exists (select 1 from public.customers c where c.id = wishlists.customer_id and c.user_id = auth.uid() and c.store_id = wishlists.store_id));

-- ----------------------------------------------------------------------------
-- 10. Privileges (Supabase grants ALL on new public tables to anon/authenticated by default)
-- ----------------------------------------------------------------------------
revoke all on public.payment_providers, public.payment_events from anon, authenticated;   -- service role only
revoke all on public.carts, public.cart_items, public.order_items, public.order_status_history,
              public.payments, public.refunds, public.download_logs, public.orders, public.digital_downloads
  from anon;
revoke insert, delete, truncate on public.orders, public.order_items, public.order_status_history,
              public.payments, public.refunds, public.carts, public.cart_items, public.download_logs,
              public.digital_downloads from authenticated;
revoke update on public.orders from authenticated;
grant  update (notes) on public.orders to authenticated;                            -- merchants may annotate; never touch money/status
revoke update on public.order_items, public.order_status_history, public.payments, public.refunds,
              public.carts, public.cart_items, public.download_logs from authenticated;
revoke update on public.digital_downloads from authenticated;
grant  update (revoked, revoked_reason, download_limit, expires_at) on public.digital_downloads to authenticated;
revoke all on public.customers, public.customer_addresses, public.shipments, public.license_keys,
              public.coupon_usage, public.abandoned_carts from anon;
-- integrations: private token references must not be readable by browsers
revoke select on public.integrations from anon, authenticated;
grant  select (id, store_id, provider, enabled, config, status, last_sync_at, created_at, updated_at)
  on public.integrations to authenticated;

-- orders trigger from 0004 (referrals) is created there; audit trigger created above.
create index if not exists abandoned_carts_store_idx on public.abandoned_carts (store_id);
