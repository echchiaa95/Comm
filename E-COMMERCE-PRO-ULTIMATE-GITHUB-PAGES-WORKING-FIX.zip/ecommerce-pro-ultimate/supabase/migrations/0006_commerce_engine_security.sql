-- ============================================================================
-- 0006_commerce_engine_security — V1.1 forward migration
-- Replaces the commerce engine functions from 0001/0003 with corrected,
-- hardened versions (fixed search_path, schema-qualified, EXECUTE locked down):
--   decrement_inventory, place_order, fulfill_paid_order (+ _finalize_paid_order),
--   confirm_cod_order, mark_cod_collected, update_order_status, cancel/expiry,
--   Stripe event state machine, refunds, Connect sync, download claim, vault RPCs,
--   handle_new_store, sales_summary, recalc_loyalty, consent-safe newsletter.
-- Safe to re-apply (create or replace / drop if exists / guarded DDL).
-- ============================================================================
set check_function_bodies = off;

-- ----------------------------------------------------------------------------
-- A. Stock: single write path. Store-scoped, untracked products are skipped,
--    negative qty restocks (cancel). INTERNAL ONLY (execute revoked below).
-- ----------------------------------------------------------------------------
create or replace function public.decrement_inventory(
  p_store_id uuid, p_product_id uuid, p_variant_id uuid, p_qty int,
  p_reason text, p_order_id uuid default null, p_idem_key text default null)
returns void language plpgsql security definer
set search_path = public, extensions, pg_temp as $$
declare v_track boolean;
begin
  if p_qty is null or p_qty = 0 then return; end if;
  select track_inventory into v_track from public.products
   where id = p_product_id and store_id = p_store_id;                       -- tenant check: product must belong to the store
  if not found then raise exception 'PRODUCT_NOT_IN_STORE'; end if;

  if p_idem_key is not null and exists (
       select 1 from public.inventory_movements where idempotency_key = p_idem_key) then
    return;                                                                  -- already applied (retry-safe)
  end if;
  if not v_track then return; end if;                                        -- digital / untracked: nothing to move

  if p_variant_id is not null then
    update public.product_variants set inventory_qty = inventory_qty - p_qty
     where id = p_variant_id and product_id = p_product_id and store_id = p_store_id
       and (p_qty < 0 or inventory_qty >= p_qty);
    if not found then raise exception 'INSUFFICIENT_STOCK'; end if;
    update public.products set inventory_qty = greatest(0, inventory_qty - p_qty)
     where id = p_product_id and store_id = p_store_id;
  else
    update public.products set inventory_qty = inventory_qty - p_qty
     where id = p_product_id and store_id = p_store_id
       and (p_qty < 0 or inventory_qty >= p_qty);
    if not found then raise exception 'INSUFFICIENT_STOCK'; end if;
  end if;

  insert into public.inventory_movements (store_id, product_id, variant_id, delta, reason, order_id, idempotency_key)
  values (p_store_id, p_product_id, p_variant_id, -p_qty, p_reason, p_order_id, p_idem_key);
end $$;

-- ----------------------------------------------------------------------------
-- B. place_order — the ONLY checkout entry. Prices, discounts, shipping and tax
--    are recomputed from the database; client totals are ignored.
-- ----------------------------------------------------------------------------
create or replace function public.place_order(p_payload jsonb)
returns jsonb language plpgsql security definer
set search_path = public, extensions, pg_temp as $$
declare
  v_store_id   uuid;
  v_store      public.stores%rowtype;
  v_idem       text  := nullif(btrim(coalesce(p_payload->>'idempotency_key','')), '');
  v_pay        text  := coalesce(p_payload->>'payment_method', 'cod');
  v_items      jsonb := coalesce(p_payload->'items', '[]'::jsonb);
  v_cust       jsonb := coalesce(p_payload->'customer', '{}'::jsonb);
  v_addr       jsonb := p_payload->'shipping_address';
  v_email      text  := nullif(lower(btrim(coalesce(p_payload->'customer'->>'email',''))), '');
  v_phone      text  := nullif(btrim(coalesce(p_payload->'customer'->>'phone','')), '');
  v_uid        uuid  := auth.uid();
  v_customer_id uuid;
  v_order      public.orders%rowtype;
  v_existing   public.orders%rowtype;
  v_item       jsonb; v_line jsonb; v_lines jsonb := '[]'::jsonb;
  v_product    public.products%rowtype;
  v_variant    public.product_variants%rowtype;
  v_method     public.shipping_methods%rowtype;
  v_coupon     public.coupons%rowtype;
  v_qty int; v_unit numeric; v_n int := 0;
  v_subtotal numeric := 0; v_discount numeric := 0; v_shipping numeric := 0; v_tax numeric := 0;
  v_elig numeric := 0; v_weight numeric := 0; v_total numeric;
  v_has_ship boolean := false; v_has_digital boolean := false;
  v_country text; v_city text; v_cart_id uuid; v_tax_rate numeric := 0;
  v_ok boolean;
begin
  begin
    v_store_id := (p_payload->>'store_id')::uuid;
  exception when others then raise exception 'INVALID_STORE';
  end;
  select * into v_store from public.stores where id = v_store_id and status in ('active','trial');
  if not found then raise exception 'INVALID_STORE'; end if;
  if v_idem is null or char_length(v_idem) > 120 then raise exception 'IDEMPOTENCY_KEY_REQUIRED'; end if;
  if jsonb_typeof(v_items) <> 'array' or jsonb_array_length(v_items) = 0 then raise exception 'EMPTY_CART'; end if;
  if jsonb_array_length(v_items) > 50 then raise exception 'CART_TOO_LARGE'; end if;
  if v_pay not in ('cod','stripe') then raise exception 'INVALID_PAYMENT_METHOD'; end if;

  -- Idempotent retry (double click / network retry): same key in the SAME store returns the same order.
  select * into v_existing from public.orders where store_id = v_store_id and idempotency_key = v_idem;
  if found then
    return jsonb_build_object('order_id', v_existing.id, 'order_number', v_existing.order_number,
      'total', v_existing.total, 'currency', v_existing.currency, 'payment_method', v_existing.payment_method,
      'requires_online_payment', v_existing.payment_method = 'stripe' and v_existing.payment_status <> 'paid',
      'duplicate', true);
  end if;

  -- Payment method must be enabled AND usable for this store
  select exists (select 1 from public.payment_providers pp
                 where pp.store_id = v_store_id and pp.code = v_pay and pp.enabled and pp.status = 'connected')
    into v_ok;
  if not v_ok then raise exception 'PAYMENT_METHOD_UNAVAILABLE'; end if;

  -- ── Price every line from the database ─────────────────────────────────────
  for v_item in select * from jsonb_array_elements(v_items) loop
    v_n := v_n + 1;
    begin
      v_qty := (v_item->>'qty')::int;
      select * into v_product from public.products
       where id = (v_item->>'product_id')::uuid and store_id = v_store_id and status = 'active';
    exception when others then raise exception 'INVALID_ITEM';
    end;
    if not found then raise exception 'PRODUCT_UNAVAILABLE: %', v_item->>'product_id'; end if;
    if v_qty is null or v_qty < 1 or v_qty > 99 then raise exception 'INVALID_QUANTITY'; end if;
    if v_product.currency <> v_store.default_currency then raise exception 'CURRENCY_MISMATCH'; end if;
    v_unit := v_product.price; v_variant := null;
    if nullif(v_item->>'variant_id','') is not null then
      select * into v_variant from public.product_variants
       where id = (v_item->>'variant_id')::uuid and product_id = v_product.id and store_id = v_store_id;
      if not found then raise exception 'VARIANT_UNAVAILABLE'; end if;
      if v_variant.price is not null then v_unit := v_variant.price; end if;
      if v_product.track_inventory and v_variant.inventory_qty < v_qty then
        raise exception 'INSUFFICIENT_STOCK: %', v_product.id; end if;
    elsif v_product.track_inventory and v_product.inventory_qty < v_qty then
      raise exception 'INSUFFICIENT_STOCK: %', v_product.id;
    end if;
    v_subtotal := v_subtotal + v_unit * v_qty;
    if v_product.type in ('physical','hybrid') then
      v_has_ship := true; v_weight := v_weight + coalesce(v_product.weight_grams, 0) * v_qty;
    end if;
    if v_product.type in ('digital','hybrid') then v_has_digital := true; end if;
    v_lines := v_lines || jsonb_build_array(jsonb_build_object(
      'n', v_n, 'product_id', v_product.id, 'variant_id', v_variant.id, 'qty', v_qty, 'unit', v_unit,
      'name', v_product.name, 'sku', coalesce(v_variant.sku, v_product.sku),
      'is_digital', v_product.type in ('digital','hybrid'),
      'requires_shipping', v_product.type in ('physical','hybrid')));
  end loop;

  -- COD is for physical goods only: never for a digital-only basket (nothing to collect on delivery).
  if v_pay = 'cod' and not v_has_ship then raise exception 'COD_NOT_ALLOWED_FOR_DIGITAL'; end if;
  if v_pay = 'stripe' and v_email is null then raise exception 'EMAIL_REQUIRED'; end if;
  if v_email is null and v_phone is null then raise exception 'CONTACT_REQUIRED'; end if;
  if v_email is not null and v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'INVALID_EMAIL'; end if;

  -- ── Shipping (physical lines only; method must be valid for the destination) ──
  if v_has_ship then
    v_country := upper(coalesce(v_addr->>'country',''));
    v_city    := coalesce(v_addr->>'city','');
    if v_country = '' or v_city = '' or coalesce(v_addr->>'address1','') = '' then raise exception 'SHIPPING_ADDRESS_REQUIRED'; end if;
    if nullif(p_payload->>'shipping_method_id','') is null then raise exception 'SHIPPING_METHOD_REQUIRED'; end if;
    select m.* into v_method from public.shipping_methods m
      join public.shipping_zones z on z.id = m.zone_id and z.store_id = m.store_id
     where m.id = (p_payload->>'shipping_method_id')::uuid and m.store_id = v_store_id
       and m.is_active and z.is_active
       and (z.countries ? '*' or exists (select 1 from jsonb_array_elements_text(z.countries) c where upper(c) = v_country))
       and (z.cities is null or exists (select 1 from jsonb_array_elements_text(z.cities) c where lower(c) = lower(v_city)));
    if not found then raise exception 'SHIPPING_METHOD_UNAVAILABLE'; end if;
    v_shipping := v_method.base_price;
    if v_method.type = 'free_threshold' and v_method.free_over is not null and v_subtotal >= v_method.free_over then v_shipping := 0; end if;
    if v_method.per_kg_price > 0 then v_shipping := v_shipping + v_method.per_kg_price * ceil(v_weight / 1000.0); end if;
  end if;

  -- ── Customer (guest or signed-in). A signed-in shopper is linked to exactly one row per store. ──
  if v_uid is not null then
    select id into v_customer_id from public.customers where store_id = v_store_id and user_id = v_uid;
  end if;
  if v_customer_id is null and v_email is not null then
    insert into public.customers (store_id, user_id, first_name, last_name, email, phone, referral_code)
    values (v_store_id, v_uid, left(v_cust->>'first_name', 80), left(v_cust->>'last_name', 80), v_email, left(v_phone, 40),
            upper(substr(md5(gen_random_uuid()::text), 1, 8)))
    on conflict (store_id, email) where email is not null do update
      set phone = coalesce(excluded.phone, public.customers.phone),
          first_name = coalesce(public.customers.first_name, excluded.first_name),
          last_name  = coalesce(public.customers.last_name, excluded.last_name),
          user_id    = coalesce(public.customers.user_id, excluded.user_id)
    returning id into v_customer_id;
  elsif v_customer_id is null then
    insert into public.customers (store_id, user_id, first_name, last_name, phone, referral_code)
    values (v_store_id, v_uid, left(v_cust->>'first_name', 80), left(v_cust->>'last_name', 80), left(v_phone, 40),
            upper(substr(md5(gen_random_uuid()::text), 1, 8)))
    returning id into v_customer_id;
  end if;

  -- ── Coupon (server-validated, restricted to eligible lines) ──────────────────
  if nullif(btrim(coalesce(p_payload->>'coupon_code','')), '') is not null then
    v_coupon := public.validate_coupon(v_store_id, p_payload->>'coupon_code', v_customer_id, v_subtotal);
    if v_coupon.kind not in ('percent','fixed','free_shipping') then raise exception 'COUPON_KIND_UNSUPPORTED'; end if;
    select coalesce(sum((l->>'unit')::numeric * (l->>'qty')::int), 0) into v_elig
      from jsonb_array_elements(v_lines) l
     where case v_coupon.apply_to
             when 'order'    then true
             when 'product'  then coalesce(v_coupon.product_ids, '[]'::jsonb) ? (l->>'product_id')
             when 'category' then exists (select 1 from public.product_categories pc
                                          where pc.product_id = (l->>'product_id')::uuid
                                            and coalesce(v_coupon.category_ids, '[]'::jsonb) ? pc.category_id::text)
             else false end;
    if v_coupon.kind = 'free_shipping' then
      if not v_has_ship then raise exception 'COUPON_NOT_APPLICABLE'; end if;
      v_discount := v_shipping;
    else
      if v_elig <= 0 then raise exception 'COUPON_NOT_APPLICABLE'; end if;
      if v_coupon.kind = 'percent' then
        v_discount := round(v_elig * v_coupon.value / 100.0, 2);
        if v_coupon.max_discount is not null then v_discount := least(v_discount, v_coupon.max_discount); end if;
      else
        v_discount := least(v_coupon.value, v_elig);
      end if;
    end if;
  end if;

  -- ── Tax (optional, store setting {"rate_percent": n}; exclusive) ─────────────
  select coalesce((value->>'rate_percent')::numeric, 0) into v_tax_rate
    from public.store_settings where store_id = v_store_id and key = 'tax';
  if coalesce(v_tax_rate, 0) > 0 then
    v_tax := round(greatest(0, v_subtotal - case when v_coupon.kind = 'free_shipping' then 0 else v_discount end) * v_tax_rate / 100.0, 2);
  end if;
  v_total := greatest(0, v_subtotal - v_discount + v_shipping + v_tax);

  -- ── Order row (unique (store_id, idempotency_key) makes concurrent duplicates collapse) ──
  insert into public.orders (store_id, order_number, customer_id, customer_snapshot, currency,
      subtotal, discount_total, shipping_total, tax_total, total, status, payment_status, fulfillment_status,
      payment_method, coupon_id, coupon_code, shipping_method_name, shipping_address, billing_address,
      notes, utm, idempotency_key)
  values (v_store_id,
      'ORD-' || to_char(now(), 'YYYYMMDD') || '-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10)),
      v_customer_id,
      jsonb_build_object('first_name', left(v_cust->>'first_name', 80), 'last_name', left(v_cust->>'last_name', 80),
                         'email', v_email, 'phone', left(v_phone, 40)),
      v_store.default_currency, v_subtotal, v_discount, v_shipping, v_tax, v_total, 'pending', 'unpaid',
      case when v_has_ship then 'unfulfilled' else 'not_required' end,
      v_pay, v_coupon.id, v_coupon.code, v_method.name, v_addr,
      coalesce(p_payload->'billing_address', v_addr), left(p_payload->>'notes', 2000),
      coalesce(p_payload->'utm', '{}'::jsonb), v_idem)
  on conflict (store_id, idempotency_key) do nothing
  returning * into v_order;
  if not found then                                                           -- lost a race with an identical request
    select * into v_order from public.orders where store_id = v_store_id and idempotency_key = v_idem;
    return jsonb_build_object('order_id', v_order.id, 'order_number', v_order.order_number, 'total', v_order.total,
      'currency', v_order.currency, 'payment_method', v_order.payment_method,
      'requires_online_payment', v_order.payment_method = 'stripe' and v_order.payment_status <> 'paid', 'duplicate', true);
  end if;

  -- ── Cart snapshot, order lines, stock (deterministic lock order, idempotent per line) ──
  insert into public.carts (store_id, customer_id, status, currency, coupon_id)
  values (v_store_id, v_customer_id, 'converted', v_order.currency, v_coupon.id) returning id into v_cart_id;

  for v_line in select l from jsonb_array_elements(v_lines) l order by l->>'product_id', (l->>'n')::int loop
    insert into public.cart_items (cart_id, store_id, product_id, variant_id, qty, unit_price)
    values (v_cart_id, v_store_id, (v_line->>'product_id')::uuid, nullif(v_line->>'variant_id','')::uuid,
            (v_line->>'qty')::int, (v_line->>'unit')::numeric);
    insert into public.order_items (store_id, order_id, product_id, variant_id, name, sku, qty, unit_price, total,
                                    is_digital, requires_shipping)
    values (v_store_id, v_order.id, (v_line->>'product_id')::uuid, nullif(v_line->>'variant_id','')::uuid,
            v_line->'name', v_line->>'sku', (v_line->>'qty')::int, (v_line->>'unit')::numeric,
            (v_line->>'unit')::numeric * (v_line->>'qty')::int,
            (v_line->>'is_digital')::boolean, (v_line->>'requires_shipping')::boolean);
    perform public.decrement_inventory(v_store_id, (v_line->>'product_id')::uuid, nullif(v_line->>'variant_id','')::uuid,
            (v_line->>'qty')::int, 'sale', v_order.id, 'sale:' || v_order.id || ':' || (v_line->>'n'));
  end loop;

  if v_coupon.id is not null then
    update public.coupons set used_count = used_count + 1
     where id = v_coupon.id and (usage_limit is null or used_count < usage_limit);
    if not found then raise exception 'COUPON_EXHAUSTED'; end if;
    insert into public.coupon_usage (store_id, coupon_id, order_id, customer_id, discount_amount)
    values (v_store_id, v_coupon.id, v_order.id, v_customer_id, v_discount)
    on conflict (coupon_id, order_id) do nothing;
  end if;

  -- A completed purchase ends any abandoned-cart recovery for this email (no reminders after buying).
  if v_email is not null then
    update public.abandoned_carts set recovered = true, updated_at = now() where store_id = v_store_id and email = v_email;
  end if;

  -- Payment row starts pending. Only a verified backend path (or merchant COD collection) can mark it paid.
  insert into public.payments (store_id, order_id, provider, amount, currency, status, method_type)
  values (v_store_id, v_order.id, v_pay, v_order.total, v_order.currency, 'pending', case when v_pay = 'cod' then 'cod' end);
  insert into public.order_status_history (store_id, order_id, from_status, to_status, note)
  values (v_store_id, v_order.id, null, 'pending', 'order placed (' || v_pay || ')');

  -- Free order (100% coupon / zero price) paid online: nothing to charge → finalize immediately.
  if v_pay = 'stripe' and v_order.total = 0 then
    perform public._finalize_paid_order(v_order.id, 'free-order', null);
  end if;

  return jsonb_build_object('order_id', v_order.id, 'order_number', v_order.order_number, 'total', v_order.total,
    'currency', v_order.currency, 'payment_method', v_pay,
    'requires_online_payment', v_pay = 'stripe' and v_order.total > 0, 'duplicate', false);
end $$;

-- Minimal, non-sensitive order summary for the guest "thank you" page (unguessable uuid required).
create or replace function public.get_order_confirmation(p_order_id uuid)
returns jsonb language sql stable security definer
set search_path = public, pg_temp as $$
  select jsonb_build_object('order_number', o.order_number, 'total', o.total, 'currency', o.currency,
         'payment_method', o.payment_method, 'status', o.status, 'payment_status', o.payment_status,
         'has_digital', exists (select 1 from public.order_items i where i.order_id = o.id and i.is_digital))
    from public.orders o where o.id = p_order_id;
$$;

-- ----------------------------------------------------------------------------
-- C. Cancellation / restock (internal) and unpaid-order expiry
-- ----------------------------------------------------------------------------
create or replace function public._cancel_order_internal(p_order_id uuid, p_reason text, p_actor uuid)
returns void language plpgsql security definer
set search_path = public, extensions, pg_temp as $$
declare v_order public.orders%rowtype; v_oi public.order_items%rowtype;
begin
  select * into v_order from public.orders where id = p_order_id for update;
  if not found or v_order.status = 'cancelled' then return; end if;
  for v_oi in select * from public.order_items where order_id = p_order_id and product_id is not null order by product_id, id loop
    perform public.decrement_inventory(v_order.store_id, v_oi.product_id, v_oi.variant_id, -v_oi.qty,
            'cancel', p_order_id, 'cancel:' || p_order_id || ':' || v_oi.id);
  end loop;
  if v_order.coupon_id is not null and exists (select 1 from public.coupon_usage where order_id = p_order_id) then
    delete from public.coupon_usage where order_id = p_order_id;
    update public.coupons set used_count = greatest(0, used_count - 1) where id = v_order.coupon_id;
  end if;
  update public.payments set status = 'cancelled' where order_id = p_order_id and status = 'pending';
  update public.orders set status = 'cancelled', cancelled_at = now(), cancel_reason = left(p_reason, 500) where id = p_order_id;
  insert into public.order_status_history (store_id, order_id, from_status, to_status, actor, note)
  values (v_order.store_id, p_order_id, v_order.status, 'cancelled', p_actor, p_reason);
end $$;

create or replace function public.expire_unpaid_orders(p_older_than_minutes int default 60)
returns int language plpgsql security definer
set search_path = public, extensions, pg_temp as $$
declare r record; n int := 0;
begin
  for r in select id from public.orders
            where payment_method = 'stripe' and payment_status in ('unpaid','failed') and status = 'pending'
              and created_at < now() - make_interval(mins => greatest(p_older_than_minutes, 15))
            order by created_at limit 200 for update skip locked
  loop
    perform public._cancel_order_internal(r.id, 'payment_expired', null); n := n + 1;
  end loop;
  return n;
end $$;

-- ----------------------------------------------------------------------------
-- D. Paid-order finalization. _finalize_paid_order is INTERNAL; the only callers are
--    fulfill_paid_order (service role, after signature verification) and mark_cod_collected
--    (merchant staff, permission-checked). It is idempotent: a second call is a no-op.
-- ----------------------------------------------------------------------------
create or replace function public._finalize_paid_order(p_order_id uuid, p_ref text, p_actor uuid)
returns jsonb language plpgsql security definer
set search_path = public, extensions, pg_temp as $$
declare
  v_order public.orders%rowtype; v_oi public.order_items%rowtype; v_pf record;
  v_dl jsonb; v_limit int; v_days int; v_files int; v_keys int; v_shortage boolean := false;
  v_any_digital boolean := false; v_all_delivered boolean := true; v_loy jsonb; v_points int;
  v_acct uuid; v_ins int; v_is_license boolean; v_ref_code text; v_referrer uuid; v_ref_id uuid; v_ref_points int;
begin
  select * into v_order from public.orders where id = p_order_id for update;
  if not found then raise exception 'ORDER_NOT_FOUND'; end if;
  if v_order.payment_status in ('paid','partially_refunded','refunded') then
    return jsonb_build_object('order_id', p_order_id, 'already_paid', true);
  end if;

  update public.payments set status = 'succeeded', provider_payment_id = coalesce(provider_payment_id, p_ref)
   where order_id = p_order_id;
  update public.orders set payment_status = 'paid', paid_at = now(),
         status = case when status = 'pending' and payment_method = 'stripe' then 'confirmed' else status end,
         confirmed_at = case when status = 'pending' and payment_method = 'stripe' then coalesce(confirmed_at, now()) else confirmed_at end
   where id = p_order_id;
  insert into public.order_status_history (store_id, order_id, from_status, to_status, actor, note)
  values (v_order.store_id, p_order_id, v_order.status,
          case when v_order.status = 'pending' and v_order.payment_method = 'stripe' then 'confirmed' else v_order.status end,
          p_actor, 'payment confirmed (' || v_order.payment_method || ')');

  -- A payment that arrives for an already-cancelled order is recorded but never fulfilled → needs a refund.
  if v_order.status = 'cancelled' then
    return jsonb_build_object('order_id', p_order_id, 'needs_refund', true);
  end if;

  update public.customers set total_orders = total_orders + 1, total_spent = total_spent + v_order.total, last_order_at = now()
   where id = v_order.customer_id;
  update public.products p set sales_count = sales_count + oi.qty
    from public.order_items oi where oi.order_id = p_order_id and oi.product_id = p.id;

  -- Digital fulfillment — reachable ONLY after verified payment.
  select value into v_dl from public.store_settings where store_id = v_order.store_id and key = 'digital';
  v_limit := coalesce((v_dl->>'download_limit')::int, 5);
  v_days  := coalesce((v_dl->>'expiry_days')::int, 30);
  for v_oi in select * from public.order_items where order_id = p_order_id and is_digital order by id loop
    v_any_digital := true; v_files := 0; v_keys := 0;
    v_is_license := exists (select 1 from public.products where id = v_oi.product_id and license_key_product);
    for v_pf in select id from public.product_files where product_id = v_oi.product_id and store_id = v_order.store_id order by sort_order loop
      insert into public.digital_downloads (store_id, order_id, order_item_id, customer_id, product_id, product_file_id,
                                            download_limit, expires_at)
      values (v_order.store_id, p_order_id, v_oi.id, v_order.customer_id, v_oi.product_id, v_pf.id,
              greatest(1, v_limit), case when v_days > 0 then now() + make_interval(days => v_days) end)
      on conflict (order_item_id, product_file_id) do nothing;
      v_files := v_files + 1;
    end loop;
    if v_is_license then
      with picked as (
        select id from public.license_keys
         where product_id = v_oi.product_id and store_id = v_order.store_id and status = 'available'
         order by created_at limit v_oi.qty for update skip locked)
      update public.license_keys k set status = 'assigned', order_item_id = v_oi.id,
             customer_id = v_order.customer_id, assigned_at = now()
        from picked where k.id = picked.id;
      get diagnostics v_keys = row_count;
      if v_keys < v_oi.qty then v_shortage := true; end if;
    end if;
    if (v_is_license and v_keys >= v_oi.qty) or (not v_is_license and v_files > 0) then
      update public.order_items set delivered = true where id = v_oi.id;
    else
      v_all_delivered := false;
    end if;
  end loop;
  if v_shortage then v_all_delivered := false; end if;

  -- Digital-only order that is fully delivered is complete.
  if not exists (select 1 from public.order_items where order_id = p_order_id and requires_shipping)
     and v_any_digital and v_all_delivered then
    update public.orders set status = 'completed', completed_at = now() where id = p_order_id and status in ('pending','confirmed');
  end if;

  -- Loyalty accrual (config-driven; at most one 'purchase' transaction per order via unique index)
  select value into v_loy from public.store_settings where store_id = v_order.store_id and key = 'loyalty';
  if v_order.customer_id is not null and coalesce((v_loy->>'enabled')::boolean, false) then
    v_points := floor(v_order.total * coalesce((v_loy->>'points_per_currency')::numeric, 1))::int;
    insert into public.loyalty_accounts (store_id, customer_id) values (v_order.store_id, v_order.customer_id)
      on conflict (store_id, customer_id) do nothing;
    select id into v_acct from public.loyalty_accounts where store_id = v_order.store_id and customer_id = v_order.customer_id;
    if v_points > 0 then
      insert into public.loyalty_transactions (store_id, account_id, delta, reason, order_id)
      values (v_order.store_id, v_acct, v_points, 'purchase', p_order_id)
      on conflict (order_id) where reason = 'purchase' do nothing;
      get diagnostics v_ins = row_count;
      if v_ins > 0 then perform public.recalc_loyalty(v_acct); end if;
    end if;
  end if;

  -- Referral reward: granted ONCE, only after real payment (never at order placement).
  v_ref_code := upper(coalesce(v_order.utm->>'referral_code', ''));
  if v_ref_code <> '' and v_order.customer_id is not null then
    select id into v_referrer from public.customers
     where store_id = v_order.store_id and referral_code = v_ref_code and id <> v_order.customer_id;
    if v_referrer is not null then
      insert into public.referrals (store_id, referrer_customer_id, referred_customer_id, code, status, order_id, reward_granted)
      values (v_order.store_id, v_referrer, v_order.customer_id, v_ref_code, 'rewarded', p_order_id, true)
      on conflict (store_id, code, referred_customer_id) do nothing
      returning id into v_ref_id;
      if v_ref_id is not null then
        v_ref_points := coalesce((v_loy->>'referral_points')::int, 50);
        insert into public.loyalty_accounts (store_id, customer_id) values (v_order.store_id, v_referrer)
          on conflict (store_id, customer_id) do nothing;
        select id into v_acct from public.loyalty_accounts where store_id = v_order.store_id and customer_id = v_referrer;
        insert into public.loyalty_transactions (store_id, account_id, delta, reason, order_id, referral_id)
        values (v_order.store_id, v_acct, v_ref_points, 'referral', p_order_id, v_ref_id)
        on conflict (referral_id) where reason = 'referral' do nothing;
        perform public.recalc_loyalty(v_acct);
      end if;
    end if;
  end if;

  -- Transactional outbox (consent-free by design; marketing mail is a separate flow)
  if v_order.customer_snapshot->>'email' is not null then
    insert into public.email_jobs (store_id, to_email, to_customer_id, payload, idempotency_key, scheduled_at)
    values (v_order.store_id, v_order.customer_snapshot->>'email', v_order.customer_id,
            jsonb_build_object('type','order_confirmation','order_id', p_order_id, 'order_number', v_order.order_number,
              'total', v_order.total, 'locale', (select default_locale from public.stores where id = v_order.store_id)),
            'confirm:' || p_order_id, now())
    on conflict (idempotency_key) do nothing;
    if v_any_digital and v_all_delivered then
      insert into public.email_jobs (store_id, to_email, to_customer_id, payload, idempotency_key, scheduled_at)
      values (v_order.store_id, v_order.customer_snapshot->>'email', v_order.customer_id,
              jsonb_build_object('type','digital_delivery','order_id', p_order_id, 'order_number', v_order.order_number,
                'locale', (select default_locale from public.stores where id = v_order.store_id)),
              'delivery:' || p_order_id, now())
      on conflict (idempotency_key) do nothing;
    end if;
  end if;

  return jsonb_build_object('order_id', p_order_id, 'fulfilled', true, 'digital', v_any_digital,
                            'license_shortage', v_shortage);
end $$;

-- fulfill_paid_order: webhook-only. Service role only (EXECUTE revoked from everyone else below) and
-- additionally refuses any call that carries an end-user JWT (auth.uid() not null).
drop function if exists public.fulfill_paid_order(uuid, text, text);
create or replace function public.fulfill_paid_order(
  p_order_id uuid, p_payment_ref text, p_idem_key text default null,
  p_amount numeric default null, p_currency text default null, p_payment_intent text default null)
returns jsonb language plpgsql security definer
set search_path = public, extensions, pg_temp as $$
declare v_order public.orders%rowtype;
begin
  if auth.uid() is not null then raise exception 'FORBIDDEN'; end if;
  select * into v_order from public.orders where id = p_order_id for update;
  if not found then raise exception 'ORDER_NOT_FOUND'; end if;
  if v_order.payment_method <> 'stripe' then raise exception 'NOT_ONLINE_ORDER'; end if;
  if p_amount is not null and abs(p_amount - v_order.total) > 0.005 then raise exception 'AMOUNT_MISMATCH'; end if;
  if p_currency is not null and lower(p_currency) <> lower(v_order.currency) then raise exception 'CURRENCY_MISMATCH'; end if;
  update public.payments set payment_intent_id = coalesce(p_payment_intent, payment_intent_id)
   where order_id = p_order_id;
  return public._finalize_paid_order(p_order_id, p_payment_ref, null);
end $$;

-- ----------------------------------------------------------------------------
-- E. Order lifecycle (staff). Status ≠ payment status. COD is NOT paid until collection is confirmed.
-- ----------------------------------------------------------------------------
create or replace function public.update_order_status(p_order_id uuid, p_status text, p_note text default null)
returns void language plpgsql security definer
set search_path = public, extensions, pg_temp as $$
declare v_order public.orders%rowtype; v_ok boolean; v_final text := p_status;
begin
  select * into v_order from public.orders where id = p_order_id for update;
  if not found then raise exception 'ORDER_NOT_FOUND'; end if;
  if not public.has_store_access(v_order.store_id, 'orders.manage') then raise exception 'forbidden'; end if;
  if p_status not in ('confirmed','processing','shipped','delivered','completed','cancelled') then raise exception 'INVALID_STATUS'; end if;
  if v_order.status = p_status then return; end if;

  v_ok := case v_order.status
    when 'pending'    then p_status in ('confirmed','cancelled')
    when 'confirmed'  then p_status in ('processing','shipped','cancelled')
    when 'processing' then p_status in ('shipped','cancelled')
    when 'shipped'    then p_status in ('delivered','cancelled')
    when 'delivered'  then p_status in ('completed')
    else false end;
  if not v_ok then raise exception 'ILLEGAL_TRANSITION: % -> %', v_order.status, p_status; end if;

  -- Online orders cannot progress before the money is confirmed by the payment provider.
  if v_order.payment_method = 'stripe' and v_order.payment_status <> 'paid' and p_status <> 'cancelled' then
    raise exception 'PAYMENT_REQUIRED'; end if;
  -- Paid orders are never cancelled silently: refund first (keeps books and downloads consistent).
  if p_status = 'cancelled' and v_order.payment_status in ('paid','partially_refunded') then raise exception 'REFUND_REQUIRED'; end if;
  if p_status = 'completed' and v_order.payment_status not in ('paid','partially_refunded') then raise exception 'PAYMENT_NOT_COLLECTED'; end if;

  if p_status = 'cancelled' then
    perform public._cancel_order_internal(p_order_id, coalesce(p_note, 'cancelled by staff'), auth.uid());
    return;
  end if;

  update public.orders set status = p_status,
    confirmed_at = case when p_status = 'confirmed' then coalesce(confirmed_at, now()) else confirmed_at end,
    shipped_at   = case when p_status = 'shipped'   then now() else shipped_at end,
    delivered_at = case when p_status = 'delivered' then now() else delivered_at end,
    completed_at = case when p_status = 'completed' then now() else completed_at end,
    fulfillment_status = case when p_status in ('shipped','delivered','completed') and fulfillment_status <> 'not_required'
                              then 'fulfilled' else fulfillment_status end
  where id = p_order_id;
  insert into public.order_status_history (store_id, order_id, from_status, to_status, actor, note)
  values (v_order.store_id, p_order_id, v_order.status, p_status, auth.uid(), p_note);

  -- Delivered + already paid (online, or COD collected earlier) → auto-complete.
  if p_status = 'delivered' and v_order.payment_status in ('paid','partially_refunded') then
    update public.orders set status = 'completed', completed_at = now() where id = p_order_id;
    insert into public.order_status_history (store_id, order_id, from_status, to_status, actor, note)
    values (v_order.store_id, p_order_id, 'delivered', 'completed', auth.uid(), 'delivered and paid');
  end if;
end $$;

-- COD step 1: merchant CONFIRMS the order (pending → confirmed). Money is NOT marked paid here.
create or replace function public.confirm_cod_order(p_order_id uuid)
returns jsonb language plpgsql security definer
set search_path = public, extensions, pg_temp as $$
declare v_order public.orders%rowtype;
begin
  select * into v_order from public.orders where id = p_order_id;
  if not found then raise exception 'ORDER_NOT_FOUND'; end if;
  if not public.has_store_access(v_order.store_id, 'orders.manage') then raise exception 'forbidden'; end if;
  if v_order.payment_method <> 'cod' then raise exception 'NOT_COD'; end if;
  perform public.update_order_status(p_order_id, 'confirmed', 'COD order confirmed by staff');
  if v_order.customer_snapshot->>'email' is not null then
    insert into public.email_jobs (store_id, to_email, to_customer_id, payload, idempotency_key, scheduled_at)
    values (v_order.store_id, v_order.customer_snapshot->>'email', v_order.customer_id,
            jsonb_build_object('type','order_confirmation','order_id', p_order_id, 'order_number', v_order.order_number,
              'total', v_order.total, 'locale', (select default_locale from public.stores where id = v_order.store_id)),
            'confirm:' || p_order_id, now())
    on conflict (idempotency_key) do nothing;
  end if;
  return jsonb_build_object('order_id', p_order_id, 'status', 'confirmed', 'payment_status', 'unpaid');
end $$;

-- COD step 2: merchant confirms the cash was COLLECTED (after dispatch). Only now is the order paid.
create or replace function public.mark_cod_collected(p_order_id uuid, p_note text default null)
returns jsonb language plpgsql security definer
set search_path = public, extensions, pg_temp as $$
declare v_order public.orders%rowtype; v_res jsonb;
begin
  select * into v_order from public.orders where id = p_order_id for update;
  if not found then raise exception 'ORDER_NOT_FOUND'; end if;
  if not public.has_store_access(v_order.store_id, 'orders.manage') then raise exception 'forbidden'; end if;
  if v_order.payment_method <> 'cod' then raise exception 'NOT_COD'; end if;
  if v_order.status not in ('shipped','delivered') then raise exception 'COD_NOT_DISPATCHED'; end if;
  if v_order.payment_status <> 'unpaid' then raise exception 'ALREADY_SETTLED'; end if;
  update public.orders set cod_collected_at = now(), cod_collected_by = auth.uid() where id = p_order_id;
  v_res := public._finalize_paid_order(p_order_id, 'cod-collected:' || p_order_id, auth.uid());
  if v_order.status = 'delivered' then
    update public.orders set status = 'completed', completed_at = now() where id = p_order_id;
    insert into public.order_status_history (store_id, order_id, from_status, to_status, actor, note)
    values (v_order.store_id, p_order_id, 'delivered', 'completed', auth.uid(), coalesce(p_note, 'COD collected'));
  end if;
  return v_res;
end $$;

-- ----------------------------------------------------------------------------
-- F. Stripe event state machine, failures, refunds, Connect sync (service role only)
-- ----------------------------------------------------------------------------
create or replace function public.claim_payment_event(
  p_provider text, p_event_id text, p_type text, p_store_id uuid, p_order_id uuid, p_account_id text, p_payload jsonb)
returns text language plpgsql security definer
set search_path = public, pg_temp as $$
declare v public.payment_events%rowtype; v_new uuid;
begin
  insert into public.payment_events (store_id, order_id, provider, event_id, type, account_id, payload, status, attempts, processing_started_at)
  values (p_store_id, p_order_id, p_provider, p_event_id, p_type, p_account_id, p_payload, 'processing', 1, now())
  on conflict (provider, event_id) do nothing returning id into v_new;
  if v_new is not null then return 'process'; end if;
  select * into v from public.payment_events where provider = p_provider and event_id = p_event_id for update;
  if v.status in ('succeeded','ignored') then return 'duplicate'; end if;
  if v.status = 'processing' and v.processing_started_at > now() - interval '2 minutes' then return 'in_progress'; end if;
  update public.payment_events set status = 'processing', attempts = attempts + 1, processing_started_at = now(),
         store_id = coalesce(store_id, p_store_id), order_id = coalesce(order_id, p_order_id)
   where id = v.id;
  return 'process';                                                    -- failed / retryable / stale: safe to retry
end $$;

create or replace function public.finish_payment_event(p_provider text, p_event_id text, p_status text, p_error text default null)
returns void language plpgsql security definer
set search_path = public, pg_temp as $$
begin
  if p_status not in ('succeeded','failed','retryable','ignored') then raise exception 'INVALID_STATUS'; end if;
  update public.payment_events set status = p_status, last_error = left(p_error, 1000),
         processed_at = case when p_status in ('succeeded','ignored') then now() else processed_at end
   where provider = p_provider and event_id = p_event_id;
end $$;

create or replace function public.mark_payment_failed(p_order_id uuid, p_reason text default null)
returns void language plpgsql security definer
set search_path = public, pg_temp as $$
begin
  update public.payments set status = 'failed', failure_reason = left(p_reason, 500)
   where order_id = p_order_id and status = 'pending';
  update public.orders set payment_status = 'failed' where id = p_order_id and payment_status = 'unpaid';
end $$;

create or replace function public.attach_checkout_session(p_order_id uuid, p_session_id text)
returns void language sql security definer
set search_path = public, pg_temp as $$
  update public.payments set checkout_session_id = p_session_id, provider_payment_id = coalesce(provider_payment_id, p_session_id)
   where order_id = p_order_id and provider = 'stripe';
$$;

create or replace function public.apply_stripe_refund(
  p_payment_intent text, p_amount_refunded numeric, p_currency text, p_refund_id text default null, p_reason text default null)
returns jsonb language plpgsql security definer
set search_path = public, pg_temp as $$
declare v_pay public.payments%rowtype; v_new numeric; v_delta numeric; v_full boolean;
begin
  select * into v_pay from public.payments where payment_intent_id = p_payment_intent for update;
  if not found then return jsonb_build_object('ignored', 'unknown_payment_intent'); end if;
  if lower(p_currency) <> lower(v_pay.currency) then raise exception 'CURRENCY_MISMATCH'; end if;
  v_new := least(p_amount_refunded, v_pay.amount);
  v_delta := v_new - v_pay.amount_refunded;
  if v_delta <= 0 then return jsonb_build_object('duplicate', true); end if;
  v_full := v_new >= v_pay.amount;
  insert into public.refunds (store_id, order_id, payment_id, provider_refund_id, amount, currency, reason)
  values (v_pay.store_id, v_pay.order_id, v_pay.id, p_refund_id, v_delta, v_pay.currency, p_reason)
  on conflict (provider_refund_id) where provider_refund_id is not null do nothing;
  update public.payments set amount_refunded = v_new,
         status = case when v_full then 'refunded' else 'partially_refunded' end where id = v_pay.id;
  update public.orders set payment_status = case when v_full then 'refunded' else 'partially_refunded' end where id = v_pay.order_id;
  if v_full then                                                       -- entitlement ends with a full refund
    update public.digital_downloads set revoked = true, revoked_reason = 'refunded' where order_id = v_pay.order_id and not revoked;
    update public.license_keys set status = 'revoked'
     where order_item_id in (select id from public.order_items where order_id = v_pay.order_id);
  end if;
  insert into public.order_status_history (store_id, order_id, from_status, to_status, note)
  select v_pay.store_id, v_pay.order_id, o.status, o.status, 'refund recorded: ' || v_delta from public.orders o where o.id = v_pay.order_id;
  return jsonb_build_object('refunded', v_new, 'full', v_full);
end $$;

create or replace function public.sync_connect_account(
  p_account_id text, p_charges_enabled boolean, p_payouts_enabled boolean, p_details_submitted boolean)
returns void language sql security definer
set search_path = public, pg_temp as $$
  update public.payment_providers set charges_enabled = p_charges_enabled, payouts_enabled = p_payouts_enabled,
         details_submitted = p_details_submitted, last_synced_at = now(),
         status = case when p_charges_enabled then 'connected' when p_details_submitted then 'restricted' else 'pending' end
   where connected_account_id = p_account_id and code = 'stripe';
$$;

-- Vault wrappers: PostgREST does not expose the vault schema; secrets never leave the server.
create or replace function public.store_secret_save(p_name text, p_secret text)
returns uuid language plpgsql security definer set search_path = public, vault, pg_temp as $$
declare v uuid;
begin select vault.create_secret(p_secret, p_name, 'managed by ecommerce-pro') into v; return v; end $$;
create or replace function public.store_secret_get(p_id uuid)
returns text language sql security definer set search_path = public, vault, pg_temp as $$
  select decrypted_secret from vault.decrypted_secrets where id = p_id;
$$;
create or replace function public.store_secret_delete(p_id uuid)
returns void language sql security definer set search_path = public, vault, pg_temp as $$
  delete from vault.secrets where id = p_id;
$$;

-- ----------------------------------------------------------------------------
-- G. Digital delivery: one atomic RPC validates token, payment, expiry, limit, rate; counts; logs.
-- ----------------------------------------------------------------------------
drop function if exists public.record_download(uuid, text);
create or replace function public.claim_download(p_token text, p_ip text default null, p_user_agent text default null)
returns jsonb language plpgsql security definer
set search_path = public, extensions, pg_temp as $$
declare d public.digital_downloads%rowtype; f public.product_files%rowtype; o public.orders%rowtype; v_recent int;
begin
  if p_token is null or char_length(p_token) < 20 then return jsonb_build_object('ok', false, 'reason', 'invalid'); end if;
  select * into d from public.digital_downloads where token = p_token for update;
  if not found then return jsonb_build_object('ok', false, 'reason', 'invalid'); end if;
  select * into o from public.orders where id = d.order_id;
  if d.revoked then
    insert into public.download_logs (store_id, download_id, outcome, ip, user_agent) values (d.store_id, d.id, 'revoked', p_ip, p_user_agent);
    return jsonb_build_object('ok', false, 'reason', 'revoked'); end if;
  if o.payment_status not in ('paid','partially_refunded') or o.status = 'cancelled' then
    insert into public.download_logs (store_id, download_id, outcome, ip, user_agent) values (d.store_id, d.id, 'denied', p_ip, p_user_agent);
    return jsonb_build_object('ok', false, 'reason', 'not_paid'); end if;
  if d.expires_at is not null and d.expires_at < now() then
    insert into public.download_logs (store_id, download_id, outcome, ip, user_agent) values (d.store_id, d.id, 'expired', p_ip, p_user_agent);
    return jsonb_build_object('ok', false, 'reason', 'expired'); end if;
  if d.download_count >= d.download_limit then
    insert into public.download_logs (store_id, download_id, outcome, ip, user_agent) values (d.store_id, d.id, 'limit', p_ip, p_user_agent);
    return jsonb_build_object('ok', false, 'reason', 'limit_reached'); end if;
  select count(*) into v_recent from public.download_logs where download_id = d.id and created_at > now() - interval '1 minute';
  if v_recent >= 10 then return jsonb_build_object('ok', false, 'reason', 'rate_limited'); end if;
  select * into f from public.product_files where id = d.product_file_id and store_id = d.store_id;
  if not found then return jsonb_build_object('ok', false, 'reason', 'file_missing'); end if;
  update public.digital_downloads set download_count = download_count + 1, last_download_at = now() where id = d.id;
  insert into public.download_logs (store_id, download_id, outcome, ip, user_agent) values (d.store_id, d.id, 'granted', p_ip, p_user_agent);
  return jsonb_build_object('ok', true, 'download_id', d.id, 'storage_path', f.storage_path,
                            'file_name', f.file_name, 'mime_type', f.mime_type);
end $$;

create or replace function public.release_download(p_download_id uuid)       -- called if signing the URL failed after claiming
returns void language sql security definer set search_path = public, pg_temp as $$
  update public.digital_downloads set download_count = greatest(0, download_count - 1) where id = p_download_id;
$$;

create or replace function public.customer_downloads_by_order(p_order_id uuid)
returns jsonb language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce(jsonb_agg(jsonb_build_object('token', dd.token, 'file_name', pf.file_name, 'mime_type', pf.mime_type)
         order by pf.sort_order), '[]'::jsonb)
    from public.digital_downloads dd
    join public.product_files pf on pf.id = dd.product_file_id
    join public.orders o on o.id = dd.order_id
   where dd.order_id = p_order_id and not dd.revoked and o.payment_status in ('paid','partially_refunded');
$$;

create or replace function public.customer_downloads(p_store_id uuid)
returns jsonb language plpgsql stable security definer set search_path = public, pg_temp as $$
declare v_customer_id uuid;
begin
  if auth.uid() is null then return '[]'::jsonb; end if;
  select id into v_customer_id from public.customers where store_id = p_store_id and user_id = auth.uid();
  if v_customer_id is null then return '[]'::jsonb; end if;
  return coalesce((
    select jsonb_agg(jsonb_build_object('download_id', dd.id, 'token', dd.token, 'file_name', pf.file_name,
        'mime_type', pf.mime_type, 'size_bytes', pf.size_bytes, 'order_number', o.order_number,
        'download_count', dd.download_count, 'download_limit', dd.download_limit, 'expires_at', dd.expires_at,
        'revoked', dd.revoked, 'created_at', dd.created_at) order by dd.created_at desc)
      from public.digital_downloads dd
      join public.product_files pf on pf.id = dd.product_file_id
      join public.orders o on o.id = dd.order_id
     where dd.store_id = p_store_id and dd.customer_id = v_customer_id
       and o.payment_status in ('paid','partially_refunded')), '[]'::jsonb);
end $$;

-- ----------------------------------------------------------------------------
-- H. Corrected helpers from 0001 / 0003
-- ----------------------------------------------------------------------------
create or replace function public.handle_new_store() returns trigger
language plpgsql security definer set search_path = public, extensions, pg_temp as $$
declare v_role uuid; v_zone uuid;
begin
  select id into v_role from public.roles where code = 'owner';
  if new.created_by is not null then
    insert into public.store_users (store_id, user_id, role_id) values (new.id, new.created_by, v_role) on conflict do nothing;
  end if;
  insert into public.store_settings (store_id, key, value) values
    (new.id, 'checkout', '{"guest_checkout":true,"one_page":true,"whatsapp_button":true,"sticky_add_to_cart":true}'::jsonb),
    (new.id, 'loyalty', '{"enabled":true,"points_per_currency":1,"tiers":[{"code":"bronze","min":0},{"code":"silver","min":500},{"code":"gold","min":1500},{"code":"platinum","min":5000}]}'::jsonb),
    (new.id, 'abandoned_cart', '{"steps":[{"delay_minutes":30,"channel":"email"},{"delay_minutes":720,"channel":"email"},{"delay_minutes":1440,"channel":"email","with_coupon":true},{"delay_minutes":2880,"channel":"email","final":true}]}'::jsonb),
    (new.id, 'digital', '{"download_limit":5,"expiry_days":30}'::jsonb),
    (new.id, 'seo', '{"generate_sitemap":true,"default_robots":"index,follow"}'::jsonb),
    (new.id, 'notifications', '{"order_email_admin":true}'::jsonb)
  on conflict do nothing;

  if new.business_model in ('physical','hybrid') then
    insert into public.payment_providers (store_id, code, display_name, enabled, status)
    values (new.id, 'cod', 'Cash on Delivery', true, 'connected') on conflict do nothing;
    insert into public.shipping_zones (store_id, name, countries, cities)
    values (new.id, 'Default zone', '["*"]'::jsonb, case when new.city is not null then jsonb_build_array(new.city) else null end)
    returning id into v_zone;
    insert into public.shipping_methods (store_id, zone_id, name, type, base_price, free_over)
    values (new.id, v_zone, '{"en":"Standard delivery","fr":"Livraison standard","ar":"التوصيل العادي"}'::jsonb, 'flat', 5.00, null);
  else
    insert into public.payment_providers (store_id, code, display_name, enabled, status)
    values (new.id, 'cod', 'Cash on Delivery', false, 'disconnected') on conflict do nothing;
  end if;
  insert into public.payment_providers (store_id, code, display_name, enabled, status)   -- every store can connect Stripe later
  values (new.id, 'stripe', 'Stripe', false, 'disconnected') on conflict do nothing;

  insert into public.store_navigation (store_id, menu_key, items) values
    (new.id, 'header', '[{"label":{"en":"Home","fr":"Accueil","ar":"الرئيسية"},"path":"/"}]'::jsonb),
    (new.id, 'footer', '[{"label":{"en":"Contact","fr":"Contact","ar":"اتصل بنا"},"path":"/page/contact"}]'::jsonb),
    (new.id, 'mobile', '[]'::jsonb)
  on conflict do nothing;

  insert into public.email_templates (store_id, key, name, subject, body) values
    (new.id, 'order_confirmation', 'Order confirmation',
      '{"en":"Your order {{order_number}} is confirmed","fr":"Votre commande {{order_number}} est confirmée","ar":"تم تأكيد طلبك {{order_number}}"}'::jsonb,
      '{"en":[{"type":"heading","text":"Thank you for your order"},{"type":"order_summary"},{"type":"button","text":"View order","url":"{{order_url}}"}]}'::jsonb),
    (new.id, 'digital_delivery', 'Your download is ready',
      '{"en":"Your files are ready to download","fr":"Vos fichiers sont prêts","ar":"ملفاتك جاهزة للتحميل"}'::jsonb,
      '{"en":[{"type":"heading","text":"Your download is ready"},{"type":"download_links"},{"type":"button","text":"Download","url":"{{download_url}}"}]}'::jsonb),
    (new.id, 'abandoned_cart', 'You left something behind',
      '{"en":"Complete your purchase","fr":"Finalisez votre achat","ar":"أكمل عملية الشراء"}'::jsonb,
      '{"en":[{"type":"heading","text":"Your cart is waiting"},{"type":"cart_items"},{"type":"button","text":"Return to cart","url":"{{cart_url}}"}]}'::jsonb)
  on conflict do nothing;
  return new;
end $$;

create or replace function public.sales_summary(p_store_id uuid, p_from date default null, p_to date default null)
returns jsonb language plpgsql stable security definer set search_path = public, pg_temp as $$
declare v_from date := coalesce(p_from, current_date - 29); v_to date := coalesce(p_to, current_date);
begin
  if not public.has_store_access(p_store_id, 'analytics.view') then raise exception 'forbidden'; end if;
  return (
    with o as (
      select * from public.orders
       where store_id = p_store_id and created_at::date between v_from and v_to and status <> 'cancelled'),
    paid as (select * from o where payment_status in ('paid','partially_refunded'))
    select jsonb_build_object(
      'gross_revenue', coalesce((select sum(total) from paid), 0),
      'discounts',     coalesce((select sum(discount_total) from paid), 0),
      'shipping',      coalesce((select sum(shipping_total) from paid), 0),
      'net_revenue',   coalesce((select sum(total - discount_total) from paid), 0),
      'pending_cod',   coalesce((select sum(total) from o where payment_method = 'cod' and payment_status = 'unpaid'), 0),
      'orders',        (select count(*) from o),
      'aov',           coalesce((select avg(total) from paid), 0),
      'by_day', coalesce((select jsonb_agg(jsonb_build_object('day', d, 'revenue', r, 'orders', c) order by d)
                           from (select created_at::date as d, sum(total) filter (where payment_status in ('paid','partially_refunded')) as r,
                                        count(*) as c from o group by 1) x), '[]'::jsonb));
  );
end $$;

create or replace function public.recalc_loyalty(p_account_id uuid)
returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare v public.loyalty_accounts%rowtype; v_settings jsonb; v_life int;
begin
  select * into v from public.loyalty_accounts where id = p_account_id for update;
  if not found then return; end if;
  update public.loyalty_accounts set
    points_balance  = greatest(0, coalesce((select sum(delta) from public.loyalty_transactions where account_id = p_account_id), 0)),
    lifetime_points = greatest(0, coalesce((select sum(delta) from public.loyalty_transactions where account_id = p_account_id and delta > 0), 0)),
    updated_at = now()
  where id = p_account_id returning lifetime_points into v_life;
  select value into v_settings from public.store_settings where store_id = v.store_id and key = 'loyalty';
  update public.loyalty_accounts set tier = coalesce((
      select t->>'code' from jsonb_array_elements(coalesce(v_settings->'tiers', '[]'::jsonb)) t
       where (t->>'min')::int <= v_life and (t->>'code') in ('bronze','silver','gold','platinum')
       order by (t->>'min')::int desc limit 1), tier)
  where id = p_account_id;
end $$;

-- Abandoned checkout: never silently reverses an opt-out; only active stores.
create or replace function public.track_abandoned_checkout(p_store_id uuid, p_email text, p_items jsonb, p_cart_total numeric)
returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare v_customer_id uuid; v_email text := lower(btrim(coalesce(p_email, '')));
begin
  if v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'INVALID_EMAIL'; end if;
  if not exists (select 1 from public.stores where id = p_store_id and status in ('active','trial')) then raise exception 'INVALID_STORE'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) > 100 or coalesce(p_cart_total, 0) < 0 then raise exception 'INVALID_CART'; end if;
  select id into v_customer_id from public.customers where store_id = p_store_id and email = v_email;
  insert into public.abandoned_carts (store_id, customer_id, email, items, cart_total)
  values (p_store_id, v_customer_id, v_email, p_items, p_cart_total)
  on conflict (store_id, email) do update set
    items = excluded.items, cart_total = excluded.cart_total, updated_at = now(),
    step = case when public.abandoned_carts.recovered then 0 else public.abandoned_carts.step end,
    recovered = false;                                                   -- opted_out is deliberately left untouched
end $$;

-- Newsletter: never re-subscribes someone who opted out (prevents abuse by third parties).
create or replace function public.subscribe_newsletter(p_store_id uuid, p_email text, p_source text default 'popup')
returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare v_email text := lower(btrim(coalesce(p_email, '')));
begin
  if char_length(v_email) > 254 or v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'INVALID_EMAIL'; end if;
  if not exists (select 1 from public.stores where id = p_store_id and status in ('active','trial')) then raise exception 'INVALID_STORE'; end if;
  if exists (select 1 from public.marketing_consents where store_id = p_store_id and email = v_email
              and channel = 'email' and status = 'opted_out') then return; end if;
  insert into public.newsletter_subscribers (store_id, email, source) values (p_store_id, v_email, left(p_source, 60))
  on conflict (store_id, email) do nothing;
  insert into public.marketing_consents (store_id, email, channel, status, source)
  values (p_store_id, v_email, 'email', 'opted_in', left(p_source, 60))
  on conflict (store_id, email, channel) do nothing;
end $$;

-- Payment options for the checkout UI: only providers that are actually usable.
create or replace function public.store_payment_options(p_store_id uuid)
returns jsonb language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce(jsonb_agg(jsonb_build_object('code', pp.code, 'display_name', pp.display_name)
         order by case pp.code when 'cod' then 0 else 1 end), '[]'::jsonb)
    from public.payment_providers pp
   where pp.store_id = p_store_id and pp.enabled and pp.status = 'connected'
     and exists (select 1 from public.stores s where s.id = p_store_id and s.status in ('active','trial'));
$$;

create or replace function public.get_payment_provider_status(p_store_id uuid, p_code text)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare r public.payment_providers%rowtype;
begin
  if not public.has_store_access(p_store_id, 'store.manage') then raise exception 'forbidden'; end if;
  select * into r from public.payment_providers where store_id = p_store_id and code = p_code;
  if not found then return jsonb_build_object('enabled', false, 'status', 'disconnected'); end if;
  return jsonb_build_object('enabled', r.enabled, 'mode', r.mode, 'status', r.status,
    'charges_enabled', r.charges_enabled, 'payouts_enabled', r.payouts_enabled, 'details_submitted', r.details_submitted,
    'has_own_key', r.secret_ref is not null,
    'connected_account_id', case when r.connected_account_id is null then null else left(r.connected_account_id, 8) || '…' end);
end $$;

-- ----------------------------------------------------------------------------
-- I. Referral rewards are granted at payment (see _finalize_paid_order), not at order placement.
-- ----------------------------------------------------------------------------
drop trigger if exists orders_referral on public.orders;
create unique index if not exists loyalty_tx_referral_uidx on public.loyalty_transactions (referral_id) where reason = 'referral';
create unique index if not exists loyalty_tx_order_purchase_uidx on public.loyalty_transactions (order_id) where reason = 'purchase';

-- ----------------------------------------------------------------------------
-- J. Tighter public policies
-- ----------------------------------------------------------------------------
drop policy if exists reviews_submit on public.reviews;
create policy reviews_submit on public.reviews for insert to anon, authenticated
  with check (status = 'pending' and not verified_purchase and customer_id is null and order_id is null
              and helpful_count = 0 and rating between 1 and 5
              and exists (select 1 from public.products p where p.id = product_id and p.store_id = reviews.store_id and p.status = 'active'));
drop policy if exists analytics_insert on public.analytics_events;
create policy analytics_insert on public.analytics_events for insert to anon, authenticated
  with check (exists (select 1 from public.stores s where s.id = store_id and s.status in ('active','trial')));
drop policy if exists popup_events_insert on public.popup_events;
create policy popup_events_insert on public.popup_events for insert to anon, authenticated
  with check (exists (select 1 from public.stores s where s.id = store_id and s.status in ('active','trial')));

-- ----------------------------------------------------------------------------
-- J2. Store resolution that cannot be spoofed by an arbitrary hostname.
--     With platform_config('platform_domain') set, "<slug>.<platform_domain>" is the ONLY sub-domain pattern
--     accepted; custom domains must be VERIFIED. (Without it, dev behaviour: "<slug>" / "<slug>.x" resolve.)
-- ----------------------------------------------------------------------------
create table if not exists public.platform_config (key text primary key, value text not null);
alter table public.platform_config enable row level security;
revoke all on public.platform_config from anon, authenticated;

create or replace function public.resolve_store(p_domain text)
returns jsonb language sql stable security definer set search_path = public, pg_temp as $$
  with d as (
    select lower(btrim(coalesce(p_domain, ''))) as dom,
           (select value from public.platform_config where key = 'platform_domain') as plat)
  select jsonb_build_object(
    'id', s.id, 'slug', s.slug, 'name', s.name, 'description', s.description,
    'business_model', s.business_model, 'locale', s.default_locale,
    'locales', public.store_locales(s.id),
    'currency', s.default_currency, 'timezone', s.timezone,
    'brand', s.brand, 'design', s.design, 'logo_url', s.logo_url,
    'social_links', s.social_links, 'whatsapp_number', s.whatsapp_number,
    'country', s.country, 'city', s.city)
  from public.stores s cross join d
  where s.status in ('active','trial') and d.dom <> '' and (
        exists (select 1 from public.store_domains sd where sd.store_id = s.id and sd.domain = d.dom and sd.verified)
     or d.dom = s.slug
     or (d.plat is not null and d.dom = s.slug || '.' || d.plat)
     or (d.plat is null and split_part(d.dom, '.', 1) = s.slug))
  order by exists (select 1 from public.store_domains sd where sd.store_id = s.id and sd.domain = d.dom) desc
  limit 1;
$$;

-- Outbox claim marker (atomic queued → sending) + cart restoration link support
alter table public.email_jobs add column if not exists claimed_at timestamptz;
create or replace function public.get_abandoned_cart_lines(p_id uuid)
returns jsonb language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce(jsonb_agg(jsonb_build_object('product_id', i->>'product_id', 'variant_id', i->>'variant_id', 'qty', (i->>'qty')::int)), '[]'::jsonb)
    from public.abandoned_carts a, jsonb_array_elements(a.items) i
   where a.id = p_id and not a.recovered and (i->>'product_id') ~ '^[0-9a-f-]{36}$';
$$;
-- Domain ownership proof (TXT token) for custom domains
alter table public.store_domains add column if not exists verification_token text not null default encode(gen_random_bytes(12), 'hex');
alter function public.search_products(uuid, text, int) set search_path = public, extensions, pg_temp;

-- ----------------------------------------------------------------------------
-- K0. Every SECURITY DEFINER function gets a fixed, trusted search_path with pg_temp LAST
--     (blocks temp-schema object shadowing). store_secret_* keep their vault path.
-- ----------------------------------------------------------------------------
do $$
declare r record;
begin
  for r in select p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace
            where n.nspname = 'public' and p.prokind = 'f' and p.prosecdef
              and p.proname not like 'store\_secret\_%'
              and not exists (select 1 from pg_depend d where d.objid = p.oid and d.deptype = 'e')
  loop
    execute format('alter function %s set search_path = public, extensions, pg_temp', r.sig);
  end loop;
end $$;

-- ----------------------------------------------------------------------------
-- K. EXECUTE privileges. Supabase/Postgres grant EXECUTE to PUBLIC by default, which would make every
--    SECURITY DEFINER function callable by anyone. Lock everything, then grant per audience.
-- ----------------------------------------------------------------------------
do $$
declare r record;
begin
  for r in select p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace
            where n.nspname = 'public' and p.prokind = 'f'
              and not exists (select 1 from pg_depend d where d.objid = p.oid and d.deptype = 'e')   -- skip extension-owned
  loop
    execute format('revoke all on function %s from public, anon, authenticated', r.sig);
    execute format('grant execute on function %s to service_role', r.sig);
  end loop;
end $$;

-- storefront API (anonymous + signed-in shoppers)
grant execute on function public.place_order(jsonb)                                    to anon, authenticated;
grant execute on function public.get_order_confirmation(uuid)                          to anon, authenticated;
grant execute on function public.get_abandoned_cart_lines(uuid)                        to anon, authenticated;
grant execute on function public.resolve_store(text)                                   to anon, authenticated;
grant execute on function public.search_products(uuid, text, int)                      to anon, authenticated;
grant execute on function public.store_payment_options(uuid)                           to anon, authenticated;
grant execute on function public.store_integrations_public(uuid)                       to anon, authenticated;
grant execute on function public.store_locales(uuid)                                   to anon, authenticated;
grant execute on function public.subscribe_newsletter(uuid, text, text)                to anon, authenticated;
grant execute on function public.track_abandoned_checkout(uuid, text, jsonb, numeric)  to anon, authenticated;
grant execute on function public.record_analytics_event(uuid, text, text, text, uuid, uuid, jsonb) to anon, authenticated;
-- signed-in only (each function enforces its own authorization internally)
grant execute on function public.has_store_access(uuid, text)                          to authenticated;
grant execute on function public.get_payment_provider_status(uuid, text)               to authenticated;
grant execute on function public.sales_summary(uuid, date, date)                       to authenticated;
grant execute on function public.update_order_status(uuid, text, text)                 to authenticated;
grant execute on function public.confirm_cod_order(uuid)                               to authenticated;
grant execute on function public.mark_cod_collected(uuid, text)                        to authenticated;
grant execute on function public.customer_downloads(uuid)                              to authenticated;
grant execute on function public.my_loyalty(uuid)                                      to authenticated;
grant execute on function public.my_consents(uuid)                                     to authenticated;
grant execute on function public.set_marketing_consent(uuid, text, text)               to authenticated;
-- Everything else (fulfill_paid_order, claim_download, claim_payment_event, apply_stripe_refund,
-- decrement_inventory, validate_coupon, vault wrappers, triggers…) stays service_role only.

-- Future functions created by migrations must not be callable by browsers unless granted explicitly.
do $$ begin
  alter default privileges in schema public revoke execute on functions from anon, authenticated;
exception when others then
  raise notice 'could not alter default privileges: %', sqlerrm;
end $$;
