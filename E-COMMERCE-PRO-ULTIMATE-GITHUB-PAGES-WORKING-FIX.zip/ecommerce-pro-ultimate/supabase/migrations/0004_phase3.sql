-- ============================================================================
-- 0003_phase3 — Automation engine, referral attribution, customer self-service
-- ============================================================================

-- WHEN [trigger] IF [conditions] THEN [actions]
create table public.automation_rules (
  id          uuid primary key default gen_random_uuid(),
  store_id    uuid not null references public.stores(id) on delete cascade,
  name        text not null,
  trigger_key text not null check (trigger_key in
    ('new_order','payment_confirmed','order_delivered','customer_inactive','low_stock')),
  conditions  jsonb not null default '{}'::jsonb,
  -- conditions: {min_total, has_digital, days, only_digital_store}
  actions     jsonb not null default '[]'::jsonb,
  -- actions: [{type:'send_email',template_key, to:'customer'|'admin'},
  --           {type:'generate_coupon', code_prefix, kind, value, expires_days},
  --           {type:'add_loyalty_points', points},
  --           {type:'notify_admin', subject}]
  enabled     boolean not null default true,
  last_run_at timestamptz,
  created_at  timestamptz not null default now()
);
create index automation_rules_store_idx on public.automation_rules(store_id) where enabled;

-- Exactly-once rule execution per subject (order id / customer id / product id)
create table public.automation_runs (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  rule_id    uuid not null references public.automation_rules(id) on delete cascade,
  subject_id text not null,
  created_at timestamptz not null default now(),
  unique (rule_id, subject_id)
);

-- Merchant reply on reviews
alter table public.reviews add column if not exists response text;
alter table public.reviews add column if not exists responded_at timestamptz;

alter table public.automation_rules enable row level security;
alter table public.automation_runs enable row level security;
create policy automation_rules_tenant on public.automation_rules for all to authenticated
  using (public.has_store_access(store_id, 'marketing.manage'))
  with check (public.has_store_access(store_id, 'marketing.manage'));
create policy automation_runs_read on public.automation_runs for select to authenticated
  using (public.has_store_access(store_id, 'marketing.manage'));

-- Referral attribution: server-side only, fires when an order carries utm.referral_code
create or replace function public.apply_referral() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  v_code text := upper(coalesce(new.utm ->> 'referral_code', ''));
  v_referrer uuid; v_points int; v_settings jsonb;
begin
  if v_code = '' or new.customer_id is null then return new; end if;
  select id into v_referrer from public.customers
  where store_id = new.store_id and referral_code = v_code and id <> new.customer_id;
  if v_referrer is null then return new; end if;

  insert into public.referrals (store_id, referrer_customer_id, referred_customer_id, code, status, order_id)
  values (new.store_id, v_referrer, new.customer_id, v_code, 'ordered', new.id)
  on conflict (store_id, code, referred_customer_id) do nothing;

  select coalesce((select value from public.store_settings where store_id = new.store_id and key = 'loyalty'), '{}'::jsonb)
  into v_settings;
  v_points := coalesce((v_settings ->> 'referral_points')::int, 50);
  insert into public.loyalty_accounts (store_id, customer_id) values (new.store_id, v_referrer)
  on conflict (store_id, customer_id) do nothing;
  insert into public.loyalty_transactions (store_id, account_id, delta, reason, order_id, referral_id)
  select new.store_id, la.id, v_points, 'referral', new.id, r.id
  from public.loyalty_accounts la
  join public.referrals r on r.order_id = new.id and r.referrer_customer_id = v_referrer
  where la.customer_id = v_referrer and la.store_id = new.store_id
  on conflict do nothing;
  return new;
end $$;
create trigger orders_referral after insert on public.orders
  for each row execute function public.apply_referral();

-- Customer self-service: loyalty balance + history (creates account on first call)
create or replace function public.my_loyalty(p_store_id uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_customer_id uuid; v_account public.loyalty_accounts%rowtype;
begin
  select id into v_customer_id from public.customers where store_id = p_store_id and user_id = auth.uid();
  if v_customer_id is null then return jsonb_build_object('balance', 0, 'lifetime', 0, 'tier', 'bronze', 'transactions', '[]'::jsonb); end if;
  insert into public.loyalty_accounts (store_id, customer_id) values (p_store_id, v_customer_id)
  on conflict (store_id, customer_id) do nothing;
  select * into v_account from public.loyalty_accounts where store_id = p_store_id and customer_id = v_customer_id;
  return jsonb_build_object(
    'balance', v_account.points_balance, 'lifetime', v_account.lifetime_points, 'tier', v_account.tier,
    'transactions', coalesce((select jsonb_agg(jsonb_build_object(
        'delta', lt.delta, 'reason', lt.reason, 'order_id', lt.order_id, 'created_at', lt.created_at)
      order by lt.created_at desc) from public.loyalty_transactions lt
      where lt.account_id = v_account.id limit 10), '[]'::jsonb));
end $$;

-- Customer self-service: marketing consent (opt-in / opt-out)
create or replace function public.my_consents(p_store_id uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_email text;
begin
  select email into v_email from public.customers where store_id = p_store_id and user_id = auth.uid();
  if v_email is null then return '[]'::jsonb; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('channel', channel, 'status', status))
    from public.marketing_consents where store_id = p_store_id and email = v_email), '[]'::jsonb);
end $$;

create or replace function public.set_marketing_consent(p_store_id uuid, p_channel text, p_status text)
returns void language plpgsql security definer set search_path = public as $$
declare v_email text; v_customer_id uuid;
begin
  select id, email into v_customer_id, v_email from public.customers where store_id = p_store_id and user_id = auth.uid();
  if v_customer_id is null then raise exception 'CUSTOMER_NOT_FOUND'; end if;
  if p_status not in ('opted_in','opted_out') or p_channel not in ('email','whatsapp','sms') then
    raise exception 'INVALID'; end if;
  insert into public.marketing_consents (store_id, customer_id, email, channel, status, source)
  values (p_store_id, v_customer_id, v_email, p_channel, p_status, 'account')
  on conflict (store_id, email, channel)
  do update set status = excluded.status, updated_at = now();
  if p_channel = 'email' then
    insert into public.newsletter_subscribers (store_id, email) values (p_store_id, v_email)
    on conflict (store_id, email) do update set status = case when p_status = 'opted_in' then 'subscribed' else 'unsubscribed' end;
  end if;
end $$;

-- Recompute loyalty balance/tier from transactions (used by automation worker)
create or replace function public.recalc_loyalty(p_account_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare v public.loyalty_accounts%rowtype; v_settings jsonb;
begin
  select * into v from public.loyalty_accounts where id = p_account_id for update;
  if not found then return; end if;
  update public.loyalty_accounts set
    points_balance = greatest(0, coalesce((select sum(delta) from public.loyalty_transactions where account_id = p_account_id), 0)),
    lifetime_points = greatest(0, coalesce((select sum(delta) from public.loyalty_transactions where account_id = p_account_id and delta > 0), 0))
  where id = p_account_id;
  select value into v_settings from public.store_settings where store_id = v.store_id and key = 'loyalty';
  update public.loyalty_accounts set tier = (
    select t.code from jsonb_array_elements(coalesce(v_settings -> 'tiers', '[]'::jsonb)) t(code, min)
    where (t ->> 'min')::int <= (select lifetime_points from public.loyalty_accounts where id = p_account_id)
    order by (t ->> 'min')::int desc limit 1
  ) where id = p_account_id and exists(select 1 from public.store_settings where store_id = v.store_id and key = 'loyalty');
end $$;
