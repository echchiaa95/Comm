-- ============================================================================
-- E-COMMERCE PRO ULTIMATE — Foundation Schema (Phase 1)
-- PostgreSQL 15+ / Supabase. Multi-tenant: every merchant row carries store_id.
-- ============================================================================

-- [V1.1] SQL/plpgsql function bodies may reference tables created later in the chain
-- (0002_commerce_core). Bodies are re-validated by the schema checker script.
set check_function_bodies = off;

create extension if not exists "pgcrypto";
create extension if not exists "unaccent";

-- ----------------------------------------------------------------------------
-- Helpers
-- ----------------------------------------------------------------------------
create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

-- Generic audit trigger (SECURITY DEFINER so it bypasses RLS and cannot be
-- spoofed by clients). Attach to sensitive tables in section 4.
create or replace function public.audit_row() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.audit_logs (store_id, actor_id, action, table_name, record_id, old_data, new_data)
  values (
    coalesce((to_jsonb(new) ->> 'store_id')::uuid, (to_jsonb(old) ->> 'store_id')::uuid),
    auth.uid(), tg_op, tg_table_name,
    coalesce((to_jsonb(new) ->> 'id'), (to_jsonb(old) ->> 'id')),
    case when tg_op in ('UPDATE','DELETE') then to_jsonb(old) end,
    case when tg_op in ('INSERT','UPDATE') then to_jsonb(new) end
  );
  return coalesce(new, old);
end $$;

-- Central authorization helper. NEVER trust client-supplied store_id:
-- every policy checks the store_users mapping derived from auth.uid().
create or replace function public.has_store_access(p_store_id uuid, p_permission text default null)
returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1
    from public.store_users su
    join public.role_permissions rp on rp.role_id = su.role_id
    join public.permissions p       on p.id = rp.permission_id
    where su.user_id = auth.uid()
      and su.store_id = p_store_id
      and su.status = 'active'
      and (p_permission is null or p.code = p_permission)
  );
$$;

-- ----------------------------------------------------------------------------
-- CORE: stores, settings, domains, users, roles
-- ----------------------------------------------------------------------------
create table public.stores (
  id              uuid primary key default gen_random_uuid(),
  name            text not null check (char_length(name) between 2 and 120),
  slug            text not null unique check (slug ~ '^[a-z0-9-]{2,60}$'),
  business_model  text not null default 'physical'
                  check (business_model in ('physical','digital','hybrid')),
  status          text not null default 'trial'
                  check (status in ('trial','active','suspended','closed')),
  default_locale  text not null default 'en' check (default_locale in ('en','fr','ar')),
  default_currency char(3) not null default 'USD',
  timezone        text not null default 'UTC',
  country         text, city text, category text, description text,
  logo_url        text, favicon_url text,
  contact_email   text, contact_phone text, whatsapp_number text,
  social_links    jsonb not null default '{}'::jsonb,
  brand           jsonb not null default '{}'::jsonb,  -- colors, fonts, preset, theme mode
  design          jsonb not null default '{}'::jsonb,  -- header/footer/sections/layout config
  settings        jsonb not null default '{}'::jsonb,  -- checkout, loyalty, notifications…
  created_by      uuid references auth.users(id),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create trigger stores_updated before update on public.stores
  for each row execute function public.set_updated_at();

create table public.store_settings (           -- key/value: everything configurable, no code changes
  store_id   uuid not null references public.stores(id) on delete cascade,
  key        text not null check (key ~ '^[a-z0-9_.-]{2,80}$'),
  value      jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (store_id, key)
);

create table public.store_domains (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  domain     text not null unique,
  is_primary boolean not null default false,
  verified   boolean not null default false,
  ssl_status text not null default 'pending'
             check (ssl_status in ('pending','active','failed')),
  created_at timestamptz not null default now()
);
create index store_domains_store_idx on public.store_domains(store_id);

create table public.permissions (
  code        text primary key,
  description text not null
);
create table public.roles (
  id   uuid primary key default gen_random_uuid(),
  code text not null unique,                 -- owner, admin, manager, staff, support
  name text not null
);
create table public.role_permissions (
  role_id       uuid not null references public.roles(id) on delete cascade,
  permission_id text not null references public.permissions(code) on delete cascade,
  primary key (role_id, permission_id)
);

create table public.store_users (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  user_id    uuid not null references auth.users(id) on delete cascade,
  role_id    uuid not null references public.roles(id),
  status     text not null default 'active' check (status in ('active','invited','disabled')),
  created_at timestamptz not null default now(),
  unique (store_id, user_id)
);
create index store_users_user_idx on public.store_users(user_id);

create table public.invitations (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  email      text not null,
  role_id    uuid not null references public.roles(id),
  token      text not null unique default encode(gen_random_bytes(24), 'hex'),
  expires_at timestamptz not null default now() + interval '7 days',
  accepted_at timestamptz,
  created_at timestamptz not null default now(),
  unique (store_id, email)
);

-- ----------------------------------------------------------------------------
-- CATALOG: categories, products, variants, media, inventory, discovery
-- Localized fields are jsonb: {"en": …, "fr": …, "ar": …}
-- ----------------------------------------------------------------------------
create table public.categories (
  id          uuid primary key default gen_random_uuid(),
  store_id    uuid not null references public.stores(id) on delete cascade,
  parent_id   uuid references public.categories(id) on delete set null,
  slug        text not null,
  name        jsonb not null,
  description jsonb,
  image_url   text,
  position    int not null default 0,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (store_id, slug)
);
create trigger categories_updated before update on public.categories
  for each row execute function public.set_updated_at();

create table public.products (
  id            uuid primary key default gen_random_uuid(),
  store_id      uuid not null references public.stores(id) on delete cascade,
  type          text not null default 'physical'
                check (type in ('physical','digital','hybrid')),
  status        text not null default 'draft'
                check (status in ('draft','active','archived')),
  slug          text not null,
  sku           text,
  name          jsonb not null,
  short_description jsonb,
  description   jsonb,
  price         numeric(12,2) not null check (price >= 0),
  compare_at_price numeric(12,2) check (compare_at_price is null or compare_at_price >= price),
  cost_price    numeric(12,2),
  currency      char(3) not null default 'USD',
  attributes    jsonb not null default '{}'::jsonb,   -- {"colors":[…],"sizes":[…]}
  track_inventory boolean not null default true,
  inventory_qty int not null default 0,              -- physical, no variants
  low_stock_threshold int not null default 5,
  weight_grams  int,
  has_digital_files boolean not null default false,
  license_key_product boolean not null default false,
  rating_avg    numeric(3,2) not null default 0,
  rating_count  int not null default 0,
  sales_count   int not null default 0,
  published_at  timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (store_id, slug),
  search tsvector generated always as (
    setweight(to_tsvector('simple', coalesce(name ->> 'en','') || ' ' || coalesce(name ->> 'fr','') || ' ' || coalesce(name ->> 'ar','')), 'A') ||
    setweight(to_tsvector('simple', coalesce(short_description ->> 'en','') || ' ' || coalesce(short_description ->> 'fr','') || ' ' || coalesce(short_description ->> 'ar','')), 'B') ||
    setweight(to_tsvector('simple', coalesce(sku,'')), 'C')
  ) stored
);
create trigger products_updated before update on public.products
  for each row execute function public.set_updated_at();

create table public.product_variants (
  id            uuid primary key default gen_random_uuid(),
  product_id    uuid not null references public.products(id) on delete cascade,
  store_id      uuid not null references public.stores(id) on delete cascade,
  sku           text,
  name          jsonb,                                -- e.g. {"en":"Red / M"}
  options       jsonb not null default '{}'::jsonb,   -- {"size":"M","color":"red"}
  price         numeric(12,2),                        -- null = inherit product price
  inventory_qty int not null default 0,
  image_url     text
);
create index product_variants_product_idx on public.product_variants(product_id);

create table public.product_images (
  id         uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  store_id   uuid not null references public.stores(id) on delete cascade,
  variant_id uuid references public.product_variants(id) on delete set null,
  url        text not null,
  alt        jsonb,                                   -- localized alt text
  position   int not null default 0,
  is_primary boolean not null default false
);
create index product_images_product_idx on public.product_images(product_id);

create table public.product_files (                   -- PRIVATE bucket only
  id         uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  store_id   uuid not null references public.stores(id) on delete cascade,
  storage_path text not null,                         -- path in private 'digital-assets' bucket
  file_name  text not null,
  mime_type  text not null,
  size_bytes bigint not null default 0,
  version    int not null default 1,
  preview_allowed boolean not null default false,
  sort_order int not null default 0
);
create index product_files_product_idx on public.product_files(product_id);

create table public.product_categories (
  product_id  uuid not null references public.products(id) on delete cascade,
  category_id uuid not null references public.categories(id) on delete cascade,
  primary key (product_id, category_id)
);

create table public.inventory (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  variant_id uuid references public.product_variants(id) on delete cascade,
  location   text not null default 'default',
  qty_on_hand int not null default 0,
  qty_reserved int not null default 0,
  unique (product_id, variant_id, location)
);

create table public.inventory_movements (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  variant_id uuid references public.product_variants(id) on delete set null,
  delta      int not null,                            -- negative = sale
  reason     text not null check (reason in ('sale','restock','adjustment','cancel','damage')),
  order_id   uuid,
  actor      uuid,
  note       text,
  idempotency_key text unique,                        -- prevents double-decrement on webhook retries
  created_at timestamptz not null default now()
);
create index inventory_movements_store_idx on public.inventory_movements(store_id, created_at desc);

create table public.product_recommendations (
  id          uuid primary key default gen_random_uuid(),
  store_id    uuid not null references public.stores(id) on delete cascade,
  product_id  uuid not null references public.products(id) on delete cascade,
  related_product_id uuid not null references public.products(id) on delete cascade,
  kind        text not null check (kind in ('fbt','also_bought','related','alternative','premium','bundle')),
  score       numeric(8,3) not null default 0,
  manual      boolean not null default false,
  created_at  timestamptz not null default now(),
  check (product_id <> related_product_id),
  unique (product_id, related_product_id, kind)
);

create table public.reviews (
  id          uuid primary key default gen_random_uuid(),
  store_id    uuid not null references public.stores(id) on delete cascade,
  product_id  uuid not null references public.products(id) on delete cascade,
  customer_id uuid,  -- FK to customers added in 0002_commerce_core
  order_id    uuid,                                   -- set by moderation fn → verified purchase
  author_name text not null,
  author_email text,
  rating      smallint not null check (rating between 1 and 5),
  title       text, body text,
  photos      jsonb not null default '[]'::jsonb,
  videos      jsonb not null default '[]'::jsonb,
  verified_purchase boolean not null default false,
  status      text not null default 'pending'
              check (status in ('pending','approved','rejected','featured')),
  helpful_count int not null default 0,
  created_at  timestamptz not null default now()
);
create index reviews_product_idx on public.reviews(product_id) where status in ('approved','featured');

create table public.wishlists (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  customer_id uuid,  -- FK to customers added in 0002_commerce_core
  product_id uuid not null references public.products(id) on delete cascade,
  variant_id uuid references public.product_variants(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (customer_id, product_id, variant_id)
);

-- ============================================================================
-- SECTION 3 — MARKETING, SEO/CONTENT, ANALYTICS, SYSTEM
-- ============================================================================

create table public.coupons (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  code       text not null,
  kind       text not null check (kind in ('percent','fixed','bogo','buy_x_get_y','free_shipping','bundle')),
  value      numeric(12,2) not null default 0,
  apply_to   text not null default 'order'
             check (apply_to in ('order','product','category','shipping')),
  product_ids  jsonb,                                -- null = all
  category_ids jsonb,
  min_order_total numeric(14,2) not null default 0,
  min_qty    int not null default 1,
  max_discount numeric(14,2),
  usage_limit int, used_count int not null default 0,
  per_customer_limit int not null default 0,         -- 0 = unlimited
  first_order_only boolean not null default false,
  stackable  boolean not null default false,
  priority   int not null default 100,
  starts_at  timestamptz, expires_at timestamptz,
  is_active  boolean not null default true,
  created_at timestamptz not null default now(),
  unique (store_id, code)
);

create table public.coupon_usage (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  coupon_id  uuid not null references public.coupons(id) on delete cascade,
  order_id   uuid not null,  -- FK to orders added in 0002_commerce_core
  customer_id uuid,  -- FK to customers added in 0002_commerce_core
  discount_amount numeric(14,2) not null,
  created_at timestamptz not null default now(),
  unique (coupon_id, order_id)                       -- one use per order
);

create table public.campaigns (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  name       text not null,
  channel    text, source text, medium text, content text,  -- UTM set
  budget     numeric(14,2) default 0,
  cost       numeric(14,2) default 0,
  status     text not null default 'draft'
             check (status in ('draft','scheduled','active','paused','ended')),
  starts_at  timestamptz, ends_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.campaign_events (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  campaign_id uuid not null references public.campaigns(id) on delete cascade,
  event_type text not null check (event_type in ('click','view','order')),
  order_id   uuid,  -- FK to orders added in 0002_commerce_core
  amount     numeric(14,2),
  meta       jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index campaign_events_campaign_idx on public.campaign_events(campaign_id, created_at desc);

create table public.abandoned_carts (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  cart_id    uuid,  -- FK to carts added in 0002_commerce_core
  customer_id uuid,  -- FK to customers added in 0002_commerce_core
  email      text, phone text,
  items      jsonb not null default '[]'::jsonb,
  cart_total numeric(14,2) not null default 0,
  step       int not null default 0,                -- recovery stage reached
  recovered  boolean not null default false,
  opted_out  boolean not null default false,
  last_sent_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (store_id, email)                           -- one active recovery flow per email
);

create table public.email_templates (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  key        text not null check (key ~ '^[a-z_]{2,50}$'),
  name       text not null,
  subject    jsonb not null,                          -- {"en":…,"fr":…,"ar":…}
  preheader  jsonb,
  body       jsonb not null,                          -- structured sections (visual editor source)
  design     jsonb not null default '{}'::jsonb,      -- colors/fonts
  is_active  boolean not null default true,
  updated_at timestamptz not null default now(),
  unique (store_id, key)
);

create table public.email_automations (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  trigger_key text not null check (trigger_key in
    ('welcome','first_purchase','abandoned_cart','order_confirmation','shipping_notification',
     'delivery_confirmation','digital_delivery','review_request','back_in_stock',
     'birthday','reactivation','win_back','new_product','promotional')),
  name       text not null,
  delay_minutes int not null default 0,
  template_id uuid references public.email_templates(id) on delete set null,
  enabled    boolean not null default true,
  config     jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table public.email_jobs (                       -- outbox/queue: reliable background delivery
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  automation_id uuid references public.email_automations(id) on delete set null,
  template_id uuid references public.email_templates(id) on delete set null,
  to_email   text not null,
  to_customer_id uuid,  -- FK to customers added in 0002_commerce_core
  payload    jsonb not null default '{}'::jsonb,
  status     text not null default 'queued'
             check (status in ('queued','sending','sent','failed','bounced')),
  attempts   int not null default 0,
  last_error text,
  idempotency_key text unique,                        -- prevents duplicate sends
  scheduled_at timestamptz not null default now(),
  sent_at    timestamptz,
  created_at timestamptz not null default now()
);
create index email_jobs_due_idx on public.email_jobs(status, scheduled_at) where status = 'queued';

create table public.marketing_consents (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  customer_id uuid,  -- FK to customers added in 0002_commerce_core
  email      text,
  channel    text not null check (channel in ('email','whatsapp','sms')),
  status     text not null check (status in ('opted_in','opted_out')),
  source     text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (store_id, email, channel)
);

create table public.loyalty_accounts (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  customer_id uuid not null,  -- FK to customers added in 0002_commerce_core
  points_balance int not null default 0,
  lifetime_points int not null default 0,
  tier       text not null default 'bronze'
             check (tier in ('bronze','silver','gold','platinum')),
  updated_at timestamptz not null default now(),
  unique (store_id, customer_id)
);

create table public.loyalty_transactions (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  account_id uuid not null references public.loyalty_accounts(id) on delete cascade,
  delta      int not null,
  reason     text not null check (reason in ('purchase','referral','review','redeem','adjustment','expire')),
  order_id   uuid,  -- FK to orders added in 0002_commerce_core
  referral_id uuid,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);
create index loyalty_transactions_account_idx on public.loyalty_transactions(account_id, created_at desc);

create table public.referrals (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  referrer_customer_id uuid not null,  -- FK to customers added in 0002_commerce_core
  referred_customer_id uuid,  -- FK to customers added in 0002_commerce_core
  code       text not null,
  status     text not null default 'clicked'
             check (status in ('clicked','signed_up','ordered','rewarded')),
  order_id   uuid,  -- FK to orders added in 0002_commerce_core
  reward_granted boolean not null default false,
  created_at timestamptz not null default now(),
  unique (store_id, code, referred_customer_id)
);

create table public.affiliates (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  user_id    uuid references auth.users(id) on delete set null,
  name       text not null, email text not null,
  code       text not null unique,
  commission_percent numeric(5,2) not null default 10 check (commission_percent between 0 and 100),
  status     text not null default 'pending'
             check (status in ('pending','active','suspended')),
  payout_method jsonb,
  created_at timestamptz not null default now()
);

create table public.affiliate_commissions (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  affiliate_id uuid not null references public.affiliates(id) on delete cascade,
  order_id   uuid not null,  -- FK to orders added in 0002_commerce_core
  amount     numeric(14,2) not null,
  rate       numeric(5,2) not null,
  status     text not null default 'pending'
             check (status in ('pending','approved','paid','rejected')),
  paid_at    timestamptz,
  created_at timestamptz not null default now(),
  unique (affiliate_id, order_id)                    -- idempotent commission
);

create table public.popups (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  name       text not null,
  type       text not null check (type in
    ('welcome','newsletter','exit_intent','discount','announcement','product','free_shipping')),
  content    jsonb not null default '{}'::jsonb,      -- headline, body, image, cta, coupon_id
  targeting  jsonb not null default '{}'::jsonb,    -- pages, cart_min, device, referrer, new/returning
  behavior   jsonb not null default '{}'::jsonb,      -- delay_seconds, scroll_pct, frequency_cap, cooldown_hours
  status     text not null default 'draft' check (status in ('draft','active','paused')),
  priority   int not null default 0,
  starts_at  timestamptz, ends_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.popup_events (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  popup_id   uuid not null references public.popups(id) on delete cascade,
  session_key text not null,
  event      text not null check (event in ('viewed','closed','submitted','converted')),
  meta       jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index popup_events_popup_idx on public.popup_events(popup_id, created_at desc);

create table public.newsletter_subscribers (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  email      text not null,
  status     text not null default 'subscribed' check (status in ('subscribed','unsubscribed')),
  source     text,
  created_at timestamptz not null default now(),
  unique (store_id, email)
);

-- SEO / CONTENT -------------------------------------------------------------
create table public.seo_metadata (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  entity_type text not null check (entity_type in ('store','product','category','page','blog_post')),
  entity_id  uuid not null,
  locale     text not null default 'en' check (locale in ('en','fr','ar')),
  title      text, meta_description text,
  focus_keyword text, keywords jsonb not null default '[]'::jsonb,
  og_image   text, canonical_url text,
  robots     text not null default 'index,follow',
  updated_at timestamptz not null default now(),
  unique (entity_type, entity_id, locale)
);

create table public.redirects (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  from_path  text not null,
  to_path    text not null,
  status_code smallint not null default 301 check (status_code in (301,302,307,308)),
  is_active  boolean not null default true,
  created_at timestamptz not null default now(),
  unique (store_id, from_path)
);

create table public.blog_categories (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  slug text not null, name jsonb not null, description jsonb,
  unique (store_id, slug)
);

create table public.blog_tags (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  slug text not null, name jsonb not null,
  unique (store_id, slug)
);

create table public.blog_posts (
  id          uuid primary key default gen_random_uuid(),
  store_id    uuid not null references public.stores(id) on delete cascade,
  author_id   uuid references public.store_users(id) on delete set null,
  category_id uuid references public.blog_categories(id) on delete set null,
  slug        text not null,
  title       jsonb not null,
  excerpt     jsonb,
  content     jsonb not null,
  cover_image text,
  status      text not null default 'draft'
              check (status in ('draft','scheduled','published','archived')),
  reading_time_min int not null default 1,
  published_at timestamptz,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (store_id, slug),
  search tsvector generated always as (
    to_tsvector('simple', coalesce(title ->> 'en','') || ' ' || coalesce(excerpt ->> 'en',''))
  ) stored
);
create trigger blog_posts_updated before update on public.blog_posts
  for each row execute function public.set_updated_at();

create table public.blog_post_tags (
  post_id uuid not null references public.blog_posts(id) on delete cascade,
  tag_id  uuid not null references public.blog_tags(id) on delete cascade,
  primary key (post_id, tag_id)
);

create table public.store_pages (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  slug       text not null,
  title      jsonb not null,
  content    jsonb not null,
  status     text not null default 'draft' check (status in ('draft','published','archived')),
  show_in_footer boolean not null default false,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (store_id, slug)
);

create table public.store_navigation (
  id       uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  menu_key text not null check (menu_key in ('header','footer','mobile','mega')),
  items    jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now(),
  unique (store_id, menu_key)
);

create table public.store_banners (
  id        uuid primary key default gen_random_uuid(),
  store_id  uuid not null references public.stores(id) on delete cascade,
  placement text not null default 'home_hero'
            check (placement in ('home_hero','home_middle','announcement','category')),
  content   jsonb not null default '{}'::jsonb,
  link      text,
  sort_order int not null default 0,
  is_active boolean not null default true,
  starts_at timestamptz, ends_at timestamptz
);

-- ANALYTICS / EXPERIMENTATION -------------------------------------------------
create table public.analytics_events (
  id         bigint generated always as identity primary key,
  store_id   uuid not null references public.stores(id) on delete cascade,
  session_key text not null,
  customer_id uuid,  -- FK to customers added in 0002_commerce_core
  event      text not null check (event in
    ('page_view','product_view','search','add_to_cart','begin_checkout','add_payment_info','purchase')),
  path       text,
  product_id uuid references public.products(id) on delete set null,
  order_id   uuid,  -- FK to orders added in 0002_commerce_core
  meta       jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
) partition by range (created_at);
create index analytics_events_store_idx on public.analytics_events(store_id, created_at desc);

create table public.conversion_events (
  id         bigint generated always as identity primary key,
  store_id   uuid not null references public.stores(id) on delete cascade,
  order_id   uuid,  -- FK to orders added in 0002_commerce_core
  customer_id uuid,  -- FK to customers added in 0002_commerce_core
  event      text not null,                         -- purchase, begin_checkout…
  value      numeric(14,2), currency char(3),
  utm        jsonb not null default '{}'::jsonb,
  experiment_id uuid, variant_id uuid,
  created_at timestamptz not null default now()
);

create table public.marketing_attribution (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  order_id   uuid not null unique,  -- FK to orders added in 0002_commerce_core
  customer_id uuid,  -- FK to customers added in 0002_commerce_core
  campaign_id uuid references public.campaigns(id) on delete set null,
  affiliate_id uuid references public.affiliates(id) on delete set null,
  utm        jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table public.experiments (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  key        text not null,                          -- e.g. homepage_hero_v1
  name       text not null,
  hypothesis text,
  target     text not null check (target in
    ('homepage_banner','product_image','product_title','product_description','button_text',
     'button_placement','price','promo_message','checkout_layout','popup_design')),
  status     text not null default 'draft'
             check (status in ('draft','running','paused','completed')),
  winning_variant_id uuid,
  starts_at  timestamptz, ends_at timestamptz,
  min_visitors int not null default 500,             -- sufficiency threshold before declaring a winner
  created_at timestamptz not null default now(),
  unique (store_id, key)
);

create table public.experiment_variants (
  id         uuid primary key default gen_random_uuid(),
  experiment_id uuid not null references public.experiments(id) on delete cascade,
  store_id   uuid not null references public.stores(id) on delete cascade,
  key        text not null,                          -- control, variant_a…
  name       text not null,
  payload    jsonb not null,                         -- the actual content under test
  traffic_pct numeric(5,2) not null default 50 check (traffic_pct between 0 and 100),
  is_control boolean not null default false,
  visitors   int not null default 0,
  conversions int not null default 0,
  revenue    numeric(14,2) not null default 0,
  unique (experiment_id, key)
);

create table public.experiment_events (
  id         bigint generated always as identity primary key,
  store_id   uuid not null references public.stores(id) on delete cascade,
  experiment_id uuid not null references public.experiments(id) on delete cascade,
  variant_id uuid not null references public.experiment_variants(id) on delete cascade,
  session_key text not null,
  event      text not null check (event in ('exposure','conversion')),
  value      numeric(14,2),
  created_at timestamptz not null default now()
);

-- SYSTEM ----------------------------------------------------------------------
create table public.integrations (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  provider   text not null check (provider in
    ('google_analytics','google_search_console','google_merchant','google_ads','google_tag_manager',
     'meta_pixel','meta_conversions_api','tiktok_pixel','whatsapp','twilio_sms','smtp','meta_catalog')),
  enabled    boolean not null default false,
  config     jsonb not null default '{}'::jsonb,     -- PUBLIC ids only (GA4 measurement id, pixel id…)
  secret_ref text,                                    -- Vault secret id for private tokens
  status     text not null default 'disconnected'
             check (status in ('disconnected','connected','error')),
  last_sync_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (store_id, provider)
);

create table public.webhook_events (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid references public.stores(id) on delete cascade,
  provider   text not null,                          -- stripe, whatsapp, meta…
  external_id text not null,
  type       text not null,
  payload    jsonb not null,
  processed  boolean not null default false,
  attempts   int not null default 0,
  created_at timestamptz not null default now(),
  unique (provider, external_id)
);

create table public.notification_logs (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  channel    text not null check (channel in ('email','whatsapp','sms','internal')),
  recipient  text not null,
  subject    text, body text,
  provider_message_id text,
  status     text not null default 'queued'
             check (status in ('queued','sent','delivered','failed')),
  attempts   int not null default 0,
  error      text,
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id         bigint generated always as identity primary key,
  store_id   uuid,                                   -- nullable: platform-level events
  actor_id   uuid,
  action     text not null,                          -- INSERT/UPDATE/DELETE
  table_name text not null,
  record_id  text,
  old_data   jsonb, new_data jsonb,
  created_at timestamptz not null default now()
);
create index audit_logs_store_idx on public.audit_logs(store_id, created_at desc);

-- ============================================================================
-- SECTION 4 — SEED, SERVER FUNCTIONS, RLS, TRIGGERS
-- ============================================================================

insert into public.permissions (code, description) values
  ('store.manage','Store settings, design, domains, integrations'),
  ('products.manage','Products, categories, inventory, digital files'),
  ('orders.manage','Orders, carts, shipments, payments view'),
  ('customers.manage','Customers, addresses, CRM, consents, reviews'),
  ('marketing.manage','Campaigns, email, popups, loyalty, affiliates, recommendations'),
  ('discounts.manage','Coupons and promotions'),
  ('seo.manage','SEO metadata, redirects, blog, pages'),
  ('analytics.view','Analytics and experiment reports'),
  ('users.manage','Team members, roles, invitations')
on conflict (code) do nothing;

insert into public.roles (code, name) values
  ('owner','Owner'), ('admin','Admin'), ('manager','Manager'), ('staff','Staff'), ('support','Support')
on conflict (code) do nothing;

insert into public.role_permissions (role_id, permission_id)
select r.id, p.code from public.roles r cross join lateral (
  select code from public.permissions
  where case r.code
    when 'owner' then true
    when 'admin' then code <> 'users.manage'
    when 'manager' then code in ('products.manage','orders.manage','customers.manage','marketing.manage','discounts.manage','seo.manage','analytics.view')
    when 'staff' then code in ('orders.manage','customers.manage','analytics.view')
    when 'support' then code in ('orders.manage','customers.manage')
  end
) p on conflict do nothing;

-- ----------------------------------------------------------------------------
-- resolve_store: public, safe storefront bootstrap (custom domains / subdomains)
-- ----------------------------------------------------------------------------
create or replace function public.resolve_store(p_domain text)
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'id', s.id, 'slug', s.slug, 'name', s.name, 'description', s.description,
    'business_model', s.business_model, 'locale', s.default_locale,
    'currency', s.default_currency, 'timezone', s.timezone,
    'brand', s.brand, 'design', s.design, 'logo_url', s.logo_url,
    'social_links', s.social_links, 'whatsapp_number', s.whatsapp_number,
    'country', s.country, 'city', s.city
  )
  from public.stores s
  where s.status in ('active','trial')
    and (s.slug = lower(split_part(p_domain, '.', 1))
         or exists (select 1 from public.store_domains d
                    where d.store_id = s.id and d.domain = p_domain and d.verified))
  order by (exists (select 1 from public.store_domains d where d.store_id = s.id and d.domain = p_domain)) desc
  limit 1;
$$;

-- Non-secret payment status for the admin UI (keys live in Vault, service-role only)
create or replace function public.get_payment_provider_status(p_store_id uuid, p_code text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare r public.payment_providers%rowtype;
begin
  if not public.has_store_access(p_store_id, 'store.manage') then raise exception 'forbidden'; end if;
  select * into r from public.payment_providers where store_id = p_store_id and code = p_code;
  if not found then return jsonb_build_object('enabled', false, 'status', 'disconnected'); end if;
  return jsonb_build_object('enabled', r.enabled, 'mode', r.mode, 'status', r.status,
    'connected_account_id', case when r.connected_account_id is null then null
      else left(r.connected_account_id, 8) || '…' end);
end $$;

-- ----------------------------------------------------------------------------
-- search_products: typo-tolerant storefront search (trigram + tsvector)
-- ----------------------------------------------------------------------------
create extension if not exists pg_trgm;

create or replace function public.search_products(p_store_id uuid, p_query text, p_limit int default 24)
returns setof public.products language plpgsql stable security definer set search_path = public as $$
begin
  return query
  select p.* from public.products p
  where p.store_id = p_store_id and p.status = 'active'
    and (p.search @@ plainto_tsquery('simple', unaccent(p_query))
         or similarity(unaccent(coalesce(p.name ->> 'en','') || ' ' || coalesce(p.sku,'')), unaccent(p_query)) > 0.25
         or unaccent(p.name::text) ilike '%' || unaccent(p_query) || '%')
  order by ts_rank(p.search, plainto_tsquery('simple', unaccent(p_query))) desc,
           similarity(unaccent(coalesce(p.name ->> 'en','')), unaccent(p_query)) desc
  limit p_limit;
end $$;

-- ----------------------------------------------------------------------------
-- validate_coupon: server-side discount truth (used by place_order only)
-- ----------------------------------------------------------------------------
create or replace function public.validate_coupon(p_store_id uuid, p_code text, p_customer_id uuid, p_subtotal numeric)
returns public.coupons language plpgsql stable security definer set search_path = public as $$
declare v public.coupons%rowtype; v_used_by_customer int;
begin
  select * into v from public.coupons
  where store_id = p_store_id and upper(code) = upper(trim(p_code));
  if not found then raise exception 'INVALID_COUPON'; end if;
  if not v.is_active then raise exception 'COUPON_INACTIVE'; end if;
  if v.starts_at is not null and v.starts_at > now() then raise exception 'COUPON_NOT_STARTED'; end if;
  if v.expires_at is not null and v.expires_at < now() then raise exception 'COUPON_EXPIRED'; end if;
  if v.usage_limit is not null and v.used_count >= v.usage_limit then raise exception 'COUPON_EXHAUSTED'; end if;
  if v.min_order_total > 0 and p_subtotal < v.min_order_total then raise exception 'MIN_ORDER_NOT_MET'; end if;
  if v.per_customer_limit > 0 and p_customer_id is not null then
    select count(*) into v_used_by_customer from public.coupon_usage
    where coupon_id = v.id and customer_id = p_customer_id;
    if v_used_by_customer >= v.per_customer_limit then raise exception 'CUSTOMER_LIMIT_REACHED'; end if;
  end if;
  if v.first_order_only and p_customer_id is not null then
    if exists(select 1 from public.orders where store_id = p_store_id and customer_id = p_customer_id
              and payment_status = 'paid') then raise exception 'NOT_FIRST_ORDER'; end if;
  end if;
  return v;
end $$;

-- ----------------------------------------------------------------------------
-- decrement_inventory: single write path for stock, idempotency-keyed
-- ----------------------------------------------------------------------------
create or replace function public.decrement_inventory(
  p_store_id uuid, p_product_id uuid, p_variant_id uuid, p_qty int,
  p_reason text, p_order_id uuid default null, p_idem_key text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_idem_key is not null and exists(
    select 1 from public.inventory_movements where idempotency_key = p_idem_key) then
    return;                                            -- already applied (webhook retry)
  end if;
  if p_variant_id is not null then
    update public.product_variants set inventory_qty = inventory_qty - p_qty
    where id = p_variant_id and product_id = p_product_id and inventory_qty >= p_qty;
    if not found then raise exception 'INSUFFICIENT_STOCK'; end if;
    update public.products set inventory_qty = greatest(0, inventory_qty - p_qty)
    where id = p_product_id and track_inventory;
  else
    update public.products set inventory_qty = inventory_qty - p_qty
    where id = p_product_id and track_inventory and inventory_qty >= p_qty;
    if not found then raise exception 'INSUFFICIENT_STOCK'; end if;
  end if;
  insert into public.inventory_movements
    (store_id, product_id, variant_id, delta, reason, order_id, idempotency_key)
  values (p_store_id, p_product_id, p_variant_id, -p_qty, p_reason, p_order_id, p_idem_key);
end $$;

-- ----------------------------------------------------------------------------
-- place_order: THE checkout. Prices recomputed from DB. Never trusts the client.
-- p_payload: {store_id, idempotency_key, items:[{product_id,variant_id?,qty}],
--   coupon_code?, payment_method: 'cod'|'stripe', customer:{...}, shipping_address?,
--   shipping_method_id?, utm?}
-- ----------------------------------------------------------------------------
create or replace function public.place_order(p_payload jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_store_id  uuid := (p_payload->>'store_id')::uuid;
  v_idem      text := p_payload->>'idempotency_key';
  v_pay       text := coalesce(p_payload->>'payment_method','cod');
  v_customer_id uuid;
  v_order_id  uuid; v_order public.orders%rowtype;
  v_item      jsonb;
  v_product   public.products%rowtype;
  v_variant   public.product_variants%rowtype;
  v_method    public.shipping_methods%rowtype;
  v_coupon    public.coupons%rowtype;
  v_cart_id   uuid;
  v_qty       int; v_unit numeric;
  v_subtotal  numeric := 0; v_discount numeric := 0; v_shipping numeric := 0;
  v_weight    numeric := 0; v_shipping_country text; v_shipping_city text;
  v_items     jsonb := coalesce(p_payload->'items','[]'::jsonb);
begin
  if not exists(select 1 from public.stores where id = v_store_id and status in ('active','trial'))
    then raise exception 'INVALID_STORE'; end if;
  if v_idem is null or v_idem = '' then raise exception 'IDEMPOTENCY_KEY_REQUIRED'; end if;
  if jsonb_typeof(v_items) <> 'array' or jsonb_array_length(v_items) = 0 then
    raise exception 'EMPTY_CART'; end if;
  if v_pay not in ('cod','stripe') then raise exception 'INVALID_PAYMENT_METHOD'; end if;

  -- Idempotent retry: same key returns the existing order, no duplicates.
  select * into v_order from public.orders where idempotency_key = v_idem;
  if found then
    return jsonb_build_object('order_id', v_order.id, 'order_number', v_order.order_number, 'duplicate', true);
  end if;

  -- Upsert customer (guest checkout supported)
  insert into public.customers (store_id, first_name, last_name, email, phone)
  values (v_store_id,
          p_payload->'customer'->>'first_name', p_payload->'customer'->>'last_name',
          lower(coalesce(p_payload->'customer'->>'email','')),
          p_payload->'customer'->>'phone')
  on conflict (store_id, email) where email is not null
    do update set phone = coalesce(excluded.phone, public.customers.phone)
  returning id into v_customer_id;

  -- Server-side pricing of every line
  for v_item in select * from jsonb_array_elements(v_items) loop
    select * into v_product from public.products
    where id = (v_item->>'product_id')::uuid and store_id = v_store_id and status = 'active';
    if not found then raise exception 'PRODUCT_UNAVAILABLE: %', v_item->>'product_id'; end if;
    v_qty := greatest(1, least(99, coalesce((v_item->>'qty')::int, 1)));
    v_unit := v_product.price;
    if v_item->>'variant_id' is not null then
      select * into v_variant from public.product_variants
      where id = (v_item->>'variant_id')::uuid and product_id = v_product.id;
      if not found then raise exception 'VARIANT_UNAVAILABLE'; end if;
      if v_variant.price is not null then v_unit := v_variant.price; end if;
      if v_product.track_inventory and coalesce(v_variant.inventory_qty,0) < v_qty
        then raise exception 'INSUFFICIENT_STOCK: %', v_product.id; end if;
    elsif v_product.track_inventory and v_product.inventory_qty < v_qty then
      raise exception 'INSUFFICIENT_STOCK: %', v_product.id;
    end if;
    v_subtotal := v_subtotal + v_unit * v_qty;
    v_weight := v_weight + coalesce(v_product.weight_grams,0) * v_qty;
  end loop;

  -- Shipping (physical lines only)
  if exists(select 1 from jsonb_array_elements(v_items) i
            join public.products p on p.id = (i->>'product_id')::uuid and p.type <> 'digital') then
    v_shipping_country := p_payload->'shipping_address'->>'country';
    v_shipping_city    := p_payload->'shipping_address'->>'city';
    if p_payload->>'shipping_method_id' is not null then
      select m.* into v_method from public.shipping_methods m
      join public.shipping_zones z on z.id = m.zone_id
      where m.id = (p_payload->>'shipping_method_id')::uuid and m.store_id = v_store_id
        and m.is_active and z.is_active
        and (z.countries = '["*"]'::jsonb or z.countries ? v_shipping_country)
        and (z.cities is null or z.cities ? v_shipping_city);
      if not found then raise exception 'SHIPPING_METHOD_UNAVAILABLE'; end if;
      if v_method.type = 'free_threshold' and v_subtotal >= coalesce(v_method.free_over, 'Infinity'::numeric)
        then v_shipping := 0;
      elsif v_method.type = 'free_threshold' then v_shipping := v_method.base_price;
      else v_shipping := v_method.base_price; end if;
      if v_method.per_kg_price > 0 then
        v_shipping := v_shipping + v_method.per_kg_price * ceil(v_weight / 1000.0); end if;
    end if;
  end if;

  -- Coupon (server-validated)
  if p_payload->>'coupon_code' is not null and p_payload->>'coupon_code' <> '' then
    v_coupon := public.validate_coupon(v_store_id, p_payload->>'coupon_code', v_customer_id, v_subtotal);
    if v_coupon.kind = 'percent' then
      v_discount := round(v_subtotal * v_coupon.value / 100.0, 2);
      if v_coupon.max_discount is not null then v_discount := least(v_discount, v_coupon.max_discount); end if;
    elsif v_coupon.kind = 'free_shipping' then v_discount := v_shipping;
    else v_discount := least(v_coupon.value, v_subtotal); end if;
  end if;

  insert into public.orders (store_id, order_number, customer_id, customer_snapshot, currency,
    subtotal, discount_total, shipping_total, total, coupon_id, coupon_code,
    payment_method, shipping_method_name, shipping_address, billing_address, notes, utm, idempotency_key)
  values (v_store_id,
    'ORD-' || to_char(now(), 'YYYYMMDD') || '-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,8)),
    v_customer_id,
    jsonb_build_object('first_name', p_payload->'customer'->>'first_name',
                       'last_name', p_payload->'customer'->>'last_name',
                       'email', p_payload->'customer'->>'email', 'phone', p_payload->'customer'->>'phone'),
    coalesce((select default_currency from public.stores where id = v_store_id), 'USD'),
    v_subtotal, v_discount, v_shipping, greatest(0, v_subtotal - v_discount + v_shipping),
    v_coupon.id, v_coupon.code, v_pay, v_method.name, p_payload->'shipping_address',
    coalesce(p_payload->'billing_address', p_payload->'shipping_address'),
    p_payload->>'notes', coalesce(p_payload->'utm','{}'::jsonb), v_idem)
  returning * into v_order;
  v_order_id := v_order.id;

  -- Persist cart snapshot (abandoned-cart audit + recovery source)
  insert into public.carts (store_id, customer_id, status, currency, coupon_id)
  values (v_store_id, v_customer_id, 'active', v_order.currency, v_coupon.id) returning id into v_cart_id;

  -- Line items + inventory decrement (idempotency-keyed per line)
  for v_item in select * from jsonb_array_elements(v_items) loop
    select * into v_product from public.products where id = (v_item->>'product_id')::uuid;
    v_qty := greatest(1, coalesce((v_item->>'qty')::int, 1));
    v_unit := v_product.price; v_variant := null;
    if v_item->>'variant_id' is not null then
      select * into v_variant from public.product_variants where id = (v_item->>'variant_id')::uuid;
      if v_variant.price is not null then v_unit := v_variant.price; end if;
    end if;
    insert into public.cart_items (cart_id, store_id, product_id, variant_id, qty, unit_price)
    values (v_cart_id, v_store_id, v_product.id, v_variant.id, v_qty, v_unit);
    insert into public.order_items (store_id, order_id, product_id, variant_id, name, sku, qty, unit_price, total, is_digital)
    values (v_store_id, v_order_id, v_product.id, v_variant.id, v_product.name,
            coalesce(v_variant.sku, v_product.sku), v_qty, v_unit, v_unit * v_qty,
            v_product.type <> 'physical');
    perform public.decrement_inventory(v_store_id, v_product.id, v_variant.id, v_qty, 'sale', v_order_id,
      v_idem || ':' || (v_item->>'product_id') || ':' || coalesce(v_item->>'variant_id',''));
  end loop;

  update public.carts set status = 'converted' where id = v_cart_id;

  if v_coupon.id is not null then
    update public.coupons set used_count = used_count + 1 where id = v_coupon.id;
    insert into public.coupon_usage (store_id, coupon_id, order_id, customer_id, discount_amount)
    values (v_store_id, v_coupon.id, v_order_id, v_customer_id, v_discount)
    on conflict (coupon_id, order_id) do nothing;
  end if;

  -- Payment row: pending. Status becomes truth only via fulfill_paid_order (webhook).
  insert into public.payments (store_id, order_id, provider, amount, currency, status, method_type)
  values (v_store_id, v_order_id, v_pay, v_order.total, v_order.currency, 'pending', v_pay);

  insert into public.order_status_history (store_id, order_id, from_status, to_status, note)
  values (v_store_id, v_order_id, null, 'pending', 'order placed');

  return jsonb_build_object('order_id', v_order_id, 'order_number', v_order.order_number,
    'total', v_order.total, 'currency', v_order.currency);
end $$;

-- ----------------------------------------------------------------------------
-- fulfill_paid_order: called ONLY by the verified Stripe webhook (or COD path).
-- Idempotent. Creates digital downloads + license keys, awards loyalty, queues
-- transactional emails. This is the ONLY path that marks an order paid.
-- ----------------------------------------------------------------------------
create or replace function public.fulfill_paid_order(p_order_id uuid, p_payment_ref text, p_idem_key text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_order public.orders%rowtype; v_oi public.order_items%rowtype; v_pf public.product_files%rowtype;
  v_key text; v_points int; v_settings jsonb;
begin
  select * into v_order from public.orders where id = p_order_id for update;
  if not found then raise exception 'ORDER_NOT_FOUND'; end if;

  if p_idem_key is not null and exists(select 1 from public.payment_events where event_id = p_idem_key) then
    return jsonb_build_object('order_id', p_order_id, 'duplicate', true);
  end if;
  if v_order.payment_status = 'paid' then
    return jsonb_build_object('order_id', p_order_id, 'already_paid', true);
  end if;

  update public.payments set status = 'succeeded', provider_payment_id = coalesce(provider_payment_id, p_payment_ref)
  where order_id = p_order_id;
  update public.orders set payment_status = 'paid',
    status = case when status = 'pending' then 'confirmed' else status end,
    confirmed_at = coalesce(confirmed_at, now())
  where id = p_order_id;
  update public.customers set total_orders = total_orders + 1, total_spent = total_spent + v_order.total,
    last_order_at = now() where id = v_order.customer_id;
  update public.products p set sales_count = sales_count + oi.qty
  from public.order_items oi where oi.order_id = p_order_id and oi.product_id = p.id;

  -- Digital fulfillment: never before this point (verified payment only).
  for v_oi in select * from public.order_items where order_id = p_order_id and is_digital loop
    for v_pf in select * from public.product_files where product_id = v_oi.product_id order by sort_order loop
      insert into public.digital_downloads
        (store_id, order_id, order_item_id, customer_id, product_id, product_file_id,
         download_limit, expires_at)
      values (v_order.store_id, p_order_id, v_oi.id, v_order.customer_id, v_oi.product_id, v_pf.id,
        coalesce((v_order.settings ?? 'x')::int, 5), now() + interval '30 days')
      on conflict (order_item_id, product_file_id) do nothing;
    end loop;
    if exists(select 1 from public.products where id = v_oi.product_id and license_key_product) then
      for v_qty in 1..v_oi.qty loop
        update public.license_keys set status = 'assigned', order_item_id = v_oi.id,
          customer_id = v_order.customer_id, assigned_at = now()
        where id = (select id from public.license_keys
                    where product_id = v_oi.product_id and status = 'available' limit 1);
      end loop;
    end if;
    update public.order_items set delivered = true where id = v_oi.id;
  end loop;

  -- Loyalty accrual (config-driven; idempotent via unique order link)
  select coalesce((select value from public.store_settings where store_id = v_order.store_id and key = 'loyalty'),
                  '{}'::jsonb) into v_settings;
  if coalesce((v_settings->>'enabled')::bool, false) and v_order.customer_id is not null then
    v_points := floor(v_order.total * coalesce((v_settings->>'points_per_currency')::numeric, 1))::int;
    insert into public.loyalty_transactions (store_id, account_id, delta, reason, order_id)
    select v_order.store_id, la.id, v_points, 'purchase', p_order_id
    from public.loyalty_accounts la
    where la.customer_id = v_order.customer_id and la.store_id = v_order.store_id
      and not exists(select 1 from public.loyalty_transactions lt
                     where lt.order_id = p_order_id and lt.reason = 'purchase');
  end if;

  -- Transactional email outbox (abandoned-cart/promotional flows are separate
  -- and require marketing consent; order confirmation is transactional)
  insert into public.email_jobs (store_id, to_email, to_customer_id, payload, idempotency_key, scheduled_at)
  select v_order.store_id, v_order.customer_snapshot->>'email', v_order.customer_id,
         jsonb_build_object('type','order_confirmation','order_id', p_order_id,
                            'order_number', v_order.order_number, 'total', v_order.total,
                            'locale', (select default_locale from public.stores where id = v_order.store_id)),
         'confirm:' || p_order_id, now()
  where v_order.customer_snapshot->>'email' is not null
  on conflict (idempotency_key) do nothing;

  return jsonb_build_object('order_id', p_order_id, 'fulfilled', true);
end $$;

-- COD confirmation by staff: same fulfillment, permission-checked.
create or replace function public.confirm_cod_order(p_order_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_order public.orders%rowtype;
begin
  select * into v_order from public.orders where id = p_order_id;
  if not public.has_store_access(v_order.store_id, 'orders.manage') then raise exception 'forbidden'; end if;
  if v_order.payment_method <> 'cod' then raise exception 'NOT_COD'; end if;
  perform public.update_order_status(p_order_id, 'confirmed', 'COD order confirmed by staff');
  return public.fulfill_paid_order(p_order_id, 'cod-manual', 'cod:' || p_order_id);
end $$;

-- ----------------------------------------------------------------------------
-- update_order_status: legal transitions + restock on cancel + timestamps
-- ----------------------------------------------------------------------------
create or replace function public.update_order_status(p_order_id uuid, p_status text, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare v_order public.orders%rowtype; v_oi public.order_items%rowtype;
begin
  select * into v_order from public.orders where id = p_order_id for update;
  if not public.has_store_access(v_order.store_id, 'orders.manage') then raise exception 'forbidden'; end if;
  if v_order.status = p_status then return; end if;
  if v_order.status = 'cancelled' or v_order.status = 'delivered' then raise exception 'TERMINAL_STATE'; end if;
  if p_status = 'cancelled' then
    for v_oi in select * from public.order_items where order_id = p_order_id and product_id is not null loop
      perform public.decrement_inventory(v_order.store_id, v_oi.product_id, v_oi.variant_id, -v_oi.qty,
        'cancel', p_order_id, 'cancel:' || p_order_id || ':' || v_oi.id);
    end loop;
  end if;
  update public.orders set
    status = p_status,
    shipped_at   = case when p_status = 'shipped'   then now() else shipped_at end,
    delivered_at = case when p_status = 'delivered' then now() else delivered_at end,
    fulfillment_status = case
      when p_status in ('confirmed','processing') and exists(select 1 from public.order_items
        where order_id = p_order_id and not is_digital) then 'unfulfilled'
      when p_status in ('shipped','delivered') then 'fulfilled' else fulfillment_status end
  where id = p_order_id;
  insert into public.order_status_history (store_id, order_id, from_status, to_status, actor, note)
  values (v_order.store_id, p_order_id, v_order.status, p_status, auth.uid(), p_note);
end $$;

-- ----------------------------------------------------------------------------
-- Smaller engine functions
-- ----------------------------------------------------------------------------
create or replace function public.record_analytics_event(
  p_store_id uuid, p_session_key text, p_event text, p_path text default null,
  p_product_id uuid default null, p_order_id uuid default null, p_meta jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not exists(select 1 from public.stores where id = p_store_id) then return; end if;
  insert into public.analytics_events (store_id, session_key, event, path, product_id, order_id, meta)
  values (p_store_id, p_session_key, p_event, p_path, p_product_id, p_order_id, p_meta);
end $$;

create or replace function public.track_abandoned_checkout(
  p_store_id uuid, p_email text, p_items jsonb, p_cart_total numeric)
returns void language plpgsql security definer set search_path = public as $$
declare v_customer_id uuid;
begin
  if p_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'INVALID_EMAIL'; end if;
  select id into v_customer_id from public.customers where store_id = p_store_id and email = lower(p_email);
  insert into public.abandoned_carts (store_id, customer_id, email, items, cart_total)
  values (p_store_id, v_customer_id, lower(p_email), p_items, p_cart_total)
  on conflict (store_id, email) do update set
    items = excluded.items, cart_total = excluded.cart_total, updated_at = now(),
    opted_out = false;
end $$;

-- Analytics summary for the dashboard (admin-permission checked inside)
create or replace function public.sales_summary(p_store_id uuid, p_from date default null, p_to date default null)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_from date := coalesce(p_from, current_date - 29); v_to date := coalesce(p_to, current_date);
begin
  if not public.has_store_access(p_store_id, 'analytics.view') then raise exception 'forbidden'; end if;
  return (
    with o as (
      select * from public.orders
      where store_id = p_store_id and created_at::date between v_from and v_to
        and status <> 'cancelled'
    )
    select jsonb_build_object(
      'gross_revenue', coalesce(sum(total),0),
      'discounts', coalesce(sum(discount_total),0),
      'shipping', coalesce(sum(shipping_total),0),
      'net_revenue', coalesce(sum(total - discount_total),0),
      'orders', count(*),
      'aov', coalesce(avg(total),0),
      'by_day', coalesce((select jsonb_agg(jsonb_build_object('day', d, 'revenue', r, 'orders', c))
        from (select created_at::date d, sum(total) r, count(*) c from o group by 1 order by 1) x), '[]'::jsonb)
    ) from o
  );
end $$;

-- Review approval keeps product rating in sync (real data only, always)
create or replace function public.sync_product_rating() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' or new.product_id <> old.product_id or new.status <> old.status then
    update public.products p set
      rating_avg  = coalesce((select round(avg(rating),2) from public.reviews
        where product_id = new.product_id and status in ('approved','featured')), 0),
      rating_count = coalesce((select count(*) from public.reviews
        where product_id = new.product_id and status in ('approved','featured')), 0)
    where p.id = new.product_id;
  end if;
  return coalesce(new, old);
end $$;

-- ----------------------------------------------------------------------------
-- handle_new_store: installation wizard backend — auto-configures the right
-- workflows for physical / digital / hybrid without code changes.
-- ----------------------------------------------------------------------------
create or replace function public.handle_new_store() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_role uuid;
begin
  select id into v_role from public.roles where code = 'owner';
  if new.created_by is not null then
    insert into public.store_users (store_id, user_id, role_id) values (new.id, new.created_by, v_role)
    on conflict do nothing;
  end if;

  insert into public.store_settings (store_id, key, value) values
    (new.id, 'checkout', '{"guest_checkout":true,"one_page":true,"whatsapp_button":true,"sticky_add_to_cart":true}'::jsonb),
    (new.id, 'loyalty', '{"enabled":true,"points_per_currency":1,"tiers":[{"code":"bronze","min":0},{"code":"silver","min":500},{"code":"gold","min":1500},{"code":"platinum","min":5000}]}'::jsonb),
    (new.id, 'abandoned_cart', '{"steps":[{"delay_minutes":30,"channel":"email"},{"delay_minutes":720,"channel":"email"},{"delay_minutes":1440,"channel":"email","with_coupon":true},{"delay_minutes":2880,"channel":"email","final":true}]}'::jsonb),
    (new.id, 'seo', '{"generate_sitemap":true,"default_robots":"index,follow"}'::jsonb),
    (new.id, 'notifications', '{"order_email_admin":true}'::jsonb)
  on conflict do nothing;

  -- Cash on Delivery: available by default for physical/hybrid, per spec.
  if new.business_model in ('physical','hybrid') then
    insert into public.payment_providers (store_id, code, display_name, enabled, status)
    values (new.id, 'cod', 'Cash on Delivery', true, 'connected') on conflict do nothing;
    insert into public.shipping_zones (store_id, name, countries, cities)
    values (new.id, 'Default zone', '["*"]'::jsonb,
            case when new.city is not null then jsonb_build_array(new.city) else null end)
    returning id into v_zone;
    insert into public.shipping_methods (store_id, zone_id, name, type, base_price, free_over)
    values (new.id, v_zone, '{"en":"Standard delivery","fr":"Livraison standard","ar":"التوصيل العادي"}'::jsonb,
            'flat', 5.00, null);
  else
    insert into public.payment_providers (store_id, code, display_name, enabled, status)
    values (new.id, 'cod', 'Cash on Delivery', false, 'disconnected') on conflict do nothing;
  end if;
  if new.business_model in ('digital','hybrid') then
    insert into public.payment_providers (store_id, code, display_name, enabled, status)
    values (new.id, 'stripe', 'Stripe', false, 'disconnected') on conflict do nothing;
  end if;

  insert into public.store_navigation (store_id, menu_key, items) values
    (new.id, 'header',  '[{"label":{"en":"Home","fr":"Accueil","ar":"الرئيسية"},"path":"/"}]'::jsonb),
    (new.id, 'footer',  '[{"label":{"en":"Contact","fr":"Contact","ar":"اتصل بنا"},"path":"/page/contact"}]'::jsonb),
    (new.id, 'mobile',  '[]'::jsonb)
  on conflict do nothing;

  insert into public.email_templates (store_id, key, name, subject, body) values
    (new.id, 'order_confirmation', 'Order confirmation',
      '{"en":"Your order {{order_number}} is confirmed","fr":"Votre commande {{order_number}} est confirmée","ar":"تم تأكيد طلبك {{order_number}}"}'::jsonb,
      '{"en":[{"type":"heading","text":"Thank you for your order"},{"type":"order_summary"},{"type":"button","text":"View order","url":"{{order_url}}"}]}'::jsonb),
    (new.id, 'digital_delivery', 'Your download is ready',
      '{"en":"Your files are ready to download","fr":"Vos fichiers sont prêts","ar":"ملفاتك جاهزة للتحميل"}'::jsonb,
      '{"en":[{"type":"heading","text":"Your download is ready"},{"type":"download_links"},{"type":"button","text":"Download","url":"{{download_url}}"}]}'::jsonb),
    (new.id, 'abandoned_cart', 'You left something behind',
      '{"en":"Complete your purchase","fr":"Finalisez votre achat","ar":"أكمل عملية الشراء"}'::jsonb,
      '{"en":[{"type":"heading","text":"Your cart is waiting"},{"type":"cart_items"},{"type":"button","text":"Return to cart","url":"{{cart_url}}"}]}'::jsonb)
  on conflict do nothing;

  return new;
end $$;
create trigger stores_new after insert on public.stores
  for each row execute function public.handle_new_store();

create trigger reviews_sync after insert or update or delete on public.reviews
  for each row execute function public.sync_product_rating();

create trigger audit_products after insert or update or delete on public.products
  for each row execute function public.audit_row();
-- [V1.1] moved to 0002_commerce_core.sql
create trigger audit_coupons after insert or update or delete on public.coupons
  for each row execute function public.audit_row();
create trigger audit_store_settings after insert or update or delete on public.store_settings
  for each row execute function public.audit_row();

-- ----------------------------------------------------------------------------
-- RLS — strict tenant isolation on every merchant table
-- ----------------------------------------------------------------------------
alter table public.stores enable row level security;
alter table public.store_settings enable row level security;
alter table public.store_domains enable row level security;
alter table public.roles enable row level security;
alter table public.permissions enable row level security;
alter table public.store_users enable row level security;
alter table public.invitations enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.product_variants enable row level security;
alter table public.product_images enable row level security;
alter table public.product_files enable row level security;
alter table public.product_categories enable row level security;
alter table public.inventory enable row level security;
alter table public.inventory_movements enable row level security;
alter table public.product_recommendations enable row level security;
alter table public.reviews enable row level security;
alter table public.wishlists enable row level security;
alter table public.coupons enable row level security;
alter table public.coupon_usage enable row level security;
alter table public.campaigns enable row level security;
alter table public.campaign_events enable row level security;
alter table public.abandoned_carts enable row level security;
alter table public.email_templates enable row level security;
alter table public.email_automations enable row level security;
alter table public.email_jobs enable row level security;
alter table public.marketing_consents enable row level security;
alter table public.loyalty_accounts enable row level security;
alter table public.loyalty_transactions enable row level security;
alter table public.referrals enable row level security;
alter table public.affiliates enable row level security;
alter table public.affiliate_commissions enable row level security;
alter table public.popups enable row level security;
alter table public.popup_events enable row level security;
alter table public.newsletter_subscribers enable row level security;
alter table public.seo_metadata enable row level security;
alter table public.redirects enable row level security;
alter table public.blog_categories enable row level security;
alter table public.blog_tags enable row level security;
alter table public.blog_posts enable row level security;
alter table public.blog_post_tags enable row level security;
alter table public.store_pages enable row level security;
alter table public.store_navigation enable row level security;
alter table public.store_banners enable row level security;
alter table public.analytics_events enable row level security;
alter table public.conversion_events enable row level security;
alter table public.marketing_attribution enable row level security;
alter table public.experiments enable row level security;
alter table public.experiment_variants enable row level security;
alter table public.experiment_events enable row level security;
alter table public.integrations enable row level security;
alter table public.webhook_events enable row level security;
alter table public.notification_logs enable row level security;
alter table public.audit_logs enable row level security;

-- Pattern A: tenant tables fully managed by permitted staff (generated per table).
do $$
declare r record;
begin
  for r in
    select * from (values
      ('store_settings','store.manage'),('store_domains','store.manage'),
      ('categories','products.manage'),('products','products.manage'),
      ('product_variants','products.manage'),('product_images','products.manage'),
      ('product_files','products.manage'),('inventory','products.manage'),
      ('inventory_movements','products.manage'),('product_recommendations','marketing.manage'),
      ('customers','customers.manage'),('customer_addresses','customers.manage'),
      ('shipping_zones','store.manage'),('shipping_methods','store.manage'),
      ('carts','orders.manage'),('cart_items','orders.manage'),
      ('orders','orders.manage'),('order_items','orders.manage'),
      ('order_status_history','orders.manage'),('payments','orders.manage'),
      ('refunds','orders.manage'),('shipments','orders.manage'),
      ('digital_downloads','orders.manage'),('download_logs','orders.manage'),
      ('license_keys','products.manage'),
      ('coupons','discounts.manage'),('coupon_usage','discounts.manage'),
      ('campaigns','marketing.manage'),('campaign_events','marketing.manage'),
      ('abandoned_carts','marketing.manage'),
      ('email_templates','marketing.manage'),('email_automations','marketing.manage'),('email_jobs','marketing.manage'),
      ('marketing_consents','customers.manage'),
      ('loyalty_accounts','marketing.manage'),('loyalty_transactions','marketing.manage'),
      ('referrals','marketing.manage'),('affiliates','marketing.manage'),('affiliate_commissions','marketing.manage'),
      ('popups','marketing.manage'),('popup_events','marketing.manage'),('newsletter_subscribers','marketing.manage'),
      ('reviews','customers.manage'),
      ('seo_metadata','seo.manage'),('redirects','seo.manage'),
      ('blog_categories','seo.manage'),('blog_tags','seo.manage'),
      ('blog_posts','seo.manage'),('blog_post_tags','seo.manage'),
      ('store_pages','store.manage'),('store_navigation','store.manage'),('store_banners','store.manage'),
      ('experiments','marketing.manage'),('experiment_variants','marketing.manage'),('experiment_events','analytics.view'),
      ('integrations','store.manage'),('webhook_events','store.manage'),('notification_logs','store.manage'),
      ('marketing_attribution','marketing.manage')
    ) as x(table_name, perm)
  loop
    if to_regclass('public.' || r.table_name) is null then continue; end if;  -- [V1.1] created later
    execute format(
      'create policy "%s_tenant" on public.%I for all to authenticated
       using (public.has_store_access(store_id, %L))
       with check (public.has_store_access(store_id, %L))',
      r.table_name, r.table_name, r.perm, r.perm);
  end loop;
end $$;

-- Pattern B: public storefront read (anon) for published content only.
create policy products_public   on public.products        for select to anon, authenticated using (status = 'active');
create policy categories_public on public.categories      for select to anon, authenticated using (is_active);
create policy blog_public       on public.blog_posts      for select to anon, authenticated using (status = 'published');
create policy pages_public      on public.store_pages     for select to anon, authenticated using (status = 'published');
create policy nav_public        on public.store_navigation for select to anon, authenticated using (true);
create policy banners_public    on public.store_banners   for select to anon, authenticated using (
  is_active and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at >= now()));
create policy redirects_public on public.redirects for select to anon, authenticated using (is_active);
create policy popups_public    on public.popups    for select to anon, authenticated using (
  status = 'active' and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at >= now()));
create policy reviews_public   on public.reviews   for select to anon, authenticated using (status in ('approved','featured'));
-- Reviews may be submitted by anyone; moderation keeps them honest. New ones are always pending.
create policy reviews_submit   on public.reviews   for insert to anon, authenticated with check (status = 'pending');
-- Variant/image read follows its product's visibility.
create policy variants_public  on public.product_variants for select to anon, authenticated using (
  exists(select 1 from public.products p where p.id = product_id and p.status = 'active'));
create policy images_public    on public.product_images   for select to anon, authenticated using (
  exists(select 1 from public.products p where p.id = product_id and p.status = 'active'));

-- Anonymous tracking inserts (no reads).
create policy analytics_insert on public.analytics_events for insert to anon, authenticated with check (true);
create policy popup_events_insert on public.popup_events for insert to anon, authenticated with check (true);

-- Store bootstrap: any signed-in user may create a store (wizard); manage requires membership.
create policy stores_select on public.stores for select to authenticated
  using (public.has_store_access(id));
create policy stores_insert on public.stores for insert to authenticated
  with check (created_by = auth.uid());
create policy stores_update on public.stores for update to authenticated
  using (public.has_store_access(id, 'store.manage'))
  with check (public.has_store_access(id, 'store.manage'));

-- Team: members visible to teammates; management needs users.manage.
create policy store_users_select on public.store_users for select to authenticated
  using (public.has_store_access(store_id) or user_id = auth.uid());
create policy store_users_write on public.store_users for all to authenticated
  using (public.has_store_access(store_id, 'users.manage'))
  with check (public.has_store_access(store_id, 'users.manage'));
create policy invitations_all on public.invitations for all to authenticated
  using (public.has_store_access(store_id, 'users.manage'))
  with check (public.has_store_access(store_id, 'users.manage'));
create policy roles_read on public.roles for select to authenticated using (true);
create policy permissions_read on public.permissions for select to authenticated using (true);

-- [V1.1] moved to 0002_commerce_core.sql
: staff read; only the SECURITY DEFINER trigger writes (bypasses RLS as owner).
create policy audit_read on public.audit_logs for select to authenticated
  using (store_id is null or public.has_store_access(store_id));

-- Hard blocks: payment secrets and webhook inbox are service-role ONLY.
-- [V1.1] moved to 0002_commerce_core.sql
revoke select (secret_ref, webhook_secret_ref) on public.integrations from anon, authenticated;

-- Helpful indexes not covered above
create index products_store_status_idx on public.products(store_id, status);
create index coupons_store_code_idx on public.coupons(store_id, upper(code));
create index abandoned_carts_due_idx on public.abandoned_carts(store_id, step, last_sent_at);
create index email_templates_store_key_idx on public.email_templates(store_id, key);
-- [V1.1] moved to 0002_commerce_core.sql
create index loyalty_tx_order_uidx on public.loyalty_transactions(order_id) where reason = 'purchase';
