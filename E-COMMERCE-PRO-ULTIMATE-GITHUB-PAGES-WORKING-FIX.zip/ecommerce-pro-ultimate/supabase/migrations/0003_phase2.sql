-- ============================================================================
-- 0002_phase2 — RPCs needed by Phase 2 workers + storefront
-- ============================================================================

-- Atomic, guarded download counter (called by deliver-download edge function)
create or replace function public.record_download(p_download_id uuid, p_ip text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  update public.digital_downloads
  set download_count = download_count + 1
  where id = p_download_id
    and not revoked
    and (expires_at is null or expires_at > now())
    and download_count < download_limit;
end $$;

-- Download links for the transactional "digital delivery" email (service-role context)
create or replace function public.customer_downloads_by_order(p_order_id uuid)
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object(
      'token', dd.token, 'file_name', pf.file_name, 'mime_type', pf.mime_type
    ) order by pf.sort_order), '[]'::jsonb)
  from public.digital_downloads dd
  join public.product_files pf on pf.id = dd.product_file_id
  where dd.order_id = p_order_id and not dd.revoked;
$$;

-- Customer's download library (storefront). Scoped to auth.uid()'s customer row.
create or replace function public.customer_downloads(p_store_id uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_customer_id uuid;
begin
  select id into v_customer_id from public.customers
  where store_id = p_store_id and user_id = auth.uid();
  if v_customer_id is null then return '[]'::jsonb; end if;
  return coalesce((
    select jsonb_agg(jsonb_build_object(
        'download_id', dd.id, 'token', dd.token,
        'file_name', pf.file_name, 'mime_type', pf.mime_type, 'size_bytes', pf.size_bytes,
        'order_number', o.order_number,
        'download_count', dd.download_count, 'download_limit', dd.download_limit,
        'expires_at', dd.expires_at, 'revoked', dd.revoked, 'created_at', dd.created_at
      ) order by dd.created_at desc)
    from public.digital_downloads dd
    join public.product_files pf on pf.id = dd.product_file_id
    join public.orders o on o.id = dd.order_id
    where dd.store_id = p_store_id and dd.customer_id = v_customer_id
  ), '[]'::jsonb);
end $$;

-- Public, non-secret payment options for the checkout UI (enabled only)
create or replace function public.store_payment_options(p_store_id uuid)
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object(
      'code', pp.code, 'display_name', pp.display_name
    ) order by case pp.code when 'cod' then 0 else 1 end), '[]'::jsonb)
  from public.payment_providers pp
  where pp.store_id = p_store_id and pp.enabled
    and exists(select 1 from public.stores s
               where s.id = p_store_id and s.status in ('active','trial'));
$$;

-- Newsletter subscription = marketing consent, recorded and idempotent
create or replace function public.subscribe_newsletter(p_store_id uuid, p_email text, p_source text default 'popup')
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'INVALID_EMAIL'; end if;
  insert into public.newsletter_subscribers (store_id, email, source)
  values (p_store_id, lower(p_email), p_source)
  on conflict (store_id, email) do update set status = 'subscribed';
  insert into public.marketing_consents (store_id, email, channel, status, source)
  values (p_store_id, lower(p_email), 'email', 'opted_in', p_source)
  on conflict (store_id, email, channel)
  do update set status = 'opted_in', updated_at = now();
end $$;

-- Public execute is intentional for these (they are the storefront API surface).
-- revoke execute from anon on internal helpers:
revoke execute on function public.record_download(uuid, text) from anon;
