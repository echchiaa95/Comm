-- 0007_public_product_column_security
-- Prevent public/merchant browser roles from reading internal product cost data.
-- Service-role backend operations retain access. This is a forward-only migration.

revoke select on table public.products from anon, authenticated;

grant select (
  id, store_id, type, status, slug, sku, name, short_description, description,
  price, compare_at_price, currency, attributes, track_inventory, inventory_qty,
  low_stock_threshold, weight_grams, has_digital_files, license_key_product,
  rating_avg, rating_count, sales_count, published_at, created_at, updated_at
) on table public.products to anon, authenticated;

-- The original RPC returned SETOF products, which includes cost_price. Replace it
-- with an explicit public projection so search cannot bypass column privileges.
drop function if exists public.search_products(uuid, text, integer);

create function public.search_products(p_store_id uuid, p_query text, p_limit integer default 24)
returns table (
  id uuid,
  store_id uuid,
  type text,
  status text,
  slug text,
  sku text,
  name jsonb,
  short_description jsonb,
  description jsonb,
  price numeric,
  compare_at_price numeric,
  currency character(3),
  attributes jsonb,
  track_inventory boolean,
  inventory_qty integer,
  low_stock_threshold integer,
  weight_grams integer,
  has_digital_files boolean,
  license_key_product boolean,
  rating_avg numeric,
  rating_count integer,
  sales_count integer,
  published_at timestamptz,
  created_at timestamptz,
  updated_at timestamptz
)
language sql
stable
security definer
set search_path = public, extensions, pg_temp
as $$
  select
    p.id, p.store_id, p.type, p.status, p.slug, p.sku, p.name,
    p.short_description, p.description, p.price, p.compare_at_price, p.currency,
    p.attributes, p.track_inventory, p.inventory_qty, p.low_stock_threshold,
    p.weight_grams, p.has_digital_files, p.license_key_product, p.rating_avg,
    p.rating_count, p.sales_count, p.published_at, p.created_at, p.updated_at
  from public.products p
  where p.store_id = p_store_id
    and p.status = 'active'
    and (
      p.search @@ plainto_tsquery('simple', unaccent(p_query))
      or similarity(unaccent(coalesce(p.name ->> 'en','') || ' ' || coalesce(p.sku,'')), unaccent(p_query)) > 0.25
      or unaccent(p.name::text) ilike '%' || unaccent(p_query) || '%'
    )
  order by
    ts_rank(p.search, plainto_tsquery('simple', unaccent(p_query))) desc,
    similarity(unaccent(coalesce(p.name ->> 'en','')), unaccent(p_query)) desc
  limit greatest(1, least(coalesce(p_limit, 24), 100));
$$;

revoke all on function public.search_products(uuid, text, integer) from public;
grant execute on function public.search_products(uuid, text, integer) to anon, authenticated;
