-- ============================================================================
-- 0004_phase4 — SEO surface + consent-safe public integrations
-- ============================================================================

-- Public, non-secret integration config for the storefront (GA4 id, pixel ids…).
-- Secrets stay behind secret_ref, readable only by edge functions.
create or replace function public.store_integrations_public(p_store_id uuid)
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('provider', i.provider, 'config', i.config)
    order by i.provider), '[]'::jsonb)
  from public.integrations i
  where i.store_id = p_store_id and i.enabled and i.status = 'connected';
$$;

-- Hreflang/SEO alternates need the store's public locales
create or replace function public.store_locales(p_store_id uuid)
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce((
    select jsonb_build_array(s.default_locale) || coalesce(nullif(s.settings -> 'extra_locales', 'null'::jsonb), '[]'::jsonb)
    from public.stores s where s.id = p_store_id), '["en"]'::jsonb);
$$;
