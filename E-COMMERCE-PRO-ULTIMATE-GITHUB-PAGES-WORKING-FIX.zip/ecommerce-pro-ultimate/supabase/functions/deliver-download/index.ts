// supabase functions deploy deliver-download --no-verify-jwt   (customers open the emailed link in a browser)
// The ONLY way a customer gets a file. The unguessable 192-bit token is the bearer entitlement; the database
// (claim_download) enforces: verified payment, not revoked, not expired, attempt limit, rate limit, and logs
// every attempt. The response is a 60-second signed URL for the PRIVATE 'digital-assets' bucket.
import { adminClient, json } from "../_shared/http.ts";

const MESSAGES: Record<string, [number, string]> = {
  invalid: [404, "invalid link"], revoked: [403, "access revoked"], not_paid: [402, "payment not confirmed"],
  expired: [410, "link expired"], limit_reached: [429, "download limit reached"], rate_limited: [429, "too many attempts, retry shortly"],
  file_missing: [404, "file unavailable"],
};

Deno.serve(async (req) => {
  if (req.method !== "GET") return json({ error: "method not allowed" }, 405);
  const token = new URL(req.url).searchParams.get("token") ?? "";
  const admin = adminClient();
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null;

  const { data: claim, error } = await admin.rpc("claim_download", {
    p_token: token, p_ip: ip, p_user_agent: req.headers.get("user-agent") });
  if (error) return json({ error: "service error" }, 500);
  if (!claim?.ok) {
    const [status, msg] = MESSAGES[claim?.reason as string] ?? [403, "denied"];
    return json({ error: msg }, status);
  }
  const { data: signed, error: sErr } = await admin.storage.from("digital-assets")
    .createSignedUrl(claim.storage_path, 60, { download: claim.file_name });
  if (sErr || !signed) {
    await admin.rpc("release_download", { p_download_id: claim.download_id });   // do not burn an attempt on our failure
    return json({ error: "storage error" }, 500);
  }
  return new Response(null, { status: 302, headers: { Location: signed.signedUrl, "Cache-Control": "no-store", "Referrer-Policy": "no-referrer" } });
});
