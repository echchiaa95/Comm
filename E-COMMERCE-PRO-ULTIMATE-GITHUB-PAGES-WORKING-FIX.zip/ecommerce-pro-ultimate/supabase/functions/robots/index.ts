// supabase functions deploy robots --no-verify-jwt
// Per-store robots.txt (route /robots.txt on the store domain → ?store=<host>). Private areas are disallowed in
// every language prefix and the Sitemap line points at the STORE domain, never at the function host.
import { adminClient, storeReturnBase } from "../_shared/http.ts";

Deno.serve(async (req) => {
  const url = new URL(req.url);
  const admin = adminClient();
  const storeInput = (url.searchParams.get("store") ?? "").toLowerCase();
  if (!storeInput) return new Response("store parameter required", { status: 400 });
  const { data: store } = await admin.rpc("resolve_store", { p_domain: storeInput });
  if (!store) return new Response("store not found", { status: 404 });
  const id = (store as { id: string }).id;
  const base = await storeReturnBase(admin, id, storeInput.includes(".") ? `https://${storeInput}` : null);
  if (!base) return new Response("store has no public domain", { status: 409 });

  const { data: setting } = await admin.from("store_settings").select("value").eq("store_id", id).eq("key", "robots").maybeSingle();
  const custom = (setting?.value as { text?: string } | null)?.text?.trim();
  const priv = ["admin", "login", "cart", "checkout", "account", "order", "downloads"];
  const dis = ["", "/en", "/fr", "/ar"].flatMap((p) => priv.map((d) => `Disallow: ${p}/${d}`)).join("\n");
  const body = `${custom ? custom : `User-agent: *\nAllow: /\n${dis}`}\n\nSitemap: ${base}/sitemap.xml\n`;
  return new Response(body, { headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "public, max-age=3600" } });
});
