// supabase functions deploy sitemap --no-verify-jwt
// Multi-store, multi-language XML sitemaps. URLs are ALWAYS absolute URLs on the store's own public domain
// (verified custom domain → <slug>.PLATFORM_DOMAIN → ALLOWED_ORIGINS[0]); never the Supabase function host.
//   Route it from the store domain:  /sitemap.xml → ?store=<host>   /sitemap-<type>.xml → ?store=<host>&type=<type>
// Only public, indexable content is listed (never admin, cart, checkout, account, orders, downloads).
// Each localized URL is its own page (/fr/…, /ar/…) with reciprocal hreflang alternates + x-default.
import { adminClient, json, storeReturnBase } from "../_shared/http.ts";

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const TYPES = ["products", "categories", "pages", "blog"] as const;

Deno.serve(async (req) => {
  const url = new URL(req.url);
  const admin = adminClient();
  const storeInput = (url.searchParams.get("store") ?? "").toLowerCase();
  const type = url.searchParams.get("type") ?? "index";
  if (!storeInput) return json({ error: "store parameter required" }, 400);

  const { data: store } = await admin.rpc("resolve_store", { p_domain: storeInput });
  if (!store) return new Response("store not found", { status: 404 });
  const s = store as { id: string; locale: string; locales?: string[] };
  const requested = storeInput.includes(".") ? `https://${storeInput}` : null;
  const base = await storeReturnBase(admin, s.id, requested);
  if (!base) return new Response("store has no public domain", { status: 409 });

  const def = s.locale;
  const locales = [...new Set([def, ...((s.locales ?? []) as string[])])].filter((l) => ["en", "fr", "ar"].includes(l));
  const localized = (l: string, path: string) => `${base}${l === def ? "" : `/${l}`}${path === "/" ? (l === def ? "/" : "") : path}`;
  const xmlHead = `<?xml version="1.0" encoding="UTF-8"?>`;
  const headers = { "Content-Type": "application/xml; charset=utf-8", "Cache-Control": "public, max-age=3600" };

  if (type === "index") {
    return new Response(`${xmlHead}<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${TYPES
      .map((t) => `<sitemap><loc>${esc(`${base}/sitemap-${t}.xml`)}</loc></sitemap>`).join("")}</sitemapindex>`, { headers });
  }
  if (!(TYPES as readonly string[]).includes(type)) return new Response("unknown type", { status: 400 });

  // Entities explicitly marked noindex in the SEO center are excluded.
  const entity = { products: "product", categories: "category", pages: "page", blog: "blog_post" }[type as typeof TYPES[number]];
  const { data: seo } = await admin.from("seo_metadata").select("entity_id, robots").eq("store_id", s.id).eq("entity_type", entity);
  const noindex = new Set((seo ?? []).filter((r) => String(r.robots ?? "").includes("noindex")).map((r) => r.entity_id));

  let rows: { id: string; path: string; lastmod: string | null }[] = [];
  const sid = s.id;
  if (type === "products") {
    const { data } = await admin.from("products").select("id, slug, updated_at").eq("store_id", sid).eq("status", "active").order("updated_at", { ascending: false }).limit(5000);
    rows = (data ?? []).map((p) => ({ id: p.id, path: `/product/${p.slug}`, lastmod: p.updated_at }));
  } else if (type === "categories") {
    const { data } = await admin.from("categories").select("id, slug, updated_at").eq("store_id", sid).eq("is_active", true).limit(1000);
    rows = (data ?? []).map((c) => ({ id: c.id, path: `/category/${c.slug}`, lastmod: c.updated_at ?? null }));
  } else if (type === "pages") {
    const { data } = await admin.from("store_pages").select("id, slug").eq("store_id", sid).eq("status", "published").limit(1000);
    rows = [{ id: "home", path: "/", lastmod: null }, ...(data ?? []).map((p) => ({ id: p.id, path: `/page/${p.slug}`, lastmod: null }))];
  } else {
    const { data } = await admin.from("blog_posts").select("id, slug, updated_at").eq("store_id", sid).eq("status", "published").order("updated_at", { ascending: false }).limit(5000);
    rows = (data ?? []).map((p) => ({ id: p.id, path: `/blog/${p.slug}`, lastmod: p.updated_at }));
  }

  const alternates = (path: string) => locales.map((l) => `<xhtml:link rel="alternate" hreflang="${l}" href="${esc(localized(l, path))}"/>`).join("") +
    `<xhtml:link rel="alternate" hreflang="x-default" href="${esc(localized(def, path))}"/>`;
  const body = rows.filter((r) => !noindex.has(r.id)).flatMap((r) => locales.map((l) =>
    `<url><loc>${esc(localized(l, r.path))}</loc>${r.lastmod ? `<lastmod>${String(r.lastmod).slice(0, 10)}</lastmod>` : ""}${alternates(r.path)}</url>`)).join("");
  return new Response(`${xmlHead}<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">${body}</urlset>`, { headers });
});
