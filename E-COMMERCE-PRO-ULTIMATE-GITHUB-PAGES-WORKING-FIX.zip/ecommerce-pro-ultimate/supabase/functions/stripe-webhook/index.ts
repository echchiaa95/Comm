// supabase functions deploy stripe-webhook --no-verify-jwt   (Stripe cannot send a Supabase JWT;
// authenticity is established ONLY by the Stripe signature over the RAW body — see supabase/config.toml)
//
// Event state machine (table payment_events): received → processing → succeeded | failed | retryable | ignored.
//   • duplicate (already succeeded/ignored) → 200, nothing re-run
//   • failed / retryable / stale "processing" → re-claimed and re-processed on Stripe's retry
//   • transient error → 500 (Stripe retries); permanent business error → recorded as failed, 200
import Stripe from "npm:stripe@14";
import { adminClient, fromMinor, json } from "../_shared/http.ts";

const PERMANENT = ["ORDER_NOT_FOUND", "AMOUNT_MISMATCH", "CURRENCY_MISMATCH", "NOT_ONLINE_ORDER", "STORE_MISMATCH"];

Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ error: "method not allowed" }, 405);
  const signature = req.headers.get("stripe-signature");
  if (!signature) return json({ error: "missing signature" }, 400);
  const rawBody = await req.text();                                   // raw bytes: required for signature verification
  const admin = adminClient();

  // Candidate signing secrets: per-store (merchant-owned account) when ?store= is given, else platform + Connect endpoints.
  const storeParam = new URL(req.url).searchParams.get("store");
  const secrets: string[] = [];
  if (storeParam) {
    const { data: p } = await admin.from("payment_providers").select("webhook_secret_ref")
      .eq("store_id", storeParam).eq("code", "stripe").maybeSingle();
    if (p?.webhook_secret_ref) {
      const { data: s } = await admin.rpc("store_secret_get", { p_id: p.webhook_secret_ref });
      if (s) secrets.push(s as string);
    }
  } else {
    for (const k of ["STRIPE_WEBHOOK_SECRET", "STRIPE_CONNECT_WEBHOOK_SECRET"]) {
      const v = Deno.env.get(k); if (v) secrets.push(v);
    }
  }
  const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") ?? "sk_unused", {
    apiVersion: "2024-06-20", httpClient: Stripe.createFetchHttpClient(),
  });
  let event: Stripe.Event | null = null;
  for (const secret of secrets) {
    try {
      // Async variant is mandatory on Deno (WebCrypto is async-only).
      event = await stripe.webhooks.constructEventAsync(rawBody, signature, secret, undefined, Stripe.createSubtleCryptoProvider());
      break;
    } catch { /* try next secret */ }
  }
  if (!event) return json({ error: "invalid signature" }, 400);

  const obj = event.data.object as Record<string, any>;
  let orderId: string | undefined = obj?.metadata?.order_id;
  let storeId: string | undefined = obj?.metadata?.store_id;
  const claim = await admin.rpc("claim_payment_event", {
    p_provider: "stripe", p_event_id: event.id, p_type: event.type,
    p_store_id: storeId ?? null, p_order_id: orderId ?? null, p_account_id: event.account ?? null, p_payload: event,
  });
  if (claim.error) return json({ error: "claim failed" }, 500);
  if (claim.data === "duplicate") return json({ received: true, duplicate: true }, 200);
  if (claim.data === "in_progress") return json({ received: true, in_progress: true }, 409);   // Stripe will retry

  const finish = (status: string, error?: string) =>
    admin.rpc("finish_payment_event", { p_provider: "stripe", p_event_id: event!.id, p_status: status, p_error: error ?? null });

  try {
    switch (event.type) {
      case "checkout.session.completed":
      case "checkout.session.async_payment_succeeded": {
        const s = obj as Stripe.Checkout.Session;
        // checkout.session.completed with an async method (e.g. SEPA/bank) is NOT paid yet: do not fulfil.
        if (s.payment_status !== "paid" && s.payment_status !== "no_payment_required") { await finish("ignored", `payment_status=${s.payment_status}`); break; }
        if (!orderId) { await finish("ignored", "no order metadata"); break; }
        const { data: order } = await admin.from("orders").select("store_id").eq("id", orderId).maybeSingle();
        if (!order) throw new Error("ORDER_NOT_FOUND");
        if (order.store_id !== storeId || (storeParam && storeParam !== order.store_id)) throw new Error("STORE_MISMATCH");
        const cur = String(s.currency ?? "");
        const { error } = await admin.rpc("fulfill_paid_order", {
          p_order_id: orderId, p_payment_ref: s.id, p_idem_key: `stripe:${event.id}`,
          p_amount: fromMinor(s.amount_total ?? 0, cur), p_currency: cur,
          p_payment_intent: typeof s.payment_intent === "string" ? s.payment_intent : (s.payment_intent as any)?.id ?? null,
        });
        if (error) throw new Error(error.message);
        await finish("succeeded");
        break;
      }
      case "checkout.session.async_payment_failed":
      case "payment_intent.payment_failed": {
        if (!orderId) { await finish("ignored", "no order metadata"); break; }
        const reason = obj?.last_payment_error?.message ?? event.type;
        const { error } = await admin.rpc("mark_payment_failed", { p_order_id: orderId, p_reason: reason });
        if (error) throw new Error(error.message);
        await finish("succeeded");
        break;
      }
      case "checkout.session.expired": {
        const { error } = await admin.rpc("expire_unpaid_orders", { p_older_than_minutes: 15 });
        if (error) throw new Error(error.message);
        await finish("succeeded");
        break;
      }
      case "charge.refunded": {
        const pi = typeof obj.payment_intent === "string" ? obj.payment_intent : obj.payment_intent?.id;
        if (!pi) { await finish("ignored", "no payment_intent"); break; }
        const { error } = await admin.rpc("apply_stripe_refund", {
          p_payment_intent: pi, p_amount_refunded: fromMinor(obj.amount_refunded ?? 0, obj.currency ?? "usd"),
          p_currency: obj.currency, p_refund_id: obj.refunds?.data?.[0]?.id ?? null, p_reason: obj.refunds?.data?.[0]?.reason ?? null,
        });
        if (error) throw new Error(error.message);
        await finish("succeeded");
        break;
      }
      case "account.updated": {
        const a = obj as Stripe.Account;
        const { error } = await admin.rpc("sync_connect_account", {
          p_account_id: a.id, p_charges_enabled: !!a.charges_enabled,
          p_payouts_enabled: !!a.payouts_enabled, p_details_submitted: !!a.details_submitted });
        if (error) throw new Error(error.message);
        await finish("succeeded");
        break;
      }
      default:
        // payment_intent.succeeded is intentionally NOT used for fulfilment: this architecture fulfils from
        // Checkout Session events only (one authoritative path, no double fulfilment).
        await finish("ignored", `unhandled ${event.type}`);
    }
    return json({ received: true }, 200);
  } catch (e) {
    const msg = (e as Error).message ?? "error";
    const permanent = PERMANENT.some((c) => msg.includes(c));
    await finish(permanent ? "failed" : "retryable", msg);
    return permanent ? json({ received: true, failed: msg }, 200) : json({ error: "retry" }, 500);
  }
});
