// supabase functions deploy create-checkout
// Creates a Stripe Checkout Session for an existing pending order (created by place_order).
// Amounts ALWAYS come from the database row. One charge model per store, never mixed:
//   • Connect (Express) → DESTINATION CHARGE on the platform account (platform key + transfer_data).
//   • Merchant-owned key (Vault) → DIRECT charge on the merchant's own Stripe account (no platform fee).
// A store without either cannot take card payments (the platform key is never used as a silent fallback).
import Stripe from "npm:stripe@14";
import { adminClient, corsHeaders, fromMinor, json, localized, storeReturnBase, toMinor } from "../_shared/http.ts";

Deno.serve(async (req) => {
  const admin = adminClient();
  const cors = await corsHeaders(admin, req);
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  if (req.method !== "POST") return json({ error: "method not allowed" }, 405, cors);

  const body = await req.json().catch(() => ({}));
  const orderId = String(body.order_id ?? "");
  if (!/^[0-9a-f-]{36}$/i.test(orderId)) return json({ error: "order_id required" }, 400, cors);

  const { data: order } = await admin.from("orders")
    .select("id, store_id, order_number, subtotal, discount_total, shipping_total, tax_total, total, currency, status, payment_status, payment_method, customer_snapshot")
    .eq("id", orderId).maybeSingle();
  if (!order) return json({ error: "order not found" }, 404, cors);
  if (order.payment_method !== "stripe" || order.status !== "pending" || !["unpaid", "failed"].includes(order.payment_status)) {
    return json({ error: "order not payable via stripe" }, 409, cors);
  }
  if (Number(order.total) <= 0) return json({ error: "nothing to charge" }, 409, cors);

  const { data: provider } = await admin.from("payment_providers")
    .select("enabled, status, mode, connected_account_id, charges_enabled, secret_ref, platform_fee_bps")
    .eq("store_id", order.store_id).eq("code", "stripe").maybeSingle();
  if (!provider?.enabled || provider.status !== "connected") return json({ error: "stripe not enabled for store" }, 409, cors);

  let secretKey: string; let destination: string | null = null;
  if (provider.connected_account_id) {
    if (!provider.charges_enabled) return json({ error: "stripe account cannot accept charges yet" }, 409, cors);
    secretKey = Deno.env.get("STRIPE_SECRET_KEY") ?? "";
    destination = provider.connected_account_id;
  } else if (provider.secret_ref) {
    const { data: k } = await admin.rpc("store_secret_get", { p_id: provider.secret_ref });
    secretKey = (k as string) ?? "";
  } else {
    return json({ error: "stripe not configured for store" }, 409, cors);
  }
  if (!secretKey) return json({ error: "stripe key unavailable" }, 500, cors);

  const stripe = new Stripe(secretKey, { apiVersion: "2024-06-20", httpClient: Stripe.createFetchHttpClient() });
  const cur = String(order.currency).toLowerCase();
  const expectedMinor = toMinor(Number(order.total), cur);

  // Double click / retry: reuse the still-open session for this order.
  const { data: pay } = await admin.from("payments").select("checkout_session_id").eq("order_id", order.id).maybeSingle();
  if (pay?.checkout_session_id) {
    try {
      const existing = await stripe.checkout.sessions.retrieve(pay.checkout_session_id);
      if (existing.status === "open" && existing.url && existing.amount_total === expectedMinor) {
        return json({ checkout_url: existing.url, reused: true }, 200, cors);
      }
    } catch { /* fall through and create a new session */ }
  }

  const base = await storeReturnBase(admin, order.store_id, req.headers.get("Origin") ?? body.return_origin);
  if (!base) return json({ error: "store has no customer-facing domain configured" }, 409, cors);

  const { data: items } = await admin.from("order_items").select("name, qty, unit_price").eq("order_id", order.id);
  const { data: store } = await admin.from("stores").select("default_locale").eq("id", order.store_id).single();
  const line_items: Stripe.Checkout.SessionCreateParams.LineItem[] = (items ?? []).map((i) => ({
    quantity: i.qty,
    price_data: { currency: cur, unit_amount: toMinor(Number(i.unit_price), cur),
      product_data: { name: localized(i.name, store?.default_locale) } },
  }));
  if (Number(order.shipping_total) > 0) line_items.push({ quantity: 1,
    price_data: { currency: cur, unit_amount: toMinor(Number(order.shipping_total), cur), product_data: { name: "Shipping" } } });
  if (Number(order.tax_total) > 0) line_items.push({ quantity: 1,
    price_data: { currency: cur, unit_amount: toMinor(Number(order.tax_total), cur), product_data: { name: "Tax" } } });

  let discounts: Stripe.Checkout.SessionCreateParams.Discount[] | undefined;
  if (Number(order.discount_total) > 0) {
    const coupon = await stripe.coupons.create({ amount_off: toMinor(Number(order.discount_total), cur), currency: cur,
      duration: "once", name: `Order ${order.order_number}` }, { idempotencyKey: `coupon:${order.id}:${expectedMinor}` });
    discounts = [{ coupon: coupon.id }];
  }

  const meta = { store_id: order.store_id, order_id: order.id, order_number: order.order_number };
  const fee = destination ? Math.floor(expectedMinor * (provider.platform_fee_bps ?? 0) / 10000) : 0;
  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    customer_email: order.customer_snapshot?.email ?? undefined,
    line_items, discounts, metadata: meta,
    expires_at: Math.floor(Date.now() / 1000) + 31 * 60,
    success_url: `${base}/order/${order.id}/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${base}/checkout?cancelled=1`,
    payment_intent_data: {
      metadata: meta,
      ...(destination ? { transfer_data: { destination }, ...(fee > 0 ? { application_fee_amount: fee } : {}) } : {}),
    },
  }, { idempotencyKey: `checkout:${order.id}:${expectedMinor}:${pay?.checkout_session_id ?? "first"}` });

  // Safety net: Stripe's total must equal the order total stored in our database.
  if (session.amount_total !== expectedMinor) {
    await stripe.checkout.sessions.expire(session.id).catch(() => {});
    return json({ error: "amount mismatch" }, 500, cors);
  }
  await admin.rpc("attach_checkout_session", { p_order_id: order.id, p_session_id: session.id });
  return json({ checkout_url: session.url, amount: fromMinor(expectedMinor, cur) }, 200, cors);
});
