// supabase functions deploy connect-stripe   (JWT verified by the platform + store.manage checked here)
// Merchant-facing payment management. One charge model per store, never both:
//   onboarding → Stripe Connect Express account (DESTINATION charges on the platform; platform fee applies)
//   save_keys  → merchant's OWN Stripe key stored in Vault (DIRECT charges on their account)
// Actions: status | toggle | onboarding | sync | save_keys | remove_keys
import Stripe from "npm:stripe@14";
import { createClient } from "npm:@supabase/supabase-js@2";
import { adminClient, corsHeaders, json, storeReturnBase } from "../_shared/http.ts";

Deno.serve(async (req) => {
  const admin = adminClient();
  const cors = await corsHeaders(admin, req);
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  if (req.method !== "POST") return json({ error: "method not allowed" }, 405, cors);

  const authHeader = req.headers.get("Authorization") ?? "";
  const { store_id, action, code, enabled, secret_key, webhook_secret } = await req.json().catch(() => ({}));
  if (!store_id || !action) return json({ error: "store_id and action required" }, 400, cors);

  // Authorize with the CALLER's JWT so the same has_store_access() used by RLS decides.
  const userClient = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: authHeader } }, auth: { persistSession: false } });
  const { data: { user } } = await userClient.auth.getUser();
  if (!user) return json({ error: "unauthorized" }, 401, cors);
  const { data: allowed } = await userClient.rpc("has_store_access", { p_store_id: store_id, p_permission: "store.manage" });
  if (allowed !== true) return json({ error: "forbidden" }, 403, cors);

  const { data: provider } = await admin.from("payment_providers")
    .select("id, enabled, status, connected_account_id, secret_ref, webhook_secret_ref")
    .eq("store_id", store_id).eq("code", "stripe").maybeSingle();

  if (action === "status") {
    const { data } = await userClient.rpc("get_payment_provider_status", { p_store_id: store_id, p_code: code ?? "stripe" });
    return json(data ?? {}, 200, cors);
  }

  if (action === "toggle") {
    if (!["cod", "stripe"].includes(code)) return json({ error: "invalid code" }, 400, cors);
    if (code === "stripe" && enabled) {
      // Never "enable" Stripe by flipping a flag: it must be genuinely able to charge.
      const usable = provider && (provider.secret_ref || (provider.connected_account_id && provider.status === "connected"));
      if (!usable) return json({ error: "complete Stripe onboarding or save a valid key first" }, 409, cors);
    }
    const patch: Record<string, unknown> = { enabled: !!enabled };
    if (code === "cod") patch.status = enabled ? "connected" : "disconnected";
    const { error } = await admin.from("payment_providers").update(patch).eq("store_id", store_id).eq("code", code);
    return error ? json({ error: error.message }, 500, cors) : json({ ok: true }, 200, cors);
  }

  if (action === "save_keys") {
    if (provider?.connected_account_id) return json({ error: "this store uses Stripe Connect; disconnect it before using its own key" }, 409, cors);
    if (!/^sk_(test|live)_[A-Za-z0-9]+$/.test(secret_key ?? "")) return json({ error: "key must start with sk_test_ or sk_live_" }, 400, cors);
    if (webhook_secret && !/^whsec_[A-Za-z0-9]+$/.test(webhook_secret)) return json({ error: "invalid webhook secret" }, 400, cors);
    try {                                                                          // verify the key really works before storing it
      await new Stripe(secret_key, { apiVersion: "2024-06-20", httpClient: Stripe.createFetchHttpClient() }).balance.retrieve();
    } catch { return json({ error: "Stripe rejected this key" }, 400, cors); }
    const mode = secret_key.startsWith("sk_live_") ? "live" : "test";
    const stamp = Date.now();
    const { data: ref, error: vErr } = await admin.rpc("store_secret_save", { p_name: `stripe_${store_id}_${mode}_${stamp}`, p_secret: secret_key });
    if (vErr || !ref) return json({ error: "vault write failed" }, 500, cors);
    let whRef: string | null = null;
    if (webhook_secret) {
      const { data: w } = await admin.rpc("store_secret_save", { p_name: `stripe_wh_${store_id}_${stamp}`, p_secret: webhook_secret });
      whRef = (w as string) ?? null;
    }
    const { error } = await admin.from("payment_providers").update({
      secret_ref: ref, webhook_secret_ref: whRef ?? provider?.webhook_secret_ref ?? null, mode, enabled: true, status: "connected",
    }).eq("store_id", store_id).eq("code", "stripe");
    if (error) return json({ error: error.message }, 500, cors);
    for (const old of [provider?.secret_ref, whRef ? provider?.webhook_secret_ref : null]) if (old) await admin.rpc("store_secret_delete", { p_id: old });
    const hook = `${Deno.env.get("SUPABASE_URL")}/functions/v1/stripe-webhook?store=${store_id}`;
    return json({ ok: true, mode, webhook_endpoint: hook,
      note: webhook_secret ? "webhook secret stored" : "add this endpoint in your Stripe dashboard, then save its signing secret" }, 200, cors);
  }

  if (action === "remove_keys") {
    for (const old of [provider?.secret_ref, provider?.webhook_secret_ref]) if (old) await admin.rpc("store_secret_delete", { p_id: old });
    await admin.from("payment_providers").update({ secret_ref: null, webhook_secret_ref: null, enabled: false, status: "disconnected" })
      .eq("store_id", store_id).eq("code", "stripe");
    return json({ ok: true }, 200, cors);
  }

  const platformKey = Deno.env.get("STRIPE_SECRET_KEY") ?? "";
  if (action === "onboarding" || action === "sync") {
    if (!platformKey) return json({ error: "platform Stripe key not configured" }, 503, cors);
    if (provider?.secret_ref) return json({ error: "this store uses its own Stripe key; remove it before using Connect" }, 409, cors);
    const platform = new Stripe(platformKey, { apiVersion: "2024-06-20", httpClient: Stripe.createFetchHttpClient() });

    let accountId = provider?.connected_account_id ?? null;
    if (action === "sync") {
      if (!accountId) return json({ error: "no connected account" }, 409, cors);
      const a = await platform.accounts.retrieve(accountId);
      await admin.rpc("sync_connect_account", { p_account_id: a.id, p_charges_enabled: !!a.charges_enabled,
        p_payouts_enabled: !!a.payouts_enabled, p_details_submitted: !!a.details_submitted });
      return json({ ok: true, charges_enabled: !!a.charges_enabled, payouts_enabled: !!a.payouts_enabled }, 200, cors);
    }
    if (!accountId) {
      const account = await platform.accounts.create({
        type: "express", capabilities: { card_payments: { requested: true }, transfers: { requested: true } },
        metadata: { store_id },
      }, { idempotencyKey: `acct:${store_id}` });
      accountId = account.id;
      const { error } = await admin.from("payment_providers")
        .update({ connected_account_id: accountId, status: "pending", mode: platformKey.startsWith("sk_live_") ? "live" : "test" })
        .eq("store_id", store_id).eq("code", "stripe");
      if (error) return json({ error: error.message }, 500, cors);
    }
    const base = await storeReturnBase(admin, store_id, req.headers.get("Origin"));
    if (!base) return json({ error: "store has no trusted domain for redirects" }, 409, cors);
    const link = await platform.accountLinks.create({
      account: accountId, type: "account_onboarding",
      refresh_url: `${base}/admin/payments?refresh=1`, return_url: `${base}/admin/payments?connected=1`,
    });
    return json({ onboarding_url: link.url }, 200, cors);
  }
  return json({ error: "unknown action" }, 400, cors);
});
