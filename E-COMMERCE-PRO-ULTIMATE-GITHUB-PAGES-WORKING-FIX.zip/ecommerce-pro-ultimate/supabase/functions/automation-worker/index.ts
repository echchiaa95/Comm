// supabase functions deploy automation-worker
// WHEN/IF/THEN rules engine. Hourly: for each enabled rule, find candidate
// subjects since the last run, check conditions, apply actions. Exactly-once
// per (rule, subject) via automation_runs unique key; every outbound action is
// idempotency-keyed.
// Schedule: supabase functions schedule automation-worker --cron '7 * * * *'
import { createClient } from "npm:@supabase/supabase-js@2";
import { requireCron } from "../_shared/http.ts";

Deno.serve(async (req) => {
  const denied = requireCron(req); if (denied) return denied;
  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  const { data: rules } = await admin.from("automation_rules").select("*").eq("enabled", true).limit(200);
  const stats = { rules: rules?.length ?? 0, fired: 0, errors: 0 };

  for (const rule of rules ?? []) {
    const since = rule.last_run_at ?? new Date(Date.now() - 65 * 60 * 1000).toISOString();
    const cond = rule.conditions ?? {};
    let subjects: { id: string; order?: any; customer?: any; product?: any }[] = [];

    try {
      if (rule.trigger_key === "new_order" || rule.trigger_key === "payment_confirmed" || rule.trigger_key === "order_delivered") {
        let q = admin.from("orders").select("id, total, customer_id, customer_snapshot, store_id").eq("store_id", rule.store_id).gt("created_at", since);
        if (rule.trigger_key === "payment_confirmed") q = q.eq("payment_status", "paid").gt("confirmed_at", since);
        if (rule.trigger_key === "order_delivered") q = q.eq("status", "delivered").gt("delivered_at", since);
        const { data: orders } = await q;
        for (const o of orders ?? []) {
          if (cond.min_total != null && Number(o.total) < Number(cond.min_total)) continue;
          if (cond.has_digital === true || cond.has_digital === false) {
            const { data: items } = await admin.from("order_items").select("is_digital").eq("order_id", o.id);
            const hasDigital = (items ?? []).some((i: any) => i.is_digital);
            if (Boolean(cond.has_digital) !== hasDigital) continue;
          }
          subjects.push({ id: o.id, order: o });
        }
      } else if (rule.trigger_key === "customer_inactive") {
        const days = Number(cond.days ?? 30);
        const { data: customers } = await admin.from("customers").select("id, email, first_name, store_id")
          .eq("store_id", rule.store_id).not("last_order_at", "is", null)
          .lt("last_order_at", new Date(Date.now() - days * 86400_000).toISOString())
          .gt("last_order_at", new Date(Date.now() - (days + 1) * 86400_000).toISOString());
        subjects = (customers ?? []).map((c: any) => ({ id: `inactive:${c.id}`, customer: c }));
      } else if (rule.trigger_key === "low_stock") {
        const { data: products } = await admin.from("products").select("id, name, inventory_qty, low_stock_threshold")
          .eq("store_id", rule.store_id).eq("track_inventory", true);
        subjects = (products ?? [])
          .filter((p: any) => Number(p.inventory_qty) <= Number(p.low_stock_threshold))
          .map((p: any) => ({ id: `stock:${p.id}`, product: p }));
      }

      for (const subject of subjects) {
        const { error: runErr } = await admin.from("automation_runs").insert({
          store_id: rule.store_id, rule_id: rule.id, subject_id: subject.id,
        });
        if (runErr) continue; // already processed (23505) or invalid

        for (const action of rule.actions ?? []) {
          const idem = `rule:${rule.id}:${subject.id}:${action.type}`;
          if (action.type === "send_email" && (subject.order || subject.customer)) {
            const { data: tpl } = await admin.from("email_templates").select("id")
              .eq("store_id", rule.store_id).eq("key", action.template_key ?? "order_confirmation").maybeSingle();
            const to = action.to === "admin"
              ? (await admin.from("stores").select("contact_email").eq("id", rule.store_id).single()).data?.contact_email
              : subject.order?.customer_snapshot?.email ?? subject.customer?.email;
            if (to && tpl) {
              await admin.from("email_jobs").insert({
                store_id: rule.store_id, template_id: tpl.id, to_email: to,
                payload: { type: action.template_key, order_id: subject.order?.id, first_name: subject.order?.customer_snapshot?.first_name ?? subject.customer?.first_name },
                idempotency_key: idem, scheduled_at: new Date().toISOString(),
              }).then((r) => r.error && r.error.code !== "23505" && stats.errors++);
            }
          } else if (action.type === "generate_coupon") {
            const code = (action.code_prefix ?? "AUTO") + "-" + Math.random().toString(36).slice(2, 8).toUpperCase();
            await admin.from("coupons").insert({
              store_id: rule.store_id, code, kind: action.kind ?? "percent",
              value: Number(action.value ?? 10), first_order_only: false, stackable: false,
              expires_at: new Date(Date.now() + Number(action.expires_days ?? 7) * 86400_000).toISOString(),
            }).then((r) => r.error && r.error.code !== "23505" && stats.errors++);
          } else if (action.type === "add_loyalty_points" && subject.order?.customer_id) {
            const cid = subject.order.customer_id;
            await admin.from("loyalty_accounts").upsert({ store_id: rule.store_id, customer_id: cid }, { onConflict: "store_id,customer_id" });
            const { data: acc } = await admin.from("loyalty_accounts").select("id").eq("store_id", rule.store_id).eq("customer_id", cid).single();
            if (acc) {
              await admin.from("loyalty_transactions").insert({
                store_id: rule.store_id, account_id: acc.id,
                delta: Number(action.points ?? 0), reason: "adjustment", order_id: subject.order.id,
              });
              await admin.rpc("recalc_loyalty", { p_account_id: acc.id }).catch(() => {});
            }
          } else if (action.type === "notify_admin") {
            const { data: st } = await admin.from("stores").select("contact_email, default_locale").eq("id", rule.store_id).single();
            if (st?.contact_email) {
              await admin.from("email_jobs").insert({
                store_id: rule.store_id, to_email: st.contact_email,
                payload: { type: "admin_notification", subject: action.subject ?? rule.name, body: `Rule "${rule.name}" fired for ${subject.id}` },
                idempotency_key: idem, scheduled_at: new Date().toISOString(),
              }).then((r) => r.error && r.error.code !== "23505" && stats.errors++);
            }
          }
        }
        stats.fired++;
      }
      await admin.from("automation_rules").update({ last_run_at: new Date().toISOString() }).eq("id", rule.id);
    } catch {
      stats.errors++;
    }
  }
  return Response.json(stats);
});
