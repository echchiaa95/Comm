// supabase functions deploy verify-domain
// Custom-domain lifecycle with OWNERSHIP proof:
//   add     → registers the domain for THIS store only (never re-assigns a domain owned by another store)
//             and returns a TXT token + the CNAME routing target
//   check   → verified only when TXT _ecommerce-verify.<domain> equals the store's token
//   primary → only for already-verified domains
import { createClient } from "npm:@supabase/supabase-js@2";
import { adminClient, corsHeaders, json } from "../_shared/http.ts";

async function lookup(name: string, type: string): Promise<string[]> {
  try {
    const res = await fetch(`https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(name)}&type=${type}`, { headers: { accept: "application/dns-json" } });
    const j = await res.json();
    return (j.Answer ?? []).map((a: { data: string }) => String(a.data).replace(/^"|"$/g, "").replace(/\.$/, ""));
  } catch { return []; }
}

Deno.serve(async (req) => {
  const admin = adminClient();
  const cors = await corsHeaders(admin, req);
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  if (req.method !== "POST") return json({ error: "method not allowed" }, 405, cors);

  const { store_id, action } = await req.json().then((b) => { (req as any)._b = b; return b; }).catch(() => ({}));
  const domain = String((req as any)._b?.domain ?? "").toLowerCase().trim();
  if (!store_id || !action || !domain) return json({ error: "store_id, action, domain required" }, 400, cors);
  if (!/^(?!-)[a-z0-9-]{1,63}(?<!-)(\.[a-z0-9-]{1,63})+$/.test(domain) || domain.length > 253) return json({ error: "invalid domain" }, 400, cors);
  const platformDomain = (Deno.env.get("PLATFORM_DOMAIN") ?? "").toLowerCase();
  if (platformDomain && (domain === platformDomain || domain.endsWith("." + platformDomain))) return json({ error: "platform domains are managed automatically" }, 400, cors);

  const userClient = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } }, auth: { persistSession: false } });
  const { data: { user } } = await userClient.auth.getUser();
  if (!user) return json({ error: "unauthorized" }, 401, cors);
  const { data: allowed } = await userClient.rpc("has_store_access", { p_store_id: store_id, p_permission: "store.manage" });
  if (allowed !== true) return json({ error: "forbidden" }, 403, cors);

  const platformHost = Deno.env.get("PLATFORM_HOST") ?? "";
  const { data: row } = await admin.from("store_domains").select("store_id, verified, verification_token, is_primary").eq("domain", domain).maybeSingle();
  if (row && row.store_id !== store_id) return json({ error: "domain already registered by another store" }, 409, cors);

  if (action === "add") {
    let token = row?.verification_token;
    if (!row) {
      const { data, error } = await admin.from("store_domains").insert({ store_id, domain }).select("verification_token").single();
      if (error) return json({ error: "could not register domain" }, 500, cors);
      token = data.verification_token;
    }
    return json({ ok: true, instructions: [
      { type: "TXT", host: `_ecommerce-verify.${domain}`, value: token, note: "proves you own the domain" },
      ...(platformHost ? [{ type: "CNAME", host: domain, value: platformHost, note: "routes traffic to the platform" }] : []),
    ] }, 200, cors);
  }
  if (!row) return json({ error: "domain not registered" }, 404, cors);

  if (action === "check") {
    const txt = await lookup(`_ecommerce-verify.${domain}`, "TXT");
    const verified = txt.includes(row.verification_token);
    if (verified && !row.verified) await admin.from("store_domains").update({ verified: true }).eq("domain", domain).eq("store_id", store_id);
    const cname = platformHost ? (await lookup(domain, "CNAME")).includes(platformHost.replace(/\.$/, "")) : null;
    return json({ verified, routing_ok: cname }, 200, cors);
  }
  if (action === "primary") {
    if (!row.verified) return json({ error: "verify the domain first" }, 409, cors);
    await admin.from("store_domains").update({ is_primary: false }).eq("store_id", store_id);
    const { error } = await admin.from("store_domains").update({ is_primary: true }).eq("domain", domain).eq("store_id", store_id);
    return error ? json({ error: "update failed" }, 500, cors) : json({ ok: true }, 200, cors);
  }
  return json({ error: "unknown action" }, 400, cors);
});
