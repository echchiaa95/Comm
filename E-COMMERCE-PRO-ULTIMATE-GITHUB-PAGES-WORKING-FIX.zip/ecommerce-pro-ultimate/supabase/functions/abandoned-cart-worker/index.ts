// supabase functions deploy abandoned-cart-worker
// Recovery workflow engine. Every 15 minutes: for each store, find abandoned carts
// due for their next configured step (default: 30min → 12h → 24h w/ coupon → 48h)
// and queue email_jobs. CONSENT-GATED: skips anyone without marketing_consents
// opt-in for email. Frequency-limited by step design; idempotent per (cart, step).
// Schedule: supabase functions schedule abandoned-cart-worker --cron '*/15 * * * *'
import { createClient } from "npm:@supabase/supabase-js@2";
import { requireCron } from "../_shared/http.ts";

Deno.serve(async (req) => {
  const denied = requireCron(req); if (denied) return denied;
  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  const { data: carts } = await admin.from("abandoned_carts")
    .select("id, store_id, email, items, cart_total, step, last_sent_at, created_at")
    .eq("recovered", false).eq("opted_out", false)
    .or("last_sent_at.is.null,last_sent_at.lte." + new Date(Date.now() - 55 * 60 * 1000).toISOString())
    .limit(200);

  const queued: number[] = [];
  for (const cart of carts ?? []) {
    // Consent is looked up per email — no FK exists between the tables.
    const { data: consent } = await admin.from("marketing_consents")
      .select("status").eq("store_id", cart.store_id)
      .eq("email", cart.email).eq("channel", "email").maybeSingle();
    if (consent?.status !== "opted_in") continue; // never send unsolicited marketing

    const { data: setting } = await admin.from("store_settings")
      .select("value").eq("store_id", cart.store_id).eq("key", "abandoned_cart").maybeSingle();
    const steps = (setting?.value as { steps?: { delay_minutes: number; with_coupon?: boolean; final?: boolean }[] } | null)
      ?.steps ?? [{ delay_minutes: 30 }, { delay_minutes: 720 }, { delay_minutes: 1440, with_coupon: true }, { delay_minutes: 2880, final: true }];

    const next = steps[cart.step];
    if (!next) continue;                                             // workflow finished
    const dueAt = cart.last_sent_at
      ? new Date(new Date(cart.last_sent_at).getTime() + next.delay_minutes * 60 * 1000)
      : new Date(new Date(cart.created_at).getTime() + steps[0].delay_minutes * 60 * 1000);
    if (dueAt > new Date()) continue;

    const idem = `ab:${cart.id}:${cart.step}`;
    const { error } = await admin.from("email_jobs").insert({
      store_id: cart.store_id, to_email: cart.email,
      payload: {
        type: "abandoned_cart", abandoned_cart_id: cart.id, items: cart.items, total: cart.cart_total,
        step: cart.step, with_coupon: next.with_coupon ?? false,
      },
      idempotency_key: idem,
      scheduled_at: new Date().toISOString(),
    });
    if (error && error.code !== "23505") continue;                   // 23505 = duplicate, skip silently

    await admin.from("abandoned_carts").update({ step: cart.step + 1, last_sent_at: new Date().toISOString() }).eq("id", cart.id);
    queued.push(cart.id);
  }
  return Response.json({ processed: carts?.length ?? 0, queued: queued.length });
});
