// supabase functions deploy unsubscribe --no-verify-jwt   (opened from an email; authenticity = HMAC token)
// GET  → confirmation page with a button (prevents mail scanners from unsubscribing people by prefetching)
// POST → performs the opt-out (also the RFC 8058 one-click endpoint used by mail clients)
import { adminClient, escapeHtml, verifyUnsubscribe } from "../_shared/http.ts";

const page = (msg: string, form?: string) => new Response(
  `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Unsubscribe</title></head>` +
  `<body style="font-family:Inter,Arial,sans-serif;max-width:480px;margin:15vh auto;text-align:center;color:#0f172a"><p>${escapeHtml(msg)}</p>${form ?? ""}</body></html>`,
  { headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" } });

Deno.serve(async (req) => {
  const t = new URL(req.url).searchParams.get("t") ?? "";
  const parsed = await verifyUnsubscribe(t).catch(() => null);
  if (!parsed) return page("This unsubscribe link is invalid or has expired.");
  const [storeId, email, channel] = parsed;
  if (req.method === "GET") {
    return page(`Stop marketing emails to ${email}?`,
      `<form method="post"><button style="background:#4f46e5;color:#fff;border:0;border-radius:8px;padding:10px 22px;font-weight:600;cursor:pointer">Unsubscribe</button></form>`);
  }
  if (req.method !== "POST") return new Response("method not allowed", { status: 405 });
  const admin = adminClient();
  await admin.from("marketing_consents").upsert(
    { store_id: storeId, email, channel, status: "opted_out", source: "unsubscribe_link", updated_at: new Date().toISOString() },
    { onConflict: "store_id,email,channel" });
  if (channel === "email") {
    await admin.from("newsletter_subscribers").update({ status: "unsubscribed" }).eq("store_id", storeId).eq("email", email);
    await admin.from("abandoned_carts").update({ opted_out: true }).eq("store_id", storeId).eq("email", email);
    await admin.from("email_jobs").update({ status: "failed", last_error: "unsubscribed" })
      .eq("store_id", storeId).eq("to_email", email).eq("status", "queued")
      .in("payload->>type", ["abandoned_cart", "promotional", "win_back", "reactivation"]);
  }
  return page("You have been unsubscribed. You will still receive essential order emails.");
});
