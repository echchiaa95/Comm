// Shared helpers for Edge Functions: CORS allow-list, JSON responses, safe redirect bases.
// Origins are trusted only if they are (a) listed in ALLOWED_ORIGINS, (b) a VERIFIED custom domain of a
// registered store, or (c) a sub-domain of PLATFORM_DOMAIN. Anything else gets no CORS headers
// and can never be used as a redirect target (prevents open redirects).
import { createClient, type SupabaseClient } from "npm:@supabase/supabase-js@2";

export function adminClient(): SupabaseClient {
  return createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
    auth: { persistSession: false },
  });
}

const csv = (v?: string) => (v ?? "").split(",").map((s) => s.trim()).filter(Boolean);

function hostOf(origin: string): string | null {
  try { return new URL(origin).host.toLowerCase(); } catch { return null; }
}

export async function isTrustedOrigin(admin: SupabaseClient, origin: string | null, storeId?: string): Promise<boolean> {
  if (!origin) return false;
  if (csv(Deno.env.get("ALLOWED_ORIGINS")).includes(origin)) return true;
  const host = hostOf(origin);
  if (!host) return false;
  const platform = (Deno.env.get("PLATFORM_DOMAIN") ?? "").toLowerCase();
  if (platform && host.endsWith("." + platform) && new URL(origin).protocol === "https:") {
    if (!storeId) return true;
    const slug = host.slice(0, -(platform.length + 1));
    const { data } = await admin.from("stores").select("id").eq("id", storeId).eq("slug", slug).maybeSingle();
    return !!data;
  }
  let q = admin.from("store_domains").select("store_id").eq("domain", host).eq("verified", true);
  if (storeId) q = q.eq("store_id", storeId);
  const { data } = await q.maybeSingle();
  return !!data;
}

export async function corsHeaders(admin: SupabaseClient, req: Request): Promise<Record<string, string>> {
  const origin = req.headers.get("Origin");
  const base: Record<string, string> = { Vary: "Origin" };
  if (origin && await isTrustedOrigin(admin, origin)) {
    base["Access-Control-Allow-Origin"] = origin;
    base["Access-Control-Allow-Headers"] = "authorization, x-client-info, apikey, content-type";
    base["Access-Control-Allow-Methods"] = "POST, GET, OPTIONS";
    base["Access-Control-Max-Age"] = "600";
  }
  return base;
}

export function json(body: unknown, status: number, headers: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(body), {
    status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store", ...headers },
  });
}

/** Customer-facing base URL for a store, validated. Never the Supabase function domain. */
export async function storeReturnBase(admin: SupabaseClient, storeId: string, requested?: string | null): Promise<string | null> {
  if (requested && await isTrustedOrigin(admin, requested, storeId)) return new URL(requested).origin;
  const { data: dom } = await admin.from("store_domains").select("domain")
    .eq("store_id", storeId).eq("verified", true).order("is_primary", { ascending: false }).limit(1).maybeSingle();
  if (dom?.domain) return `https://${dom.domain}`;
  const platform = Deno.env.get("PLATFORM_DOMAIN");
  if (platform) {
    const { data: s } = await admin.from("stores").select("slug").eq("id", storeId).maybeSingle();
    if (s?.slug) return `https://${s.slug}.${platform}`;
  }
  const fallback = csv(Deno.env.get("ALLOWED_ORIGINS"))[0];
  return fallback ?? null;
}

const ZERO_DECIMAL = new Set(["bif","clp","djf","gnf","jpy","kmf","krw","mga","pyg","rwf","ugx","vnd","vuv","xaf","xof","xpf"]);
export function toMinor(amount: number, currency: string): number {
  return ZERO_DECIMAL.has(currency.toLowerCase()) ? Math.round(amount) : Math.round(amount * 100);
}
export function fromMinor(amount: number, currency: string): number {
  return ZERO_DECIMAL.has(currency.toLowerCase()) ? amount : amount / 100;
}
export const localized = (v: unknown, locale = "en"): string =>
  typeof v === "string" ? v : (v as Record<string, string>)?.[locale] ?? (v as Record<string, string>)?.en ?? "Item";

/** Scheduled workers (cron) must present the shared secret; the Supabase anon key alone is NOT enough. */
export function requireCron(req: Request): Response | null {
  const secret = Deno.env.get("CRON_SECRET");
  if (!secret) return json({ error: "CRON_SECRET not configured" }, 503);
  const given = req.headers.get("x-cron-secret") ?? "";
  if (given.length !== secret.length) return json({ error: "unauthorized" }, 401);
  let diff = 0; for (let i = 0; i < secret.length; i++) diff |= secret.charCodeAt(i) ^ given.charCodeAt(i);
  return diff === 0 ? null : json({ error: "unauthorized" }, 401);
}

export const escapeHtml = (s: unknown): string =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));

// HMAC-signed unsubscribe tokens (store|email|channel) — no database lookup needed to trust them.
const b64u = (b: ArrayBuffer | Uint8Array) => btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
async function hmac(data: string): Promise<string> {
  const secret = Deno.env.get("UNSUBSCRIBE_SECRET") ?? "";
  if (!secret) throw new Error("UNSUBSCRIBE_SECRET not configured");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return b64u(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(data)));
}
export async function signUnsubscribe(storeId: string, email: string, channel = "email"): Promise<string> {
  const payload = b64u(new TextEncoder().encode(JSON.stringify([storeId, email.toLowerCase(), channel])));
  return `${payload}.${await hmac(payload)}`;
}
export async function verifyUnsubscribe(token: string): Promise<[string, string, string] | null> {
  const [payload, sig] = token.split(".");
  if (!payload || !sig || sig !== await hmac(payload)) return null;
  try {
    const raw = atob(payload.replace(/-/g, "+").replace(/_/g, "/"));
    const arr = JSON.parse(new TextDecoder().decode(Uint8Array.from(raw, (c) => c.charCodeAt(0))));
    return Array.isArray(arr) && arr.length === 3 ? arr as [string, string, string] : null;
  } catch { return null; }
}
