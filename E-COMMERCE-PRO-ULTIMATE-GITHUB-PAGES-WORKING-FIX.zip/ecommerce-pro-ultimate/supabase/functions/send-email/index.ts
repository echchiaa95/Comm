// supabase functions deploy send-email        (schedule every minute; requires header x-cron-secret)
// Outbox worker for email_jobs (queued + due) → Resend. Guarantees:
//   • exactly-once claim (queued → sending is an atomic conditional update; overlapping runs cannot double-send)
//   • TRANSACTIONAL mail (order/delivery) is separated from MARKETING mail (abandoned cart, promotions…)
//   • marketing is re-checked against marketing_consents at SEND time and carries a working unsubscribe link
//     + RFC 8058 List-Unsubscribe headers; carts that were recovered/opted-out are never mailed
//   • provider failures retry with back-off (3 attempts) and are recorded; no provider key = jobs fail visibly
import { adminClient, escapeHtml, json, localized, requireCron, signUnsubscribe, storeReturnBase } from "../_shared/http.ts";

const FROM = Deno.env.get("MAIL_FROM") ?? "Shop <no-reply@example.com>";
const MARKETING = new Set(["abandoned_cart", "promotional", "win_back", "reactivation", "welcome", "review_request", "new_product", "birthday", "back_in_stock"]);

const render = (text: string | undefined, vars: Record<string, string>) =>
  Object.entries(vars).reduce((s, [k, v]) => s.replaceAll(`{{${k}}}`, escapeHtml(v)), text ?? "");
type Block = { type: string; text?: string; url?: string; level?: number };

function blocksToHtml(blocks: Block[] | undefined, vars: Record<string, string>, raw: Record<string, string>): string {
  if (!blocks) return `<p>${render(vars.body ?? "", vars)}</p>`;
  return blocks.map((b) => {
    if (b.type === "heading") { const tag = `h${Math.min(3, Math.max(1, b.level ?? 2))}`; return `<${tag} style="margin:0 0 12px">${render(b.text, vars)}</${tag}>`; }
    if (b.type === "button") return `<p><a href="${escapeHtml(b.url?.replace(/\{\{(\w+)\}\}/g, (_m, k) => raw[k] ?? "") ?? "#")}" style="background:#4f46e5;color:#fff;padding:10px 22px;border-radius:8px;text-decoration:none;font-weight:600">${render(b.text, vars)}</a></p>`;
    if (b.type === "order_summary") return `<div>${raw.order_summary ?? ""}</div>`;
    if (b.type === "cart_items") return `<p>${raw.cart_items ?? ""}</p>`;
    if (b.type === "download_links") return `<p>${raw.download_links ?? ""}</p>`;
    return `<p style="margin:0 0 10px;line-height:1.6">${render(b.text, vars)}</p>`;
  }).join("");
}

Deno.serve(async (req) => {
  const denied = requireCron(req); if (denied) return denied;
  const admin = adminClient();
  const supaUrl = Deno.env.get("SUPABASE_URL")!;
  const key = Deno.env.get("RESEND_API_KEY");

  // Recover jobs whose worker died mid-send.
  await admin.from("email_jobs").update({ status: "queued" })
    .eq("status", "sending").lt("claimed_at", new Date(Date.now() - 10 * 60_000).toISOString());

  const { data: due } = await admin.from("email_jobs").select("id")
    .eq("status", "queued").lte("scheduled_at", new Date().toISOString()).order("scheduled_at").limit(50);
  const results = { sent: 0, failed: 0, skipped: 0 };

  for (const { id } of due ?? []) {
    const { data: claimed } = await admin.from("email_jobs")
      .update({ status: "sending", claimed_at: new Date().toISOString() }).eq("id", id).eq("status", "queued").select("*").maybeSingle();
    if (!claimed) { results.skipped++; continue; }                               // another worker took it
    const job = claimed;
    const fail = async (msg: string, final = true) => {
      await admin.from("email_jobs").update({ status: final ? "failed" : "queued", attempts: job.attempts + 1, last_error: msg,
        ...(final ? {} : { scheduled_at: new Date(Date.now() + 10 * 60_000).toISOString() }) }).eq("id", job.id);
      results.failed++;
    };
    const p = job.payload ?? {};
    const type: string = p.type ?? "generic";
    const marketing = MARKETING.has(type);

    if (marketing) {
      const { data: consent } = await admin.from("marketing_consents").select("status")
        .eq("store_id", job.store_id).eq("email", job.to_email).eq("channel", "email").maybeSingle();
      if (consent?.status !== "opted_in") { await fail("no_marketing_consent"); continue; }
      if (type === "abandoned_cart" && p.abandoned_cart_id) {
        const { data: ac } = await admin.from("abandoned_carts").select("recovered, opted_out").eq("id", p.abandoned_cart_id).maybeSingle();
        if (!ac || ac.recovered || ac.opted_out) { await fail("cart_recovered_or_opted_out"); continue; }
      }
    }
    if (!key) { await fail("RESEND_API_KEY not configured"); continue; }

    const base = await storeReturnBase(admin, job.store_id, null) ?? supaUrl;
    const { data: store } = await admin.from("stores").select("name, default_locale").eq("id", job.store_id).single();
    const locale: string = p.locale ?? store?.default_locale ?? "en";
    let tpl: { subject?: Record<string, string>; body?: Record<string, Block[]> } | null = null;
    if (job.template_id) tpl = (await admin.from("email_templates").select("subject, body").eq("id", job.template_id).maybeSingle()).data;
    if (!tpl) tpl = (await admin.from("email_templates").select("subject, body").eq("store_id", job.store_id).eq("key", type).eq("is_active", true).maybeSingle()).data;

    const vars: Record<string, string> = {
      order_number: p.order_number ?? "", total: p.total != null ? String(p.total) : "", first_name: p.first_name ?? "",
      store_name: store?.name ?? "", cart_url: p.abandoned_cart_id ? `${base}/cart?restore=${p.abandoned_cart_id}` : `${base}/cart`,
      order_url: `${base}/order/${p.order_id ?? ""}/success`, download_url: `${base}/downloads`, body: p.body ?? "",
    };
    const raw: Record<string, string> = { ...vars };
    if (p.order_id) {
      const { data: o } = await admin.from("orders").select("order_number, total, currency").eq("id", p.order_id).maybeSingle();
      const { data: its } = await admin.from("order_items").select("name, qty, total").eq("order_id", p.order_id);
      if (o) { vars.order_number = o.order_number; vars.total = `${o.total} ${o.currency}`;
        raw.order_summary = `<table style="width:100%;border-collapse:collapse">${(its ?? []).map((i) =>
          `<tr><td>${escapeHtml(localized(i.name, locale))} × ${i.qty}</td><td style="text-align:end">${i.total}</td></tr>`).join("")}` +
          `<tr><td><b>Total</b></td><td style="text-align:end"><b>${escapeHtml(vars.total)}</b></td></tr></table>`; }
    }
    if (type === "digital_delivery" && p.order_id) {
      const { data: dls } = await admin.rpc("customer_downloads_by_order", { p_order_id: p.order_id });   // paid orders only
      raw.download_links = (dls ?? []).map((d: { token: string; file_name: string }) =>
        `<a href="${supaUrl}/functions/v1/deliver-download?token=${encodeURIComponent(d.token)}">${escapeHtml(d.file_name)}</a>`).join("<br>");
    }
    if (type === "abandoned_cart" && Array.isArray(p.items)) {
      raw.cart_items = "";                                                      // line names are resolved from product ids
      const ids = p.items.map((i: { product_id: string }) => i.product_id);
      const { data: prods } = await admin.from("products").select("id, name").in("id", ids).eq("store_id", job.store_id);
      raw.cart_items = p.items.map((i: { product_id: string; qty: number }) =>
        `${escapeHtml(localized(prods?.find((x) => x.id === i.product_id)?.name, locale))} × ${i.qty}`).join("<br>");
    }

    const subject = (tpl?.subject?.[locale] ?? tpl?.subject?.en ?? "Update from your store").replaceAll(/\{\{(\w+)\}\}/g, (_m, k) => vars[k] ?? "");
    let footer = `<p style="font-size:12px;color:#94a3b8">You received this email because of an action on ${escapeHtml(store?.name ?? "our store")}.</p>`;
    const headers: Record<string, string> = {};
    if (marketing) {
      const link = `${supaUrl}/functions/v1/unsubscribe?t=${await signUnsubscribe(job.store_id, job.to_email)}`;
      footer = `<p style="font-size:12px;color:#94a3b8">You are receiving marketing emails from ${escapeHtml(store?.name ?? "our store")}. <a href="${link}">Unsubscribe</a></p>`;
      headers["List-Unsubscribe"] = `<${link}>`; headers["List-Unsubscribe-Post"] = "List-Unsubscribe=One-Click";
    }
    const html = `<!doctype html><html lang="${locale}" dir="${locale === "ar" ? "rtl" : "ltr"}"><body style="font-family:Inter,Cairo,Arial,sans-serif;max-width:560px;margin:24px auto;color:#0f172a">` +
      `${blocksToHtml(tpl?.body?.[locale] ?? tpl?.body?.en, vars, raw)}<hr style="border:none;border-top:1px solid #e2e8f0;margin:24px 0">${footer}</body></html>`;

    let res: Response;
    try {
      res = await fetch("https://api.resend.com/emails", { method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}`, "Idempotency-Key": job.idempotency_key ?? job.id },
        body: JSON.stringify({ from: FROM, to: [job.to_email], subject, html, headers }) });
    } catch (e) { await fail(`provider unreachable: ${(e as Error).message}`, job.attempts + 1 >= 3); continue; }
    if (res.ok) {
      const out = await res.json().catch(() => ({}));
      await admin.from("email_jobs").update({ status: "sent", attempts: job.attempts + 1, sent_at: new Date().toISOString(), last_error: null }).eq("id", job.id);
      await admin.from("notification_logs").insert({ store_id: job.store_id, channel: "email", recipient: job.to_email, subject, provider_message_id: out.id ?? null, status: "sent" });
      results.sent++;
    } else {
      await fail(`provider ${res.status}: ${(await res.text()).slice(0, 200)}`, job.attempts + 1 >= 3 || (res.status >= 400 && res.status < 500 && res.status !== 429));
    }
  }
  return json(results, 200);
});
