// supabase functions deploy create-store
// Installation wizard backend: validates input, creates the store for the AUTHENTICATED user.
// The DB trigger (handle_new_store) auto-configures workflows for the chosen business model.
import { createClient } from "npm:@supabase/supabase-js@2";
import { z } from "npm:zod@3";
import { adminClient, corsHeaders, json } from "../_shared/http.ts";

const RESERVED = new Set(["www", "admin", "api", "app", "mail", "functions", "static", "assets", "support", "login", "auth"]);
const WizardSchema = z.object({
  name: z.string().min(2).max(120),
  slug: z.string().regex(/^[a-z0-9][a-z0-9-]{1,59}$/).refine((s) => !RESERVED.has(s), "reserved"),
  business_model: z.enum(["physical", "digital", "hybrid"]).default("physical"),
  country: z.string().length(2).optional(),
  city: z.string().max(80).optional(),
  currency: z.string().length(3).transform((s) => s.toUpperCase()).default("USD"),
  timezone: z.string().max(60).default("UTC"),
  default_locale: z.enum(["en", "fr", "ar"]).default("en"),
  contact_email: z.string().email().optional(),
  whatsapp_number: z.string().max(30).optional(),
  category: z.string().max(60).optional(),
});

Deno.serve(async (req) => {
  const admin = adminClient();
  const cors = await corsHeaders(admin, req);
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  if (req.method !== "POST") return json({ error: "method not allowed" }, 405, cors);

  const anon = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } }, auth: { persistSession: false } });
  const { data: { user }, error: authError } = await anon.auth.getUser();
  if (authError || !user) return json({ error: "unauthorized" }, 401, cors);

  const parsed = WizardSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return json({ error: parsed.error.flatten() }, 400, cors);

  // Soft abuse limit: a user may create at most 5 stores.
  const { count } = await admin.from("stores").select("id", { count: "exact", head: true }).eq("created_by", user.id);
  if ((count ?? 0) >= 5) return json({ error: "store limit reached" }, 429, cors);

  const { data: taken } = await admin.from("stores").select("id").eq("slug", parsed.data.slug).maybeSingle();
  if (taken) return json({ error: { slug: ["already_taken"] } }, 409, cors);

  const { currency, ...rest } = parsed.data;
  const { data: store, error } = await admin.from("stores").insert({
    ...rest, default_currency: currency, created_by: user.id,       // created_by always comes from the JWT, never the body
  }).select("id, slug, name, business_model, default_locale, default_currency").single();
  if (error) return json({ error: error.message.includes("duplicate") ? { slug: ["already_taken"] } : "could not create store" }, error.message.includes("duplicate") ? 409 : 500, cors);
  return json({ store }, 201, cors);
});
