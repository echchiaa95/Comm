-- ============================================================================
-- checkout.test.sql — commerce engine (pgTAP). Run: supabase test db
-- STATUS: written for V1.1, NOT executed in the repair sandbox (no Postgres there) — see TESTING.md.
-- Covers: server-side pricing, idempotency, coupons, stock, COD (confirm ≠ paid ≠ collected),
-- digital-only COD rejection, delivery only after payment, cancel restock, Stripe amount check.
-- ============================================================================
begin;
select plan(26);

select tests.create_supabase_user('merchant', 'merchant@test.dev', null);
insert into public.stores (name, slug, business_model, created_by, default_currency, country, city)
values ('Test Shop', 'test-shop-checkout', 'hybrid', tests.get_supabase_uid('merchant'), 'USD', 'US', 'NYC') returning id \gset
select :'id' as sid \gset

insert into public.products (store_id, status, slug, name, price, currency, type, track_inventory, inventory_qty)
values (:'sid', 'active', 'mug', '{"en":"Mug"}', 20, 'USD', 'physical', true, 3) returning id \gset
select :'id' as p_mug \gset
insert into public.products (store_id, status, slug, name, price, currency, type, track_inventory)
values (:'sid', 'active', 'ebook', '{"en":"E-book"}', 10, 'USD', 'digital', false) returning id \gset
select :'id' as p_ebook \gset
insert into public.product_files (product_id, store_id, storage_path, file_name, mime_type)
values (:'p_ebook', :'sid', 'tests/ebook.pdf', 'ebook.pdf', 'application/pdf');
insert into public.shipping_zones (store_id, name, countries) values (:'sid', 'US', '["US"]') returning id \gset
select :'id' as zone \gset
insert into public.shipping_methods (store_id, zone_id, name, type, base_price)
values (:'sid', :'zone', '{"en":"Flat"}', 'flat', 5) returning id \gset
select :'id' as ship \gset
insert into public.coupons (store_id, code, kind, value) values (:'sid', 'SAVE10', 'percent', 10);
-- Stripe usable for this store (connected account that can charge)
update public.payment_providers set enabled = true, status = 'connected', connected_account_id = 'acct_test', charges_enabled = true
 where store_id = :'sid' and code = 'stripe';

-- 1. server-side totals (client sends no prices at all)
select (public.place_order(jsonb_build_object('store_id', :'sid', 'idempotency_key', 'test-1',
  'items', jsonb_build_array(jsonb_build_object('product_id', :'p_mug', 'qty', 2), jsonb_build_object('product_id', :'p_ebook', 'qty', 1)),
  'payment_method', 'cod', 'customer', jsonb_build_object('first_name','T','last_name','T','email','t@t.dev'),
  'shipping_address', jsonb_build_object('country','US','city','NYC','address1','1 St'),
  'shipping_method_id', :'ship')) ->> 'total')::numeric as total_1 \gset
select ok(abs(:total_1 - 55.0) < 0.001, 'total = 2×20 + 10 + 5 shipping');

-- 2/3. idempotent retry
select (public.place_order(jsonb_build_object('store_id', :'sid', 'idempotency_key', 'test-1',
  'items', jsonb_build_array(jsonb_build_object('product_id', :'p_mug', 'qty', 2)), 'payment_method', 'cod',
  'customer', jsonb_build_object('email','t@t.dev'), 'shipping_address', jsonb_build_object('country','US','city','NYC','address1','1 St'),
  'shipping_method_id', :'ship')) ->> 'duplicate') as dup \gset
select is(:'dup', 'true', 'same idempotency key marks duplicate');
select is((select count(*) from public.orders where store_id = :'sid' and idempotency_key = 'test-1'), 1::bigint, 'exactly one order');

-- 4/5. stock decremented once (untracked ebook did NOT raise), movement logged
select is((select inventory_qty from public.products where id = :'p_mug'), 1, 'stock 3 → 1');
select ok(exists(select 1 from public.inventory_movements where product_id = :'p_mug' and delta = -2), 'movement recorded');

-- 6/7. coupon
select (public.place_order(jsonb_build_object('store_id', :'sid', 'idempotency_key', 'test-2', 'coupon_code', 'SAVE10',
  'items', jsonb_build_array(jsonb_build_object('product_id', :'p_mug', 'qty', 1)), 'payment_method', 'cod',
  'customer', jsonb_build_object('email','t2@t.dev'), 'shipping_address', jsonb_build_object('country','US','city','NYC','address1','1 St'),
  'shipping_method_id', :'ship')) ->> 'total')::numeric as total_2 \gset
select ok(abs(:total_2 - 23.0) < 0.001, 'coupon 10% off: (20−2)+5 = 23');
select ok(exists(select 1 from public.coupon_usage where coupon_id = (select id from public.coupons where code = 'SAVE10')), 'coupon usage recorded');

-- 8. oversell
select throws_ok(format($q$select public.place_order(jsonb_build_object('store_id', %L, 'idempotency_key', 'test-3',
  'items', jsonb_build_array(jsonb_build_object('product_id', %L, 'qty', 99)), 'payment_method', 'cod',
  'customer', jsonb_build_object('email','t3@t.dev'), 'shipping_address', jsonb_build_object('country','US','city','NYC','address1','1 St'),
  'shipping_method_id', %L))$q$, :'sid', :'p_mug', :'ship'), 'P0001', null, 'oversell rejected');

-- 9. expired coupon
insert into public.coupons (store_id, code, kind, value, expires_at) values (:'sid', 'OLD', 'percent', 10, now() - interval '1 day');
select throws_ok(format('select public.validate_coupon(%L, ''OLD'', null, 100)', :'sid'), 'P0001', null, 'expired coupon rejected');

-- 10. COD refused for a digital-only basket
select throws_ok(format($q$select public.place_order(jsonb_build_object('store_id', %L, 'idempotency_key', 'test-dig',
  'items', jsonb_build_array(jsonb_build_object('product_id', %L, 'qty', 1)), 'payment_method', 'cod',
  'customer', jsonb_build_object('email','d@t.dev')))$q$, :'sid', :'p_ebook'), 'P0001', 'COD_NOT_ALLOWED_FOR_DIGITAL', 'COD rejected for digital-only');

-- 11. a COD order starts pending + unpaid
select (select id from public.orders where store_id = :'sid' and idempotency_key = 'test-1') as oid \gset
select is((select status || '/' || payment_status from public.orders where id = :'oid'), 'pending/unpaid', 'COD order starts pending/unpaid');

-- 12. merchant confirms: status moves, payment does NOT
select tests.authenticate_as('merchant');
select public.confirm_cod_order(:'oid');
select is((select status || '/' || payment_status from public.orders where id = :'oid'), 'confirmed/unpaid', 'confirm_cod_order ≠ paid');

-- 13. cash cannot be "collected" before dispatch
select throws_ok(format('select public.mark_cod_collected(%L)', :'oid'), 'P0001', 'COD_NOT_DISPATCHED', 'collection requires shipped');

-- 14. no download exists before payment; then ship + collect → paid, download created exactly once
select is((select count(*) from public.digital_downloads where order_id = :'oid'), 0::bigint, 'no entitlement before payment');
select public.update_order_status(:'oid', 'shipped');
select public.mark_cod_collected(:'oid', 'cash received');
select is((select payment_status from public.orders where id = :'oid'), 'paid', 'paid only after collection is confirmed');
select is((select count(*) from public.digital_downloads where order_id = :'oid'), 1::bigint, 'exactly one entitlement after payment');
select throws_ok(format('select public.mark_cod_collected(%L)', :'oid'), 'P0001', null, 'collection cannot be applied twice');

-- 15. cancelling an unpaid order restocks and releases the coupon
select (select id from public.orders where store_id = :'sid' and idempotency_key = 'test-2') as oid2 \gset
select public.update_order_status(:'oid2', 'cancelled', 'customer changed mind');
select is((select inventory_qty from public.products where id = :'p_mug'), 1, 'stock restored after cancel (1 + 1 − earlier 1)');
select is((select used_count from public.coupons where code = 'SAVE10' and store_id = :'sid'), 0, 'coupon usage released on cancel');

-- 16. paid orders cannot be cancelled without a refund
select throws_ok(format('select public.update_order_status(%L, ''cancelled'')', :'oid'), 'P0001', null, 'paid order requires refund before cancel');

-- 17-21. Stripe order: unpaid → amount-checked fulfilment → idempotent
select tests.clear_authentication();
select (public.place_order(jsonb_build_object('store_id', :'sid', 'idempotency_key', 'test-s1',
  'items', jsonb_build_array(jsonb_build_object('product_id', :'p_ebook', 'qty', 1)), 'payment_method', 'stripe',
  'customer', jsonb_build_object('email','s@t.dev'))) ->> 'order_id')::uuid as soid \gset
select is((select payment_status from public.orders where id = :'soid'), 'unpaid', 'stripe order starts unpaid');
select is((select count(*) from public.digital_downloads where order_id = :'soid'), 0::bigint, 'no files before verified payment');
set local role service_role;
select throws_ok(format('select public.fulfill_paid_order(%L, ''cs_1'', ''e1'', 1.00, ''usd'')', :'soid'), 'P0001', 'AMOUNT_MISMATCH', 'wrong amount rejected');
select ok((public.fulfill_paid_order(:'soid', 'cs_1', 'e1', 10.00, 'usd') ->> 'fulfilled')::boolean, 'verified payment fulfils');
select ok((public.fulfill_paid_order(:'soid', 'cs_1', 'e2', 10.00, 'usd') ->> 'already_paid')::boolean, 'second fulfilment is a no-op');
reset role;
select is((select count(*) from public.digital_downloads where order_id = :'soid'), 1::bigint, 'one download after payment, none duplicated');

select * from finish();
rollback;
