-- ============================================================================
-- security.test.sql — attack regression suite (pgTAP). Run: supabase test db
-- STATUS: written for V1.1, NOT executed in the repair sandbox (no Postgres) — see TESTING.md.
-- Every statement below is an ATTACK that must be rejected or return nothing.
-- ============================================================================
begin;
select plan(19);

select tests.create_supabase_user('merch_a', 'ma@test.dev', null);
select tests.create_supabase_user('merch_b', 'mb@test.dev', null);
select tests.create_supabase_user('shopper', 'sh@test.dev', null);
select tests.create_supabase_user('shopper2', 'sh2@test.dev', null);

insert into public.stores (name, slug, business_model, created_by, default_currency)
values ('A', 'sec-a', 'hybrid', tests.get_supabase_uid('merch_a'), 'USD') returning id \gset
select :'id' as sa \gset
insert into public.stores (name, slug, business_model, created_by, default_currency)
values ('B', 'sec-b', 'hybrid', tests.get_supabase_uid('merch_b'), 'USD') returning id \gset
select :'id' as sb \gset

insert into public.products (store_id, status, slug, name, price, currency, type, track_inventory, inventory_qty)
values (:'sa', 'active', 'pa', '{"en":"PA"}', 10, 'USD', 'physical', true, 10) returning id \gset
select :'id' as pa \gset
insert into public.products (store_id, status, slug, name, price, currency, type, track_inventory, inventory_qty)
values (:'sb', 'active', 'pb', '{"en":"PB"}', 10, 'USD', 'physical', true, 10) returning id \gset
select :'id' as pb \gset
insert into public.products (store_id, status, slug, name, price, currency, type, track_inventory)
values (:'sa', 'active', 'dig', '{"en":"Dig"}', 10, 'USD', 'digital', false) returning id \gset
select :'id' as pdig \gset

-- Public browser roles must never read merchant-only cost_price.
select ok(not has_column_privilege('anon', 'public.products', 'cost_price', 'SELECT'), 'anon cannot read product cost_price');
select ok(not has_column_privilege('authenticated', 'public.products', 'cost_price', 'SELECT'), 'authenticated cannot read product cost_price');
insert into public.shipping_zones (store_id, name, countries) values (:'sa', 'Z', '["*"]') returning id \gset
select :'id' as za \gset
insert into public.shipping_methods (store_id, zone_id, name, type, base_price) values (:'sa', :'za', '{"en":"F"}', 'flat', 1) returning id \gset
select :'id' as ma \gset
insert into public.shipping_zones (store_id, name, countries) values (:'sb', 'Z', '["*"]') returning id \gset
select :'id' as zb \gset
insert into public.shipping_methods (store_id, zone_id, name, type, base_price) values (:'sb', :'zb', '{"en":"F"}', 'flat', 1) returning id \gset
select :'id' as mb \gset

-- an order placed by `shopper` in store A (as that shopper)
select tests.authenticate_as('shopper');
select (public.place_order(jsonb_build_object('store_id', :'sa', 'idempotency_key', 'k1',
  'items', jsonb_build_array(jsonb_build_object('product_id', :'pa', 'qty', 1)), 'payment_method', 'cod',
  'customer', jsonb_build_object('email','sh@test.dev'), 'shipping_address', jsonb_build_object('country','US','city','X','address1','1'),
  'shipping_method_id', :'ma')) ->> 'order_id')::uuid as oid \gset

-- 1. a customer cannot call fulfill_paid_order (EXECUTE revoked)
select throws_ok(format('select public.fulfill_paid_order(%L, ''x'', ''y'')', :'oid'), '42501', null, 'customer cannot mark own order paid via RPC');
-- 2. nor write payment_status directly (column privileges)
select throws_ok(format('update public.orders set payment_status = ''paid'' where id = %L', :'oid'), '42501', null, 'customer cannot UPDATE orders');
-- 3. nor create free downloads / license keys
select throws_ok(format($q$insert into public.digital_downloads (store_id, order_id, order_item_id, product_id, product_file_id) values (%L, %L, gen_random_uuid(), %L, gen_random_uuid())$q$, :'sa', :'oid', :'pdig'), '42501', null, 'customer cannot INSERT downloads');
select throws_ok(format('select public.claim_download(%L)', repeat('a', 48)), '42501', null, 'claim_download is service-only');
-- 4. nor reduce another store's stock
select throws_ok(format('select public.decrement_inventory(%L, %L, null, 5, ''sale'')', :'sb', :'pb'), '42501', null, 'decrement_inventory is not callable by customers');
-- 5. price manipulation: client-sent prices are ignored
select ok((public.place_order(jsonb_build_object('store_id', :'sa', 'idempotency_key', 'k2',
  'items', jsonb_build_array(jsonb_build_object('product_id', :'pa', 'qty', 1, 'unit_price', 0.01, 'price', 0.01)),
  'total', 0.01, 'payment_method', 'cod', 'customer', jsonb_build_object('email','sh@test.dev'),
  'shipping_address', jsonb_build_object('country','US','city','X','address1','1'), 'shipping_method_id', :'ma')) ->> 'total')::numeric = 11.00,
  'forged price/total ignored (10 + 1 shipping)');
-- 6. cross-store product in a cart is rejected
select throws_ok(format($q$select public.place_order(jsonb_build_object('store_id', %L, 'idempotency_key', 'k3',
  'items', jsonb_build_array(jsonb_build_object('product_id', %L, 'qty', 1)), 'payment_method', 'cod',
  'customer', jsonb_build_object('email','sh@test.dev'), 'shipping_address', jsonb_build_object('country','US','city','X','address1','1'),
  'shipping_method_id', %L))$q$, :'sa', :'pb', :'ma'), 'P0001', null, 'product from another store rejected');
-- 7. idempotency keys do not leak across stores
select is((public.place_order(jsonb_build_object('store_id', :'sb', 'idempotency_key', 'k1',
  'items', jsonb_build_array(jsonb_build_object('product_id', :'pb', 'qty', 1)), 'payment_method', 'cod',
  'customer', jsonb_build_object('email','sh@test.dev'), 'shipping_address', jsonb_build_object('country','US','city','X','address1','1'), 'shipping_method_id', :'mb'))
  ->> 'duplicate'), 'false', 'same key in another store creates a NEW order');

-- 8. shopper sees own orders only
select is((select count(*) from public.orders where id = :'oid'), 1::bigint, 'shopper sees own order');
select tests.authenticate_as('shopper2');
select is((select count(*) from public.orders), 0::bigint, 'another shopper sees none');
select is((select count(*) from public.digital_downloads), 0::bigint, 'another shopper sees no downloads');
-- 9. merchant B cannot see store A orders; payment secrets unreachable
select tests.authenticate_as('merch_b');
select is((select count(*) from public.orders where store_id = :'sa'), 0::bigint, 'merchant B cannot read store A orders');
select throws_ok('select * from public.payment_events', '42501', null, 'payment_events not readable by clients');
select throws_ok('select secret_ref from public.payment_providers', '42501', null, 'payment_providers not readable by clients');
-- 10. merchant of the SAME store cannot fake payment either
select tests.authenticate_as('merch_a');
select throws_ok(format('update public.orders set payment_status = ''paid'' where id = %L', :'oid'), '42501', null, 'merchant cannot flip payment_status directly');
select throws_ok(format('select public.mark_cod_collected(%L)', :'oid'), 'P0001', null, 'merchant needs a dispatched COD order to confirm cash');
-- 11. forged reviews (verified purchase) are blocked for anon
select tests.clear_authentication();
select throws_ok(format($q$insert into public.reviews (store_id, product_id, author_name, rating, status, verified_purchase) values (%L, %L, 'x', 5, 'pending', true)$q$, :'sa', :'pa'), '42501', null, 'cannot forge verified-purchase review');

select * from finish();
rollback;
