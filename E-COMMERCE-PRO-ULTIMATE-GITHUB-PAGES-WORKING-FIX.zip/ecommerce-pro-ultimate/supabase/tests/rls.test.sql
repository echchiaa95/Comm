-- ============================================================================
-- rls.test.sql — Proof of multi-tenant isolation (pgTAP)
-- Run: supabase test db   (helpers come from the Supabase local test image:
--       tests.create_supabase_user / authenticate_as / clear_authentication)
-- ============================================================================
begin;
select plan(11);

-- ── Fixture users ────────────────────────────────────────────────────────────
select tests.create_supabase_user('owner_a', 'owner-a@test.dev', null);
select tests.create_supabase_user('owner_b', 'owner-b@test.dev', null);

-- ── Stores (trigger auto-creates owner membership + COD/shipping/templates) ──
insert into public.stores (name, slug, business_model, created_by, default_currency)
values ('Store A', 'store-a-test', 'hybrid', tests.get_supabase_uid('owner_a'), 'USD') returning id \gset
select :id as store_a \gset
insert into public.stores (name, slug, business_model, created_by, default_currency)
values ('Store B', 'store-b-test', 'physical', tests.get_supabase_uid('owner_b'), 'EUR') returning id \gset
select :id as store_b \gset

-- ── Fixture catalog (inserts as table owner bypass RLS — this is setup) ────
insert into public.products (store_id, status, slug, name, price, currency)
values (:store_a, 'active', 'a-widget', '{"en":"A Widget"}', 25, 'USD');
insert into public.products (store_id, status, slug, name, price, currency)
values (:store_b, 'active', 'b-widget', '{"en":"B Widget"}', 30, 'EUR');
insert into public.products (store_id, status, slug, name, price, currency)
values (:store_a, 'draft', 'a-draft', '{"en":"A Draft"}', 10, 'USD');

-- 1. Owner A has access to store A
select tests.authenticate_as('owner_a');
select ok(public.has_store_access(:store_a), 'owner_a can access store A');

-- 2. Owner A has NO access to store B
select ok(not public.has_store_access(:store_b), 'owner_a cannot access store B');

-- 3. Cross-tenant reads are invisible (RLS select)
select ok(not exists(select 1 from public.products where store_id = :store_b),
  'owner_a cannot see store B products');

-- 4. Cross-tenant writes are rejected (RLS with check)
select throws_ok(
  format('insert into public.products (store_id, status, slug, name, price) values (%s, ''active'', ''evil'', ''{"en":"x"}''::jsonb, 1)', :store_b),
  '42501', null, 'owner_a cannot insert into store B');

-- 5. store_users cross-tenant read blocked
select ok(not exists(select 1 from public.store_users where store_id = :store_b),
  'owner_a cannot see store B team');

-- 6. Payment secrets are unreachable for authenticated clients (privilege revoked)
select throws_ok('select * from public.payment_providers', '42501', null,
  'payment_providers revoked from authenticated');

-- 7. Anon sees ONLY active products
select tests.clear_authentication();
select is((select count(*) from public.products where store_id = :store_a and status = 'draft'),
  0::bigint, 'anon cannot see drafts');
select is((select count(*) from public.products where store_id = :store_a and status = 'active'),
  1::bigint, 'anon sees exactly the active product');

-- 8. Reviews: anon can submit, but only approved/featured are readable
insert into public.reviews (store_id, product_id, author_name, rating, body)
select :store_a, id, 'Tester', 5, 'Nice' from public.products where slug = 'a-widget';
select is((select count(*) from public.reviews where author_name = 'Tester'),
  0::bigint, 'pending review invisible to anon');
update public.reviews set status = 'approved' where author_name = 'Tester';
select is((select count(*) from public.reviews where author_name = 'Tester'),
  1::bigint, 'approved review visible');

-- 9. Coupon codes are tenant-scoped
select tests.authenticate_as('owner_a');
select ok(not exists(select 1 from public.coupons where store_id = :store_b),
  'owner_a cannot read store B coupons');
select ok(not exists(select 1 from public.store_settings where store_id = :store_b),
  'owner_a cannot read store B settings');

-- 10. resolve_store only exposes safe, active stores
select ok((public.resolve_store('store-a-test') ->> 'name') = 'Store A',
  'resolve_store returns safe store payload');
select ok(public.resolve_store('nonexistent-store-xyz') is null,
  'resolve_store returns null for unknown');

select * from finish();
rollback;
