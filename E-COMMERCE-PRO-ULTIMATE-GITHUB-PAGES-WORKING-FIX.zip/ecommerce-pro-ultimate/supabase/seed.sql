-- ============================================================================
-- seed.sql — Demo data. Run: supabase db reset (applies migrations + this seed)
-- Creates a demo store "Noura Boutique" (hybrid) ready for manual testing.
-- ============================================================================

-- Demo owner (adjust email to your auth user, or sign up with this one)
insert into auth.users (id, email, encrypted_password, email_confirmed_at, created_at, updated_at)
values ('00000000-0000-0000-0000-000000000001', 'demo@noura.shop',
        crypt('Demo1234!', gen_salt('bf')), now(), now(), now())
on conflict (id) do nothing;

insert into public.stores (id, name, slug, business_model, default_locale, default_currency,
  country, city, category, description, contact_email, whatsapp_number, created_by,
  brand, status)
values ('10000000-0000-0000-0000-000000000001', 'Noura Boutique', 'noura', 'hybrid', 'ar', 'MAD',
  'MA', 'Casablanca', 'fashion',
  'Fashion & digital art, curated in Casablanca.', 'demo@noura.shop', '212612345678',
  '00000000-0000-0000-0000-000000000001',
  '{"primary":"#7c3aed","accent":"#f59e0b","bg":"#ffffff","text":"#1e1b4b"}', 'active')
update public.stores set settings = settings || '{"extra_locales":["en","fr"]}'::jsonb
 where id = '10000000-0000-0000-0000-000000000001';

-- ── Catalog ────────────────────────────────────────────────────────────────
insert into public.categories (store_id, slug, name) values
  ('10000000-0000-0000-0000-000000000001', 'apparel', '{"en":"Apparel","fr":"Vêtements","ar":"ملابس"}'),
  ('10000000-0000-0000-0000-000000000001', 'digital-art', '{"en":"Digital Art","fr":"Art numérique","ar":"فن رقمي"}');

insert into public.products (store_id, status, slug, sku, name, description, price, compare_at_price, currency, type, track_inventory, inventory_qty, attributes) values
  ('10000000-0000-0000-0000-000000000001', 'active', 'linen-shirt', 'SHIRT-LIN-01',
   '{"en":"Linen Shirt","fr":"Chemise en lin","ar":"قميص كتان"}',
   '{"en":"Breathable premium linen.","fr":"Lin premium respirant.","ar":"كتان فاخر يسمح بمرور الهواء."}',
   349, 449, 'MAD', 'physical', true, 25, '{"sizes":["S","M","L","XL"],"colors":["white","beige"]}'),
  ('10000000-0000-0000-0000-000000000001', 'active', 'leather-tote', 'TOTE-LEA-02',
   '{"en":"Leather Tote","fr":"Cabas en cuir","ar":"حقيبة جلدية"}',
   '{"en":"Handcrafted full-grain leather.","fr":"Cuir pleine fleur artisanal.","ar":"جلد طبيعي مصنوع يدوياً."}',
   899, null, 'MAD', 'physical', true, 8, '{"colors":["tan","black"]}'),
  ('10000000-0000-0000-0000-000000000001', 'active', 'wall-art-pack', 'ART-PACK-01',
   '{"en":"Wall Art Pack (10 prints)","fr":"Pack d''affiches (10)","ar":"حزمة ملصقات جدارية (10)"}',
   '{"en":"10 high-resolution prints, instant download.","fr":"10 affiches haute résolution, téléchargement immédiat.","ar":"10 ملصقات بدقة عالية، تحميل فوري."}',
   99, 149, 'MAD', 'digital', false, 0, '{}');

insert into public.product_categories (product_id, category_id)
select p.id, c.id from public.products p, public.categories c
where p.slug in ('linen-shirt','leather-tote') and c.slug = 'apparel'
   or p.slug = 'wall-art-pack' and c.slug = 'digital-art';

-- ── Shipping / coupons / marketing fixtures ───────────────────────────────
insert into public.shipping_zones (store_id, name, countries) values
  ('10000000-0000-0000-0000-000000000001', 'Morocco', '["MA"]'),
  ('10000000-0000-0000-0000-000000000001', 'Worldwide', '["*"]');
insert into public.shipping_methods (store_id, zone_id, name, type, base_price, free_over) values
  ('10000000-0000-0000-0000-000000000001', (select id from public.shipping_zones where name='Morocco' and store_id='10000000-0000-0000-0000-000000000001'),
   '{"en":"Local delivery","fr":"Livraison locale","ar":"توصيل محلي"}', 'free_threshold', 30, 500),
  ('10000000-0000-0000-0000-000000000001', (select id from public.shipping_zones where name='Worldwide' and store_id='10000000-0000-0000-0000-000000000001'),
   '{"en":"International","fr":"International","ar":"دولي"}', 'flat', 150, null);

insert into public.coupons (store_id, code, kind, value, min_order_total, starts_at, expires_at) values
  ('10000000-0000-0000-0000-000000000001', 'WELCOME10', 'percent', 10, 0, now() - interval '1 day', now() + interval '30 days');

insert into public.popups (store_id, name, type, status, content, behavior) values
  ('10000000-0000-0000-0000-000000000001', 'Welcome 10% off', 'discount', 'active',
   '{"title":"أهلاً بك! Welcome! Bienvenue !","body":"Get 10% off your first order.","coupon_code":"WELCOME10"}',
   '{"delay_seconds":4,"frequency_cap":2,"cooldown_hours":48}');

insert into public.store_banners (store_id, placement, content, link) values
  ('10000000-0000-0000-0000-000000000001', 'home_hero',
   '{"title":{"en":"New Season","fr":"Nouvelle saison","ar":"موسم جديد"},"subtitle":{"en":"Up to 30% off linen","fr":"Jusqu''à -30% sur le lin","ar":"خصم حتى 30٪ على الكتان"}}',
   '/category/apparel');

insert into public.blog_posts (store_id, slug, title, excerpt, content, status, published_at, reading_time_min) values
  ('10000000-0000-0000-0000-000000000001', 'caring-for-linen',
   '{"en":"Caring for linen","fr":"Entretenir le lin","ar":"العناية بالكتان"}',
   '{"en":"Wash cold, air dry.","fr":"Lavage à froid, séchage à l''air.","ar":"غسيل بارد وتجفيف طبيعي."}',
   '{"en":"Linen lasts decades when washed cold and air-dried. Avoid bleach and tumble drying.","fr":"Le lin dure des décennies lavé à froid et séché à l''air.","ar":"الكتان يدوم عقوداً مع الغسيل البارد والتجفيف الطبيعي."}',
   'published', now(), 2);

insert into public.store_pages (store_id, slug, title, content, status, show_in_footer) values
  ('10000000-0000-0000-0000-000000000001', 'contact',
   '{"en":"Contact us","fr":"Contact","ar":"اتصل بنا"}',
   '{"en":"Email: demo@noura.shop — WhatsApp: +212612345678","fr":"Email : demo@noura.shop","ar":"البريد: demo@noura.shop — واتساب: +212612345678"}',
   'published', true);
