# TESTING — what was actually executed, and what still must be

> **Honesty rule (V1.1):** a row is marked ✅ only if the command was really run and passed. Everything else is
> ⏳ *written but not executed* or ⛔ *needs live services*. Nothing here is "production ready" until the ⏳/⛔ rows are green on a real deployment.

## A. Executed in the V1.1 repair sandbox (no Postgres, no network, no Stripe)

| Check | Command | Result |
|---|---|---|
| Migration dependency order (every FK/index/policy/trigger/revoke target exists before use; every table used in function bodies exists) | `python3 scripts/check-migrations.py` | ✅ OK — 75 tables, 46 functions. *Original 4 migrations: failed with 13+ undefined tables.* |
| TS/TSX/Edge-Function **syntax** gate | `node scripts/syntax-check.mjs` | ✅ 37 files, 0 errors. *Original: 3 errors in `web/src/App.tsx:34` (invalid JSX closing).* |
| Multi-store / multi-language prerender output (2 stores, `ar`/`en`/`fr`, hreflang, canonical, JSON-LD, RTL/LTR, escaping, no admin pages) against a local fake PostgREST | `cd web && node scripts/prerender.test.mjs` | ✅ 11 pages generated and validated, all assertions passed |

These do **not** prove SQL syntax, RLS behaviour, type-correctness or runtime behaviour.

## B. Written, NOT executed (need `supabase start` / `npm install` / Deno)

| Suite | File | Assertions | Needs |
|---|---|---|---|
| RLS tenant isolation | `supabase/tests/rls.test.sql` | 11 | `supabase test db` |
| Commerce engine (pricing, idempotency, coupons, stock, COD confirm ≠ paid ≠ collected, digital only after payment, cancel/restock, Stripe amount check) | `supabase/tests/checkout.test.sql` | 26 | `supabase test db` |
| Attack regressions (customer calls `fulfill_paid_order`, direct `payment_status` update, forged downloads, cross-store stock, price forgery, idempotency leak, other shopper's orders, payment secrets, forged reviews, public cost-column access) | `supabase/tests/security.test.sql` | 19 | `supabase test db` |
| Strict typecheck + production build | `cd web && npm install && npm run typecheck && npm run build` | — | network; `package-lock.json` is not included in this archive, so dependency resolution is not yet reproducible |
| Edge Function typecheck | `deno check supabase/functions/*/index.ts` | — | Deno |

**First thing to do on a machine with Docker:** `supabase start && supabase db reset` — the migrations have never been executed against a real Postgres; expect to fix a few SQL details the static checker cannot see.

## C. The 25 business scenarios (matrix)

Status legend: ✅ executed & passed · ⏳ automated test written, not run · ⛔ requires live services/manual.

| # | Scenario | Env needed | Status | Evidence / remaining issue |
|---|---|---|---|---|
| 1 | Store creation (wizard → `create-store` → trigger configures COD/shipping/templates) | Supabase | ⛔ | `/admin/setup` page + function rewritten; not run |
| 2 | Physical product + COD order | Supabase | ⏳ | `checkout.test.sql` #1–7 |
| 3 | Server-side pricing / shipping / tax | Supabase | ⏳ | `checkout.test.sql` #1, `security.test.sql` #6 |
| 4 | Stock decrement, oversell blocked, cancel restock | Supabase | ⏳ | `checkout.test.sql` #4,#8,#18 |
| 5 | COD lifecycle: confirm → ship → cash collected (paid only then) | Supabase | ⏳ | `checkout.test.sql` #11–17 |
| 6 | Stripe checkout (Connect destination charge / own key) | Stripe test mode | ⛔ | `create-checkout` rewritten, not run |
| 7 | Stripe webhook: signature, async payment, duplicate, retry | Stripe CLI | ⛔ | state machine in `claim_payment_event`; not run |
| 8 | Failed payment / refund / `account.updated` | Stripe CLI | ⛔ | handlers written, not run |
| 9 | Digital delivery only after verified payment | Supabase + Stripe | ⏳/⛔ | `checkout.test.sql` #21–26 (DB part) |
| 10 | Hybrid cart (physical + digital) | Supabase | ⏳ | `checkout.test.sql` #1 (mixed basket), #14–16 |
| 11 | Coupon validation (expired, usage, restriction) | Supabase | ⏳ | `checkout.test.sql` #6,#7,#9 |
| 12 | Abandoned cart (consent, frequency, recovery, restore link) | Supabase + email | ⛔ | worker/RPC rewritten, not run |
| 13 | Email workflows (transactional vs marketing, unsubscribe) | Resend | ⛔ | `send-email`, `unsubscribe` rewritten, not run |
| 14 | WhatsApp | Provider account | ⛔ | **Not operational** — no provider integration exists |
| 15 | Loyalty accrual & tiers | Supabase | ⛔ | `_finalize_paid_order` / `recalc_loyalty` rewritten, not run |
| 16 | Referral reward (once, after payment) | Supabase | ⛔ | moved from order insert to payment; not run |
| 17 | Reviews (moderation, verified purchase not forgeable) | Supabase | ⏳ | `security.test.sql` #17 |
| 18 | Arabic / French / English URLs & UI | Browser | ✅ (SEO output) / ⛔ (UI) | prerender test asserts `lang`/`dir`/hreflang; UI language switch not run |
| 19 | RTL / LTR | Browser | ✅ (static HTML) / ⛔ (UI) | same |
| 20 | Prerender: title, description, canonical, OG, JSON-LD | Node | ✅ | `prerender.test.mjs` |
| 21 | Sitemap / robots on store domain | Deno + Supabase | ⛔ | functions rewritten; need CDN rewrite rules (README) |
| 22 | Custom domain verification (TXT proof) | DNS | ⛔ | `verify-domain` rewritten |
| 23 | RLS & cross-tenant isolation | Supabase | ⏳ | `rls.test.sql`, `security.test.sql` |
| 24 | Mobile checkout + PWA install/update | Browser | ⛔ | `sw.js` v2 rewritten; install/update not tested |
| 25 | Analytics events & consent | Browser + Supabase | ⛔ | RLS tightened; not run |

## D. Manual checklist with real keys (unchanged intent, updated steps)

1. `supabase secrets set --env-file supabase/.env` (see `supabase/.env.example`), deploy functions.
2. Stripe: create two webhook endpoints → `…/functions/v1/stripe-webhook` (events: `checkout.session.completed`, `checkout.session.async_payment_succeeded`, `checkout.session.async_payment_failed`, `checkout.session.expired`, `payment_intent.payment_failed`, `charge.refunded`) and a **Connect** endpoint for `account.updated`. Test: `stripe trigger checkout.session.completed`, replay the same event (must be a no-op), send a bad signature (must be 400).
3. Schedule workers with header `x-cron-secret: $CRON_SECRET`: `send-email` (1 min), `abandoned-cart-worker` (15 min), `automation-worker` (hourly), and `select public.expire_unpaid_orders(60)` (pg_cron, 15 min).
4. Verify downloads: pay, open the emailed link (200→302), exceed the limit (429), wait for expiry (410), refund (403).

The three pgTAP plans currently total **56 assertions** (11 RLS + 26 checkout + 19 security). They are authored but have not been executed in this repair environment.

## E. Hardening checklist
- [ ] `supabase db reset` + `supabase test db` green in CI
- [ ] On a network-connected machine, run `cd web && npm install`; commit the generated `web/package-lock.json`.
- [ ] After committing the lockfile, verify the existing conditional web CI path selects `npm ci`; then verify `npm ci && npm run typecheck && npm run build` in CI.
- [ ] PITR backups enabled; restore drill
- [ ] Rate limiting in front of `place_order` / functions (Cloudflare / API gateway)
- [ ] `git grep -nE "sk_(live|test)_|whsec_"` returns nothing

## V1.1 follow-up: public product cost confidentiality

The forward migration `0007_public_product_column_security.sql` restricts browser roles to an explicit list of public product columns and replaces `search_products` so it no longer returns the full `products` row. The storefront and admin product-list queries use explicit projections. Run `python3 scripts/check-public-product-columns.py` for the static regression check, then run `supabase db reset && supabase test db` to execute the two new pgTAP assertions against PostgreSQL.
