# Super Admin dashboard implementation

Added:
- `/platform-admin` authenticated route available even when no tenant store resolves.
- `web/src/pages/platform-superadmin.tsx`: store list, merchant invitation/store creation, store status changes.
- `supabase/functions/platform-admin/index.ts`: verifies JWT and `platform_superadmins` membership server-side; uses service role only inside Edge Function.
- `supabase/config.toml`: JWT verification enabled for `platform-admin`.

Deployment steps:
1. Apply migrations including `0008_platform_superadmins.sql`.
2. Bootstrap the superadmin account with `bootstrap_superadmin.sql`.
3. Deploy: `supabase functions deploy platform-admin`.
4. Set Supabase Auth Site URL and Redirect URLs to the deployed GitHub Pages URL.
5. Configure Supabase SMTP for merchant invitations.
6. Configure Edge Function `ALLOWED_ORIGINS` to include the exact GitHub Pages origin.
7. Sign in as the superadmin and visit `/platform-admin`.

The function creates an Auth invitation first, then inserts the store with `created_by` set to the invited merchant.
The existing `handle_new_store` trigger grants the merchant the `owner` store role. If store insertion fails,
the function deletes the newly invited Auth user as rollback.

No service-role key is exposed in frontend code.
