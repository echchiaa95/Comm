import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

type StoreRow = {
  id: string; name: string; slug: string; status: string;
  business_model: string; default_currency: string; contact_email: string | null;
  created_at: string;
};

export default function PlatformSuperAdmin() {
  const [stores, setStores] = useState<StoreRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [form, setForm] = useState({
    merchant_name: "", email: "", store_name: "", slug: "",
    business_model: "physical", currency: "MAD", default_locale: "ar",
    country: "MA", city: "",
  });

  async function invoke(body: Record<string, unknown>) {
    const { data, error } = await supabase.functions.invoke("platform-admin", { body });
    if (error) {
      const payload = await (error as any).context?.json?.().catch(() => null);
      throw new Error(payload?.error ?? error.message);
    }
    if (data?.error) throw new Error(data.error);
    return data;
  }

  async function load() {
    setLoading(true); setError("");
    try {
      const data = await invoke({ action: "list" });
      setStores(data.stores ?? []);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load stores.");
    } finally { setLoading(false); }
  }

  useEffect(() => { void load(); }, []);

  function update(key: keyof typeof form, value: string) {
    setForm((old) => ({
      ...old, [key]: value,
      ...(key === "store_name" && !old.slug
        ? { slug: value.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") }
        : {}),
    }));
  }

  async function create(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError(""); setNotice("");
    try {
      const data = await invoke({ action: "create", ...form });
      setNotice(`Store ${data.store.name} created. Invitation sent to ${data.merchant.email}.`);
      setForm({ merchant_name: "", email: "", store_name: "", slug: "", business_model: "physical", currency: "MAD", default_locale: "ar", country: "MA", city: "" });
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Store creation failed.");
    } finally { setBusy(false); }
  }

  async function changeStatus(store_id: string, status: string) {
    setError(""); setNotice("");
    try {
      await invoke({ action: "set_status", store_id, status });
      setNotice("Store status updated.");
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Status update failed."); }
  }

  const input = "w-full rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-sm";
  return (
    <main className="min-h-screen bg-slate-50 p-4 sm:p-8" dir="auto">
      <div className="mx-auto max-w-6xl space-y-7">
        <header className="flex flex-wrap items-center justify-between gap-3">
          <div><p className="text-sm font-semibold text-indigo-600">E-Commerce Pro Ultimate</p><h1 className="text-3xl font-extrabold">Platform Super Admin</h1><p className="mt-1 text-sm text-slate-500">Manage stores and merchant invitations.</p></div>
          <button onClick={() => void load()} className="rounded-xl border bg-white px-4 py-2 text-sm font-semibold">Refresh</button>
        </header>

        {error && <div role="alert" className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}
        {notice && <div role="status" className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-700">{notice}</div>}

        <section className="rounded-2xl border bg-white p-5 shadow-sm sm:p-7">
          <h2 className="mb-1 text-xl font-bold">Create merchant account and store</h2>
          <p className="mb-5 text-sm text-slate-500">The merchant receives an email invitation to set their password. The store is assigned to that merchant as owner.</p>
          <form onSubmit={create} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <input className={input} placeholder="Merchant full name" value={form.merchant_name} onChange={e => update("merchant_name", e.target.value)} />
            <input className={input} type="email" required placeholder="Merchant email" value={form.email} onChange={e => update("email", e.target.value)} />
            <input className={input} required minLength={2} placeholder="Store name" value={form.store_name} onChange={e => update("store_name", e.target.value)} />
            <input className={input} required pattern="[a-z0-9][a-z0-9-]{1,59}" placeholder="store-slug" value={form.slug} onChange={e => update("slug", e.target.value)} />
            <select className={input} value={form.business_model} onChange={e => update("business_model", e.target.value)}><option value="physical">Physical products</option><option value="digital">Digital products</option><option value="hybrid">Hybrid</option></select>
            <input className={input} required minLength={3} maxLength={3} placeholder="Currency (MAD)" value={form.currency} onChange={e => update("currency", e.target.value.toUpperCase())} />
            <select className={input} value={form.default_locale} onChange={e => update("default_locale", e.target.value)}><option value="ar">العربية</option><option value="fr">Français</option><option value="en">English</option></select>
            <input className={input} maxLength={2} placeholder="Country code (MA)" value={form.country} onChange={e => update("country", e.target.value.toUpperCase())} />
            <input className={input} placeholder="City" value={form.city} onChange={e => update("city", e.target.value)} />
            <div className="sm:col-span-2 lg:col-span-3"><button disabled={busy} className="rounded-xl bg-indigo-600 px-5 py-3 font-bold text-white disabled:opacity-50">{busy ? "Creating…" : "Create account and store"}</button></div>
          </form>
        </section>

        <section className="rounded-2xl border bg-white p-5 shadow-sm sm:p-7">
          <div className="mb-4 flex items-center justify-between"><h2 className="text-xl font-bold">Stores ({stores.length})</h2></div>
          {loading ? <p className="text-sm text-slate-500">Loading stores…</p> : stores.length === 0 ? <p className="text-sm text-slate-500">No stores registered yet.</p> : (
            <div className="overflow-x-auto"><table className="w-full min-w-[720px] text-left text-sm"><thead><tr className="border-b text-slate-500"><th className="p-3">Store</th><th className="p-3">Merchant email</th><th className="p-3">Model</th><th className="p-3">Status</th><th className="p-3">Actions</th></tr></thead><tbody>
              {stores.map(s => <tr key={s.id} className="border-b last:border-0"><td className="p-3"><b>{s.name}</b><div className="text-xs text-slate-500">{s.slug}</div></td><td className="p-3">{s.contact_email ?? "—"}</td><td className="p-3">{s.business_model}</td><td className="p-3">{s.status}</td><td className="p-3"><select aria-label={`Change status for ${s.name}`} className="rounded-lg border p-2" value={s.status} onChange={e => void changeStatus(s.id, e.target.value)}><option value="trial">Trial</option><option value="active">Active</option><option value="suspended">Suspended</option><option value="closed">Closed</option></select></td></tr>)}
            </tbody></table></div>
          )}
        </section>
      </div>
    </main>
  );
}
