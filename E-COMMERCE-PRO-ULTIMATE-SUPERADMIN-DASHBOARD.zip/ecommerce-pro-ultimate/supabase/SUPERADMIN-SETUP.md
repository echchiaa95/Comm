# Supabase first-time setup: superadmin

## Apply migrations
Run `supabase db push` against the new Supabase project, or apply migrations in order
through the Supabase migration workflow. This includes `0008_platform_superadmins.sql`.

## Create the first superadmin
1. Create the intended administrator account in Supabase Authentication.
2. Open `bootstrap_superadmin.sql`.
3. Replace `REPLACE_WITH_YOUR_LOGIN_EMAIL` with the exact Auth email.
4. Run the SQL in the Supabase SQL Editor while signed in as project owner.

This direct SQL bootstrap is intentionally not available to browser users.

## Deploy the store creation function
`supabase functions deploy create-store`

Only users listed in `public.platform_superadmins` can create stores. Other signed-in
users receive HTTP 403. If migration 0008 has not been applied, the function returns
HTTP 503 rather than allowing store creation.

Never put `SUPABASE_SERVICE_ROLE_KEY` in frontend environment variables.

## Platform admin dashboard and merchant provisioning
After applying migrations and bootstrapping your superadmin, deploy:
`supabase functions deploy platform-admin`

Sign in with the superadmin account and open:
`https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPOSITORY/platform-admin`

The dashboard can list stores, invite a merchant by email, create the store with that merchant as
`created_by` (the existing `handle_new_store` trigger assigns the owner role), and change store
status. The invitation uses Supabase Auth email delivery; configure SMTP and Auth redirect URLs
in Supabase for reliable invitations. Ensure the deployed Edge Function accepts your frontend
origin via `ALLOWED_ORIGINS` (for GitHub Pages, include `https://echchiaa95.github.io`).
