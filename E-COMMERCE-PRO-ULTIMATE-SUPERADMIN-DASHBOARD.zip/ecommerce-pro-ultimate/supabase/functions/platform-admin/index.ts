import { createClient } from "npm:@supabase/supabase-js@2";
import { adminClient, corsHeaders, json } from "../_shared/http.ts";

const schema = (v: any) => {
  const email = String(v?.email ?? "").trim().toLowerCase();
  const storeName = String(v?.store_name ?? "").trim();
  const slug = String(v?.slug ?? "").trim().toLowerCase();
  const model = v?.business_model ?? "physical";
  const currency = String(v?.currency ?? "MAD").trim().toUpperCase();
  if (!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email)) return "A valid merchant email is required.";
  if (storeName.length < 2 || storeName.length > 120) return "Store name must be 2-120 characters.";
  if (!/^[a-z0-9][a-z0-9-]{1,59}$/.test(slug) || ["www","admin","api","app","mail","login","auth"].includes(slug)) return "Invalid or reserved store slug.";
  if (!["physical","digital","hybrid"].includes(model)) return "Invalid business model.";
  if (!/^[A-Z]{3}$/.test(currency)) return "Currency must be a 3-letter code.";
  return null;
};

Deno.serve(async (req) => {
  const admin = adminClient();
  const cors = await corsHeaders(admin, req);
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  if (req.method !== "POST") return json({ error: "method not allowed" }, 405, cors);

  const authClient = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
    global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data: { user }, error: authError } = await authClient.auth.getUser();
  if (authError || !user) return json({ error: "unauthorized" }, 401, cors);

  const { data: adminRow, error: lookupError } = await admin
    .from("platform_superadmins").select("user_id").eq("user_id", user.id).maybeSingle();
  if (lookupError) return json({ error: "Super Admin migration is missing or database is unavailable." }, 503, cors);
  if (!adminRow) return json({ error: "Only platform superadmins can access this operation." }, 403, cors);

  const body = await req.json().catch(() => ({}));
  const action = body?.action ?? "list";

  if (action === "list") {
    const { data, error } = await admin.from("stores")
      .select("id,name,slug,status,business_model,default_currency,country,city,contact_email,created_at,created_by")
      .order("created_at", { ascending: false }).limit(200);
    if (error) return json({ error: error.message }, 500, cors);
    return json({ stores: data ?? [] }, 200, cors);
  }

  if (action === "create") {
    const invalid = schema(body);
    if (invalid) return json({ error: invalid }, 400, cors);

    const { data: existing } = await admin.from("stores").select("id").eq("slug", body.slug).maybeSingle();
    if (existing) return json({ error: "This store address is already taken." }, 409, cors);

    // Invite the merchant. Supabase sends a password-setup invitation; no password is handled here.
    const { data: invited, error: inviteError } = await admin.auth.admin.inviteUserByEmail(
      String(body.email).trim().toLowerCase(),
      { data: { full_name: String(body.merchant_name ?? "").trim() || null } }
    );
    if (inviteError || !invited.user) return json({ error: inviteError?.message ?? "Could not invite merchant." }, 400, cors);

    const merchantId = invited.user.id;
    const { data: store, error: storeError } = await admin.from("stores").insert({
      name: String(body.store_name).trim(),
      slug: String(body.slug).trim().toLowerCase(),
      business_model: body.business_model ?? "physical",
      default_currency: String(body.currency ?? "MAD").toUpperCase(),
      default_locale: body.default_locale ?? "ar",
      country: body.country ? String(body.country).toUpperCase() : null,
      city: body.city ? String(body.city).trim() : null,
      contact_email: String(body.email).trim().toLowerCase(),
      created_by: merchantId,
      status: "trial",
    }).select("id,name,slug,status,business_model,default_currency,created_at").single();

    if (storeError || !store) {
      // Roll back the invited Auth user if store provisioning fails.
      await admin.auth.admin.deleteUser(merchantId);
      return json({ error: storeError?.message ?? "Could not create store." }, 500, cors);
    }

    return json({ store, merchant: { id: merchantId, email: invited.user.email }, invitation_sent: true }, 201, cors);
  }

  if (action === "set_status") {
    const id = String(body.store_id ?? "");
    const status = String(body.status ?? "");
    if (!id || !["trial","active","suspended","closed"].includes(status)) {
      return json({ error: "Valid store_id and status are required." }, 400, cors);
    }
    const { data, error } = await admin.from("stores").update({ status }).eq("id", id)
      .select("id,name,slug,status").single();
    if (error) return json({ error: error.message }, 500, cors);
    return json({ store: data }, 200, cors);
  }

  return json({ error: "Unknown action." }, 400, cors);
});
